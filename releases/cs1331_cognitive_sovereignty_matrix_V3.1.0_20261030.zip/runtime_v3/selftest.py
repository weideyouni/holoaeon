# -*- coding: utf-8 -*-
"""
认知主权矩阵 V3.1 —— 14 组自检（G1-G14）
==============================================================
张量向量化 × 五机制 × 内外协议融通 × 平台全域 × 五阶闭环 × 冷热插拔插件宿主。
纯标准库、零外部依赖、确定性；平台侧数据一律 pending_human_measure（零伪造）。
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from so1331_runtime import (  # noqa: E402
    spec, ThreadBus, HeartbeatHub, SkinGate, Cytoskeleton, SemanticBus, HebbianField,
    HyperSpace, LogicGrid, KalmanChannels, HilbertLayers, MandalaSpace,
    OntologyGraph, QueryForge, CORE_PROMPTS, AntiLabelEngine, OfflineInjector,
    ProtocolFusion, PlatformRegistry, Knowledge, SovereignHost, PluginHost,
)

RESULT = []
ASSERTS = []


def _check(name: str, cond: bool, detail: str = "") -> None:
    RESULT.append((name, bool(cond), detail))
    ASSERTS.append(bool(cond))


def g1_identity() -> None:
    ok = (
        spec.MATRIX_ID == "SG-MASTER-COGNITIVE-SOVEREIGNTY-1331x1331-SUPER-MAS-V3.1"
        and spec.RUNTIME_ID == "SG-MASTER-COGNITIVE-SOVEREIGNTY-RUNTIME-HOLOGRAPHIC-V3.1"
        and spec.DOMAIN == "sovereign"
        and spec.PROTOCOL_ID == "SO-DATAPROTO v3.1"
        and spec.VERSION == "V3.1.0"
        and spec.BUS_ID == "SO-BUS-V1.0" and spec.THREADBUS_ID == "SO-THREADBUS-V1.0"
        and spec.SECRET_OPEN == "潮起开门" and spec.SECRET_CLOSE == "潮落闭嘴"
    )
    _check("G1 身份/协议/密令(V3.1)", ok)


def g2_locks() -> None:
    ok = (
        spec.lock_verify()
        and spec.LOCK_DESIGN == 1771561 and spec.LOCK_MANDALA == 108641
        and spec.LOCK_HILBERT == 651846 and spec.LOCK_KALMAN == 22627
        and spec.LOCK_HILBERT == spec.LOCK_MANDALA * 6
    )
    _check("G2 锁数(1331²/108641/651846/22627)", ok)


def g3_heartbeat_spec() -> None:
    ok = (
        spec.HEARTBEAT_COUNT == 70 and spec.HEARTBEAT_BASE == 9700
        and spec.HEARTBEAT_BASE + spec.HEARTBEAT_COUNT - 1 == 9769
        and spec.HEARTBEAT_DIM == 768 and abs(spec.HEARTBEAT_ALPHA - 0.18) < 1e-9
    )
    _check("G3 心跳(70体/9700-9769/768维/α0.18)", ok)


def g4_threadbus() -> None:
    bus = ThreadBus()
    v = bus.verify()
    ok = v["ok"] and bus.heartbeat()["domain"] == "sovereign"
    _check("G4 ThreadBus 域锁 sovereign", ok)


def g5_heartbeat_run() -> None:
    v = HeartbeatHub().verify()
    ok = v["ok"] and v["scan"]["total"] == 70 and v["holo"]["probe_uid"] == 9700
    _check("G5 心跳运行/全息自检", ok)


def g6_cytoskeleton() -> None:
    v = Cytoskeleton().verify()
    ok = v["ok"] and v["cross_links_total"] == 12
    _check("G6 细胞骨架 L3×4 采洗检注/跨链12", ok)


def g7_skin() -> None:
    v = SkinGate().verify()
    ok = v["ok"] and v["layers"] == 8 and v["version"] == "SG-SKIN-V6.0"
    _check("G7 皮肤八层 L1-L8", ok)


def g8_gate() -> None:
    v = SkinGate().verify()
    ok = v["e14_veto"] and v["e13_veto"] and v["normal_pass"] and v["secret_pass"]
    _check("G8 皮肤闸门(E14越界/E13失真/正常/密令)", ok)


def g9_semantic() -> None:
    v = SemanticBus().verify()
    ok = v["ok"] and v["modules_total"] == 10 and len(v["routes"]) == 10
    _check("G9 语义十模块/路由", ok)


def g10_knowledge_csv() -> None:
    v = Knowledge().verify()
    ok = (v["executors"] == 70 and v["dimensions"] == 147
          and v["dims_avatar"] == 130 and v["dims_channel"] == 17
          and v["mandala_rows"] == 10 and v["mandala_total"] == 108641
          and v["cases"] == 20 and v["case_cats"] == {"normal": 10, "AL": 4, "PF": 6}
          and abs(v["weight_sum"] - 1.0) <= 0.001)
    _check("G10 四表台账(70/147=130+17/10行108641/20案例)", ok)


def g11_protocols_subjects() -> None:
    k = Knowledge()
    p = k.protocols()
    s = k.subjects()
    pr = PlatformRegistry().verify()
    ok = (
        p["total"] == 23 and p["inner_count"] == 12 and p["outer_count"] == 11
        and s["total"] == 40 and s["origin_count"] == 29 and s["fusion_count"] == 11
        and pr["ok"] and pr["avatars"] == 168 and pr["groups"] == 130
        and pr["special"] == 26 and pr["bridge"] == 12 and pr["families"] == 10
    )
    _check("G11 协议23(内12外11)/40科(29+11)/168分身(130+26+12)", ok)


def g12_tensor_forge_interop() -> None:
    hv = HyperSpace().verify()
    lg = LogicGrid().verify()
    kc = KalmanChannels().verify()
    hl = HilbertLayers().verify()
    md = MandalaSpace().verify()
    fg = QueryForge().verify()
    og = OntologyGraph().verify()
    al = AntiLabelEngine().verify()
    inj = OfflineInjector().verify()
    pf = ProtocolFusion().verify()
    ok = (
        hv["ok"] and hv["dim"] == 768 and abs(hv["self_cosine"] - 1.0) < 1e-9
        and hv["deterministic"] and hv["bipolar"]
        and lg["ok"] and lg["design"] == 1771561 and lg["combos"] == 10 * 23 * 17
        and kc["ok"] and kc["formula_ok"] and hl["ok"] and hl["capacity"] == 651846
        and md["ok"] and md["total"] == 108641
        and fg["ok"] and fg["deterministic"] and fg["density_monotonic"]
        and og["ok"] and og["cognitive_domains"] == 16
        and al["ok"] and al["blocks_automation"] and al["all_manual"]
        and inj["ok"] and inj["no_auto"] and inj["unknown_mode_rejected"]
        and pf["ok"] and pf["cells"] == 132 and pf["no_network"]
    )
    _check("G12 张量向量化/锻造/反标签/内外协议132映射", ok)


def g13_hebbian_host() -> None:
    hv = HebbianField().verify()
    host = SovereignHost("0")
    rd = host.run_round()
    st = rd["stages"]
    ok = (
        hv["ok"] and hv["nodes"] == 17 and hv["fol_circles"] == 19
        and hv["fol_edges_19"] == 42 and hv["node_edges_17"] == 36
        and hv["flow_edges"] == 28
        and hv["hebbian_potentiation"] and hv["deterministic"]
        and rd["round_ok"] and rd["domain"] == "sovereign"
        and sorted(st.keys()) == ["R0", "R1", "R2", "R3", "R4"]
        and st["R1"]["deterministic"] and st["R2"]["all_manual"]
        and st["R3"]["network"] is False and st["R4"]["all_allowed"]
        and st["R4"]["platform_metrics"]["status"] == "pending_human_measure"
        and all(st[s]["simulated"] for s in st)
        and len(st["R4"]["audit"]) == 16
        and rd["heartbeat"]["scan"]["healthy"]
        and len(CORE_PROMPTS) == 7
    )
    _check("G13 赫布协作场(19圆/17节点/42几何/28流边)+宿主R0-R4闭环", ok)


def _round_digest(round_dict: dict) -> str:
    import hashlib
    import json
    payload = {k: v for k, v in round_dict.items() if k not in ("round", "seed")}
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True,
                                     default=str).encode("utf-8")).hexdigest()[:16]


def g14_plugin_host() -> None:
    """SD-Distill 冷热插拔：冷装 / 热装 / 卸载回滚 / 非侵入（宿主产物逐位一致）。"""
    root = os.path.dirname(os.path.abspath(__file__))
    skin = SkinGate()
    # ① 冷装：启动期按 manifest.enabled 装载
    ph_cold = PluginHost(root, skin=skin)
    avail = ph_cold.discover()
    cold = ph_cold.cold_boot()
    caps_cold = ph_cold.capabilities()

    # ② 热装：全新宿主（尚未冷装）现场装载；非侵入性用"两次首轮产物逐位一致"证明
    before = _round_digest(SovereignHost("0").run_round())
    ph_hot = PluginHost(root, skin=skin)
    hot = ph_hot.hot_load("subdistill")
    rd_after = SovereignHost("0").run_round()
    after_load = _round_digest(rd_after)
    caps = ph_hot.capabilities()

    run = caps["pipeline.run"](tau=1.4, gate=skin, epoch=1)
    valid = [caps["skc.validate"](s)["ok"] for s in run["skcs"]]
    loss = caps["losses.eval"]({"covered": 9, "total": 12, "tp": 7, "fp": 2, "fn": 1,
                                "mappable_p": 0.6, "dist": {"cross": 0.6, "part": 0.3, "none": 0.1},
                                "max_hist_cos": 0.3, "retrievability": 0.7, "gate_hits": 0,
                                "tokens": 900, "latency_ms": 30.0})
    st = [caps["curriculum.stage"](e) for e in (0, 250, 600, 1100)]
    bursts = [caps["curriculum.burst"](e) for e in range(40)]
    anti = caps["antilabel.score"]([caps["taxonomy.encode"]("范畴论 与 大模型对齐 伴随函子 偏好优化")])
    far = caps["taxonomy.far_pairs"](0.02, 5)

    # ③ 卸载回滚 → 再热装
    gone = ph_hot.hot_unload("subdistill")
    caps_after = ph_hot.capabilities()
    re = ph_hot.hot_load("subdistill")

    ok = (
        len(avail) == 1 and avail[0]["id"] == "subdistill" and avail[0]["enabled"]
        and cold["loaded"] == ["subdistill"] and len(caps_cold) == len(caps)
        and len(caps) >= 11
        and not any("network" in c.lower() or "login" in c.lower() or "scrape" in c.lower()
                    for c in caps)
        and hot["ok"] and hot["mode"] == "hot" and len(hot["capabilities"]) >= 10
        and hot["audit"] and hot["meta"]["checks"]["slots_ok"]
        and hot["meta"]["checks"]["nodes_ok"]
        and before == after_load and rd_after["round_ok"]
        and run["S2"]["classified"] >= 5 and run["S4"]["edges"] >= 5
        and run["S5"]["units"] >= 1 and run["S6"]["skcs"] >= 1
        and run["S7"]["committed"] == run["S6"]["skcs"] and all(valid)
        and 0.0 <= loss["total"] <= 1.0 and len(loss["parts"]) == 7
        and [s["name"] for s in st] == ["C1_root", "C2_neighbor", "C3_far", "C4_multi"]
        and all(s["tau"] in (0.6, 0.9, 1.4, 1.8) for s in st)
        and isinstance(bursts[0], bool) and any(bursts)
        and anti["subdisciplines_touched"] >= 2 and anti["macro_domains_touched"] >= 2
        and len(far) == 5 and far[0]["cos"] <= 0.02
        and gone["ok"] and len(caps_after) == 0 and re["ok"]
        and spec.LOCK_SUBD * 10 + spec.LOCK_SUBD_RESERVED == 1331
        and spec.LOCK_SUBD * 855 + spec.LOCK_SUBD_COORD == 108641
    )
    _check("G14 冷热插拔(SD-Distill/热装不重启/卸载回滚/非侵入)", ok,
           f"caps={len(caps)} skc={run['S6']['skcs']} committed={run['S7']['committed']} "
           f"digest={before}")


def run() -> dict:
    global RESULT, ASSERTS
    RESULT, ASSERTS = [], []
    for fn in (g1_identity, g2_locks, g3_heartbeat_spec, g4_threadbus, g5_heartbeat_run,
               g6_cytoskeleton, g7_skin, g8_gate, g9_semantic, g10_knowledge_csv,
               g11_protocols_subjects, g12_tensor_forge_interop, g13_hebbian_host,
               g14_plugin_host):
        fn()
    return {n: ok for n, ok, _ in RESULT}


def main() -> int:
    print("=" * 72)
    print("认知主权 Cognitive Sovereignty 1331×1331 多智能体矩阵 V3.1 自检 G1-G14")
    print("=" * 72)
    groups = run()
    for name, ok, detail in RESULT:
        print(f"[{'PASS' if ok else 'FAIL'}] {name}{('  ' + detail) if detail else ''}")
    n_pass = sum(1 for v in groups.values() if v)
    print("-" * 72)
    print(f"自检: {n_pass}/{len(groups)} 组 PASS | 断言 {sum(ASSERTS)}/{len(ASSERTS)} 通过")
    return 0 if n_pass == len(groups) else 1


if __name__ == "__main__":
    sys.exit(main())
