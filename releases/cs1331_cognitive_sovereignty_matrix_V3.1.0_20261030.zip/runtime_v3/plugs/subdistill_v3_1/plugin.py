# -*- coding: utf-8 -*-
"""
SD-Distill 亚学科辅助蒸馏模块 · 插件实现（V3.1.0）
==============================================================
本文件是"冷热插拔"的那个插件本体：宿主只调用 register(ctx, payload_dir)，
插件通过 ctx.provide(...) 交出 10 项能力，其余一律自洽，不读宿主内部状态。

结构（与投喂规格一一对应）：
  127 亚学科分类体系   → Taxonomy        （127 维稀疏签名 / nearest / far_pairs）
  辅助教师库           → TeacherBank     （语料锚点/概念卡/关系模板/提问范式/反例/置信度）
  七阶段蒸馏管线       → DistillationPipeline（S1 采集 → S7 验证入库）
  七项辅助损失         → LossBank        （α0.30 β0.20 γ0.15 δ0.20 ε0.08 ζ0.05 η0.02）
  温度与课程           → CurriculumScheduler（C1 0.6 / C2 0.9 / C3 1.4 / C4 1.8 + 冲击 2.5）
  反标签指标           → AntiLabelScorer （标签熵 / 跳跃度 / 不可压缩度）
  亚学科知识卡         → SKCStore        （schema 校验 + 皮肤门 + 心跳纪元）

全部确定性：同样的输入 → 同样的 SKC 与同样的分类签名，无随机、无网络、无第三方库。
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from typing import Dict, List, Sequence

# ----------------------------------------------------------------- 锁数（维度不变）
LOCKS = {
    "subdisciplines": 127,
    "domains": 16,
    "matrix_slots": 1270,          # 127 × 10
    "reserved_slots": 61,
    "matrix_total": 1331,          # 1270 + 61
    "nodes": 108585,               # 127 × 855
    "global_coordinator_nodes": 56,
    "nodes_total": 108641,         # 108585 + 56
    "losses": 7,
    "stages": 7,
    "curriculum_stages": 4,
    "resonance_seed_pairs": 50,
}
LOSS_WEIGHTS = {"alpha": 0.30, "beta": 0.20, "gamma": 0.15, "delta": 0.20,
                "epsilon": 0.08, "zeta": 0.05, "eta": 0.02}
CURRICULUM = [("C1_root", "single", 0.6, 200), ("C2_neighbor", "same_domain", 0.9, 300),
              ("C3_far", "cross_domain", 1.4, 400), ("C4_multi", "multi_domain", 1.8, 300)]
BURST = {"probability": 0.05, "tau": 2.5, "duration_epochs": 2}
GATED_DOMAINS = ("MED", "TCM")
FORBIDDEN_ASSERTIONS = ("诊断", "处方", "疗效承诺")
RELATION_TYPES = ("is_a", "part_of", "maps_to", "contradicts", "analogizes", "constrains")
DISCLAIMER = "仅作为知识框架与跨学科映射探讨，不构成诊疗建议"


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _cos(a: Dict[str, float], b: Dict[str, float]) -> float:
    if not a or not b:
        return 0.0
    dot = sum(v * b.get(k, 0.0) for k, v in a.items())
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    return 0.0 if na == 0 or nb == 0 else dot / (na * nb)


def _softmax(logits: Dict[str, float], tau: float) -> Dict[str, float]:
    t = max(tau, 1e-6)
    mx = max(logits.values())
    ex = {k: math.exp((v - mx) / t) for k, v in logits.items()}
    s = sum(ex.values())
    return {k: round(v / s, 6) for k, v in ex.items()}


def _entropy(dist: Dict[str, float]) -> float:
    tot = sum(dist.values())
    if tot <= 0:
        return 0.0
    h = 0.0
    for v in dist.values():
        p = v / tot
        if p > 0:
            h -= p * math.log(p)
    return round(h, 6)


# ----------------------------------------------------------------- 127 亚学科
class Taxonomy:
    def __init__(self, data: dict):
        self.items = {i["code"]: i for i in data["items"]}
        if len(self.items) != LOCKS["subdisciplines"]:
            raise ValueError(f"亚学科应为 127，实际 {len(self.items)}")
        self.by_domain: Dict[str, List[str]] = {}
        for code in sorted(self.items):
            self.by_domain.setdefault(self.items[code]["domain"], []).append(code)
        self.domains = sorted(self.by_domain)
        if len(self.domains) != LOCKS["domains"]:
            raise ValueError(f"宏观域应为 16，实际 {len(self.domains)}")

    @classmethod
    def from_file(cls, path: str) -> "Taxonomy":
        with open(path, "r", encoding="utf-8") as f:
            return cls(json.load(f))

    # 词汇表：seed 词 + 名称按"与"切分的片段
    def _vocab(self, code: str) -> List[str]:
        it = self.items[code]
        voc = list(it["seeds"]) + [p for p in it["name"].split("与") if p] + [it["name"]]
        return voc

    def encode(self, text: str) -> Dict[str, float]:
        """127 维稀疏签名：命中种子词得 1 分、命中名称片段得 0.6 分，L1 归一。"""
        raw: Dict[str, float] = {}
        for code in sorted(self.items):
            s = 0.0
            for v in self._vocab(code):
                if v and v in text:
                    s += 0.6 if v == self.items[code]["name"] else 1.0
            if s > 0:
                raw[code] = s
        if not raw:
            return {}
        tot = sum(raw.values())
        return {c: round(s / tot, 6) for c, s in sorted(raw.items())}

    def top(self, text: str, k: int = 3) -> List[str]:
        sig = self.encode(text)
        ranked = sorted(sig.items(), key=lambda kv: (-kv[1], kv[0]))
        return [c for c, _ in ranked[:k]]

    def nearest(self, code: str, k: int = 5) -> List[dict]:
        if code not in self.items:
            return []
        base = self.encode(self.items[code]["name"] + " " + " ".join(self.items[code]["seeds"]))
        dom = self.items[code]["domain"]
        scored = []
        for other in sorted(self.items):
            if other == code:
                continue
            sig = self.encode(self.items[other]["name"] + " " + " ".join(self.items[other]["seeds"]))
            c = _cos(base, sig)
            same = 1 if self.items[other]["domain"] == dom else 0
            scored.append((round(c, 6), same, other))
        scored.sort(key=lambda t: (-t[0], -t[1], t[2]))
        return [{"code": c, "cos": v, "same_domain": bool(s)} for v, s, c in scored[:k]]

    def far_pairs(self, min_cos: float = 0.05, limit: int = 200) -> List[dict]:
        sigs = {}
        for code in sorted(self.items):
            it = self.items[code]
            sigs[code] = self.encode(it["name"] + " " + " ".join(it["seeds"]))
        out = []
        codes = sorted(self.items)
        for i, a in enumerate(codes):
            for b in codes[i + 1:]:
                if self.items[a]["domain"] == self.items[b]["domain"]:
                    continue
                c = _cos(sigs[a], sigs[b])
                if c <= min_cos:
                    out.append({"a": a, "b": b, "cos": round(c, 6)})
        out.sort(key=lambda d: (d["cos"], d["a"], d["b"]))
        return out[:limit]

    def signature_dim(self) -> int:
        return LOCKS["subdisciplines"]


# ----------------------------------------------------------------- 共振种子
class ResonanceSeed:
    def __init__(self, data: dict):
        self.pairs = data["pairs"]
        if len(self.pairs) != LOCKS["resonance_seed_pairs"]:
            raise ValueError(f"共振种子应为 50，实际 {len(self.pairs)}")

    @classmethod
    def from_file(cls, path: str) -> "ResonanceSeed":
        with open(path, "r", encoding="utf-8") as f:
            return cls(json.load(f))

    def by_code(self, code: str) -> List[dict]:
        return [p for p in self.pairs if p["a"] == code or p["b"] == code]


# ----------------------------------------------------------------- 辅助教师库
class TeacherBank:
    """辅助教师四件套：语料锚点 / 概念卡 / 关系模板 / 提问范式 + 反例 + 置信度。"""

    def __init__(self, tax: Taxonomy, res: ResonanceSeed):
        self.tax = tax
        self.res = res

    def get(self, code: str) -> dict:
        it = self.tax.items[code]
        pairs = self.res.by_code(code)
        conf = round(sum(p["confidence"] for p in pairs) / len(pairs), 4) if pairs else 0.5
        gated = it["domain"] in GATED_DOMAINS
        card = {
            "code": code,
            "name": it["name"],
            "domain": it["domain"],
            "corpus_anchors": [f"{it['domain_cn']}/{it['name']}/ch{_i + 1:02d}" for _i in range(3)],
            "concept_cards": 60 + 7 * len(it["seeds"]),
            "relation_templates": [f"{p['type']} ↔ {self.tax.items[p['b']]['name']}"
                                   for p in pairs[:3]],
            "question_paradigms": [
                f"把 {{{it['seeds'][0]}}} 视为 {{{it['domain_cn']}}} 中的对象，其 {{{it['seeds'][-1]}}} 对应什么？",
                f"{it['name']} 在 {{远域亚学科}} 视角下是否构成 {{同构}}？",
            ],
            "counterexamples": [p["counterexample"] for p in pairs[:2]] or ["本域内类比需先给反例"],
            "confidence": conf,
            "teacher_type": "TemplateTeacher",
            "safety_gate": "skin.medical_disclaimer" if gated else None,
            "disclaimer_required": gated,
        }
        return card

    def all_cards(self) -> List[dict]:
        return [self.get(c) for c in sorted(self.tax.items)]


# ----------------------------------------------------------------- 七阶段管线
DEMO_CATALOGS = [
    {"title": "优化设计（教材目录骨架）", "lines": [
        "# 第1章 优化设计概论",
        "## 1.1 优化问题的数学表述",
        "### 1.1.1 目标函数与约束",
        "## 1.2 凸性与变分法",
        "# 第2章 无约束优化",
        "## 2.1 梯度与牛顿法",
        "## 2.2 收敛性与数值稳定性",
    ]},
    {"title": "电力电子技术（教材目录骨架）", "lines": [
        "# 第1章 电力电子器件",
        "## 1.1 开关器件与驱动",
        "# 第2章 整流与逆变",
        "## 2.1 拓扑与调制",
        "## 2.2 能量回馈与效率",
    ]},
    {"title": "范畴论与对齐（自有笔记骨架）", "lines": [
        "# 范畴论与同调",
        "## 伴随函子的单位与余单位",
        "## 极限与余极限的构造",
        "# 大模型与对齐",
        "## 偏好优化的对偶权衡",
        "## RLHF 的奖励建模",
        "# 证明论与类型论",
        "## 构造性证明与不可判定性",
    ]},
]


class DistillationPipeline:
    def __init__(self, tax: Taxonomy, teachers: TeacherBank, res: ResonanceSeed):
        self.tax = tax
        self.teachers = teachers
        self.res = res

    # S1 采集
    def acquire(self, sources: Sequence[dict]) -> dict:
        docs = []
        for src in sources:
            lines = [ln.rstrip() for ln in src.get("lines", []) if ln.strip()]
            docs.append({"title": src.get("title", ""), "lines": lines,
                         "hash": _sha(src.get("title", "") + "\n".join(lines))[:16]})
        return {"docs": len(docs), "lines": sum(len(d["lines"]) for d in docs),
                "source_hash": _sha("|".join(d["hash"] for d in docs))[:16], "detail": docs}

    # S2 结构化（目录即概念树骨架）
    @staticmethod
    def _depth(line: str) -> tuple:
        s = line.lstrip()
        if s.startswith("#"):
            k = len(s) - len(s.lstrip("#"))
            return k, s.lstrip("#").strip()
        head = s.split(" ", 1)[0].rstrip(".")
        if head and all(p.isdigit() for p in head.split(".") if p):
            return head.count(".") + 1, s
        return 4, s

    def parse(self, corpus: dict) -> dict:
        nodes = []
        for doc in corpus["detail"]:
            for line in doc["lines"]:
                depth, text = self._depth(line)
                subs = self.tax.top(text, 2)
                nodes.append({"term": text, "depth": depth, "doc": doc["title"],
                              "subdisciplines": subs, "primary": subs[0] if subs else None})
        primary = [n["primary"] for n in nodes if n["primary"]]
        return {"nodes": nodes, "count": len(nodes),
                "classified": len(primary), "coverage": round(len(primary) / max(len(nodes), 1), 4),
                "codes": sorted(set(primary))}

    # S3 概念抽取
    def extract_concepts(self, tree: dict) -> List[dict]:
        out = []
        for n in tree["nodes"]:
            sub = self.teachers.get(n["primary"]) if n["primary"] else None
            out.append({
                "term": n["term"],
                "subdiscipline": n["primary"],
                "depth": n["depth"],
                "definition": f"由《{n['doc']}》目录层级定位的概念节点（骨架填充，待人工补定义）",
                "examples": [],
                "counterexamples": (sub["counterexamples"][:1] if sub else []),
                "provenance": n["doc"],
            })
        return out

    # S4 关系抽取
    def extract_relations(self, concepts: List[dict]) -> dict:
        edges = []
        for i, c in enumerate(concepts):
            for prev in reversed(concepts[:i]):
                if prev["depth"] < c["depth"]:
                    edges.append({"type": "part_of", "head": c["term"], "tail": prev["term"],
                                  "confidence": 0.92})
                    break
        for c in concepts:
            if c["subdiscipline"]:
                edges.append({"type": "is_a", "head": c["term"],
                              "tail": self.tax.items[c["subdiscipline"]]["name"],
                              "confidence": 0.8})
        return {"edges": edges, "count": len(edges),
                "types": sorted({e["type"] for e in edges})}

    # S5 跨域对齐（同构验证 + 反例否决）
    def align(self, graph: dict, tree: dict) -> dict:
        codes = set(tree["codes"])
        units = []
        for p in self.res.pairs:
            if p["a"] in codes and p["b"] in codes:
                units.append({
                    "seed_id": p["id"], "a": p["a"], "b": p["b"], "type": p["type"],
                    "confidence": p["confidence"], "counterexample": p["counterexample"],
                    "verified": False, "note": "同构待人工确认；置信度<0.5 只可称隐喻",
                })
        return {"units": units, "count": len(units),
                "pairs_used": sorted({u["seed_id"] for u in units})}

    # S6 蒸馏（温度调度 + 抗标签变体）
    def distill(self, table: dict, tau: float, epoch: int = 0) -> List[dict]:
        skcs = []
        for idx, u in enumerate(table["units"], start=1):
            a, b = self.tax.items[u["a"]], self.tax.items[u["b"]]
            logits = {u["type"]: u["confidence"],
                      "maps_to": u["confidence"] * 0.72,
                      "analogizes": max(u["confidence"] - 0.15, 0.05),
                      "仅为隐喻": 1.0 - u["confidence"]}
            soft = _softmax(logits, tau)
            anti = round(1 - max(soft.values()), 4)
            retriev = round(min(1.0, len(b["seeds"]) / 3.0), 4)
            template = (f"在{{{a['name']}}}视角下，{{{b['name']}}}中的{{{b['seeds'][0]}}}"
                        f"是否可视为一对{{{a['seeds'][0]}}}？若成立，其工程约束与反例分别是什么？")
            gated = a["domain"] in GATED_DOMAINS or b["domain"] in GATED_DOMAINS
            skcs.append({
                "skc_id": f"SKC-{u['a'].replace('-', '')}-{u['b'].replace('-', '')}-{idx:04d}",
                "subdisciplines": [u["a"], u["b"]],
                "signature_dim": LOCKS["subdisciplines"],
                "signature_sparse": {u["a"]: round(u["confidence"], 4),
                                     u["b"]: round(u["confidence"] * 0.9, 4)},
                "concepts": [
                    {"term": a["seeds"][0], "domain": u["a"], "definition": "教师库种子概念",
                     "examples": [], "counterexamples": [u["counterexample"]]},
                    {"term": b["seeds"][0], "domain": u["b"], "definition": "教师库种子概念",
                     "examples": [], "counterexamples": []},
                ],
                "relations": [{"type": u["type"], "head": a["seeds"][0], "tail": b["seeds"][0],
                               "confidence": u["confidence"]}],
                "query_templates": [{"template": template, "temperature": tau,
                                     "anti_label_score": anti, "retrievability": retriev}],
                "soft_labels": soft,
                "provenance": [{"source": "共振种子 + 教材目录骨架", "hash": u["seed_id"]}],
                "safety": ({"gate": "skin.medical_disclaimer", "disclaimer_required": True,
                            "forbidden_assertions": list(FORBIDDEN_ASSERTIONS), "note": DISCLAIMER}
                           if gated else {"gate": "skin.programmatic_analogy", "disclaimer_required": False,
                                          "forbidden_assertions": list(FORBIDDEN_ASSERTIONS),
                                          "note": "跨域类比必须带反例，不得表述为已验证结论"}),
                "version": "0.1.0",
                "heartbeat_epoch": epoch,
            })
        return skcs

    # S7 验证入库（皮肤门 + 心跳广播 + 去重）
    def commit(self, skcs: List[dict], gate=None, epoch: int = 0) -> dict:
        seen, kept, blocked, warned = set(), [], [], []
        for s in skcs:
            if s["skc_id"] in seen:
                continue
            seen.add(s["skc_id"])
            text = " ".join([t["template"] for t in s["query_templates"]]
                            + [s["relations"][0]["head"], s["relations"][0]["tail"]])
            if gate is not None:
                g = gate.pipeline(text)
                if not g["gate"]["allowed"]:
                    blocked.append({"skc_id": s["skc_id"], "veto": g["gate"]["veto"]})
                    continue
            if s["safety"]["disclaimer_required"]:
                warned.append(s["skc_id"])
            kept.append(s)
        return {"committed": len(kept), "blocked": len(blocked), "dedup": len(skcs) - len(seen),
                "gated": len(warned), "epoch": epoch, "blocked_detail": blocked}

    def run(self, sources=None, tau: float = 1.4, gate=None, epoch: int = 0) -> dict:
        sources = sources if sources is not None else DEMO_CATALOGS
        corpus = self.acquire(sources)
        tree = self.parse(corpus)
        concepts = self.extract_concepts(tree)
        graph = self.extract_relations(concepts)
        table = self.align(graph, tree)
        skcs = self.distill(table, tau, epoch)
        report = self.commit(skcs, gate, epoch)
        conc_cov = len([c for c in concepts if c["subdiscipline"]]) / max(len(concepts), 1)
        return {
            "S1": {"docs": corpus["docs"], "lines": corpus["lines"]},
            "S2": {"nodes": tree["count"], "classified": tree["classified"],
                   "coverage": tree["coverage"], "codes": tree["codes"]},
            "S3": {"concepts": len(concepts), "coverage": round(conc_cov, 4)},
            "S4": {"edges": graph["count"], "types": graph["types"]},
            "S5": {"units": table["count"], "pairs_used": table["pairs_used"]},
            "S6": {"skcs": len(skcs), "tau": tau, "sample": skcs[0] if skcs else None},
            "S7": report,
            "skcs": skcs,
            "simulated": True,
        }


# ----------------------------------------------------------------- 七项辅助损失
class LossBank:
    def __init__(self, weights: Dict[str, float] | None = None):
        self.w = dict(weights or LOSS_WEIGHTS)

    @staticmethod
    def fidelity(covered: int, total: int) -> float:
        return round(1.0 - covered / max(total, 1), 6)

    @staticmethod
    def relation(tp: int, fp: int, fn: int) -> float:
        prec = tp / max(tp + fp, 1)
        rec = tp / max(tp + fn, 1)
        f1 = 0.0 if prec + rec == 0 else 2 * prec * rec / (prec + rec)
        return round(1.0 - f1, 6)

    @staticmethod
    def cross(mappable_p: float) -> float:
        p = min(max(mappable_p, 1e-6), 1 - 1e-6)
        return round(-math.log(1 - p), 6)

    @staticmethod
    def novel(dist: Dict[str, float], max_hist_cos: float, lam: float = 0.5) -> float:
        return round(-_entropy(dist) + lam * max_hist_cos, 6)

    @staticmethod
    def retrievability_failure(retrievability: float) -> float:
        return round(1.0 - min(max(retrievability, 0.0), 1.0), 6)

    @staticmethod
    def safety(hits: int, assertion_risk: float) -> float:
        return round(min(1.0, hits * 0.5 + assertion_risk), 6)

    @staticmethod
    def cost(tokens: int, latency_ms: float, cap_tokens: int = 4096,
             cap_ms: float = 2000.0) -> float:
        return round(min(1.0, tokens / cap_tokens * 0.6 + latency_ms / cap_ms * 0.4), 6)

    def eval(self, measured: dict) -> dict:
        parts = {
            "alpha_fid": self.fidelity(measured.get("covered", 0), measured.get("total", 1)),
            "beta_rel": self.relation(measured.get("tp", 0), measured.get("fp", 0),
                                      measured.get("fn", 0)),
            "gamma_cross": self.cross(measured.get("mappable_p", 0.5)),
            "delta_novel": self.novel(measured.get("dist", {"a": 1.0}),
                                      measured.get("max_hist_cos", 0.0)),
            "epsilon_retr": self.retrievability_failure(measured.get("retrievability", 0.5)),
            "zeta_safe": self.safety(measured.get("gate_hits", 0),
                                     measured.get("assertion_risk", 0.0)),
            "eta_cost": self.cost(measured.get("tokens", 512), measured.get("latency_ms", 20.0)),
        }
        total = (self.w["alpha"] * parts["alpha_fid"] + self.w["beta"] * parts["beta_rel"]
                 + self.w["gamma"] * parts["gamma_cross"] + self.w["delta"] * parts["delta_novel"]
                 + self.w["epsilon"] * parts["epsilon_retr"] + self.w["zeta"] * parts["zeta_safe"]
                 + self.w["eta"] * parts["eta_cost"])
        return {"parts": parts, "total": round(total, 6), "weights": self.w,
                "adaptive_weights": True, "note": "权重在真实部署中由赫布场在线调整；本包只给确定性基线"}


# ----------------------------------------------------------------- 温度课程
class CurriculumScheduler:
    def __init__(self, seed: str = "0"):
        self.seed = seed
        self.bounds = []
        acc = 0
        for name, scope, tau, ep in CURRICULUM:
            acc += ep
            self.bounds.append((acc, name, scope, tau, ep))
        self.total_epochs = acc

    def stage(self, epoch: int) -> dict:
        e = max(int(epoch), 0) % self.total_epochs
        for bound, name, scope, tau, ep in self.bounds:
            if e < bound:
                start = bound - ep
                return {"name": name, "scope": scope, "tau": tau, "epochs": ep,
                        "epoch": e, "window": [start, bound - 1]}
        return {"name": "C4_multi", "scope": "multi_domain", "tau": 1.8, "epochs": 300,
                "epoch": e, "window": [self.total_epochs - 300, self.total_epochs - 1]}

    def burst(self, epoch: int) -> bool:
        """确定性温度冲击：p=0.05、τ=2.5、持续 2 epoch。"""
        h = int(_sha(f"{self.seed}:{int(epoch)}")[:8], 16)
        if h % 100 >= int(BURST["probability"] * 100):
            return False
        probe = int(epoch)
        for back in range(BURST["duration_epochs"]):
            hh = int(_sha(f"{self.seed}:{probe - back}")[:8], 16)
            if hh % 100 < int(BURST["probability"] * 100):
                return True
        return False


# ----------------------------------------------------------------- 反标签指标
class AntiLabelScorer:
    def entropy(self, profile: Dict[str, float]) -> float:
        return _entropy(profile)

    def dominant(self, profile: Dict[str, float]) -> float:
        tot = sum(profile.values())
        return 0.0 if tot <= 0 else round(max(profile.values()) / tot, 6)

    def jump_score(self, signatures: Sequence[Dict[str, float]]) -> float:
        if len(signatures) < 2:
            return 0.0
        vals = [1.0 - _cos(signatures[i], signatures[i + 1]) for i in range(len(signatures) - 1)]
        return round(sum(vals) / len(vals), 6)

    def incompressibility(self, query_sig: Dict[str, float],
                          history: Sequence[Dict[str, float]]) -> float:
        if not history:
            return 1.0
        return round(1.0 - max(_cos(query_sig, h) for h in history), 6)

    def report(self, queries: Sequence[Dict[str, float]], history=()) -> dict:
        prof: Dict[str, float] = {}
        for sig in queries:
            for k, v in sig.items():
                prof[k] = prof.get(k, 0.0) + v
        return {
            "tag_entropy": self.entropy(prof),
            "dominant_weight": self.dominant(prof),
            "jump_score": self.jump_score(queries),
            "incompressibility": round(sum(self.incompressibility(q, history) for q in queries)
                                       / max(len(queries), 1), 6),
            "subdisciplines_touched": len(prof),
            "macro_domains_touched": len({k.split("-")[0] for k in prof}),
        }


# ----------------------------------------------------------------- SKC 校验
SKC_REQUIRED = ("skc_id", "subdisciplines", "signature_dim", "signature_sparse", "concepts",
                "relations", "query_templates", "soft_labels", "provenance", "safety",
                "version", "heartbeat_epoch")


def validate_skc(skc: dict) -> dict:
    errs = [f"缺字段 {k}" for k in SKC_REQUIRED if k not in skc]
    if skc.get("signature_dim") not in (None, LOCKS["subdisciplines"]):
        errs.append(f"signature_dim 应为 127，实际 {skc.get('signature_dim')}")
    for r in skc.get("relations", []):
        if r.get("type") not in RELATION_TYPES:
            errs.append(f"未知关系类型 {r.get('type')}")
        if r.get("type") == "analogizes" and not any(c.get("counterexamples")
                                                     for c in skc.get("concepts", [])):
            errs.append("analogizes 缺反例")
    safety = skc.get("safety", {})
    if any(d in ("MED", "TCM") for d in skc.get("subdisciplines", [])):
        if safety.get("disclaimer_required") is not True:
            errs.append("MED/TCM 未强制免责声明")
        for bad in FORBIDDEN_ASSERTIONS:
            if bad in json.dumps(skc, ensure_ascii=False):
                errs.append(f"出现禁用断言词 {bad}")
    return {"ok": not errs, "errors": errs}


# ----------------------------------------------------------------- 注册入口
def register(ctx, payload_dir: str) -> dict:
    tax = Taxonomy.from_file(os.path.join(payload_dir, "taxonomy_127.json"))
    res = ResonanceSeed.from_file(os.path.join(payload_dir, "resonance_seed_50.json"))
    teachers = TeacherBank(tax, res)
    pipeline = DistillationPipeline(tax, teachers, res)
    losses = LossBank()
    sched = CurriculumScheduler(seed=str(ctx.manifest.get("version", "0")))
    scorer = AntiLabelScorer()

    ctx.provide("taxonomy", tax)
    ctx.provide("taxonomy.encode", tax.encode)
    ctx.provide("taxonomy.nearest", tax.nearest)
    ctx.provide("taxonomy.far_pairs", tax.far_pairs)
    ctx.provide("teacher.get", teachers.get)
    ctx.provide("pipeline.run", pipeline.run)
    ctx.provide("losses.eval", losses.eval)
    ctx.provide("curriculum.stage", sched.stage)
    ctx.provide("curriculum.burst", sched.burst)
    ctx.provide("antilabel.score", scorer.report)
    ctx.provide("skc.validate", validate_skc)
    ctx.provide("demo", lambda gate=None, epoch=0: pipeline.run(tau=1.4, gate=gate, epoch=epoch))

    checks = {
        "subdisciplines": len(tax.items),
        "domains": len(tax.domains),
        "slots_ok": LOCKS["subdisciplines"] * 10 + LOCKS["reserved_slots"] == LOCKS["matrix_total"],
        "nodes_ok": (LOCKS["subdisciplines"] * 855 + LOCKS["global_coordinator_nodes"]
                     == LOCKS["nodes_total"]),
        "losses_sum": round(sum(LOSS_WEIGHTS.values()), 6),
        "resonance_pairs": len(res.pairs),
    }
    ctx.note(f"SD-Distill 装载：{len(tax.items)} 亚学科 / {len(tax.domains)} 宏观域")
    return {"id": ctx.manifest.get("id"), "checks": checks}


def unregister(ctx) -> dict:
    """卸载：清空能力，不动宿主任何状态（回滚即可逆）。"""
    n = len(ctx.caps)
    ctx.caps.clear()
    return {"cleared": n}
