# -*- coding: utf-8 -*-
"""
认知主权矩阵 V3.1 —— 命令行入口
用法（在本目录执行）：
  python main.py --version / --tensor / --forge / --anti / --interop / --host
  python main.py --knowledge / --heartbeat / --hebb / --run / --selftest / --redline
  python main.py --plugs                 # 列出可插拔插件（冷装状态）
  python main.py --plug-hot subdistill   # 运行期热装（不重启）
  python main.py --plug-off subdistill   # 卸载回滚
  python main.py --subdistill            # 冷装 + 跑 S1-S7 全流程（含 SKC 与损失）
"""
from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from so1331_runtime import (  # noqa: E402
    spec, HyperSpace, LogicGrid, KalmanChannels, HilbertLayers, MandalaSpace, encode_all,
    QueryForge, OntologyGraph, CORE_PROMPTS, AntiLabelEngine, OfflineInjector,
    ProtocolFusion, PlatformRegistry, Knowledge, HeartbeatHub, HebbianField, SovereignHost,
    SkinGate, PluginHost,
)


def _dump(title: str, obj) -> None:
    print("=" * 72)
    print(title)
    print("=" * 72)
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def cmd_version() -> int:
    print(f"矩阵 ID : {spec.MATRIX_ID}")
    print(f"运行时  : {spec.RUNTIME_ID}")
    print(f"协议    : {spec.PROTOCOL_ID}（{spec.BUS_ID} / {spec.THREADBUS_ID}，域 {spec.DOMAIN}）")
    print(f"版本    : {spec.VERSION}  {spec.DATE}")
    print(f"心跳    : {spec.HEARTBEAT_BASE}-{spec.HEARTBEAT_BASE + spec.HEARTBEAT_COUNT - 1}")
    print(f"密令    : {spec.SECRET_OPEN}，{spec.SECRET_CLOSE}")
    print("锁数    : " + json.dumps(spec.lock_check(), ensure_ascii=False))
    return 0


def cmd_tensor() -> int:
    _dump("R0 张量向量化（超向量/逻辑网格/卡尔曼/希尔伯特/曼陀罗）", encode_all())
    hs = HyperSpace()
    from so1331_runtime.tensor import cosine
    triple = hs.encode("数学", "映射到", "人工智能")
    _dump("三元组编码示例（可复现·可解绑）", {
        "dim": hs.dim,
        "recover_cosine": round(cosine(hs.recover(triple, "映射到"), hs.get("数学")), 4),
        "cross_cosine": round(hs.similarity("数学", "人工智能"), 4),
        "simulated": True,
    })
    return 0


def cmd_forge() -> int:
    f = QueryForge()
    out = {
        "verify": f.verify(),
        "core_prompts": len(CORE_PROMPTS),
        "samples": [f.generate(str(i), k=3 + i % 2) for i in range(3)],
        "identity": f.identity_statement("0"),
        "plan_3days": f.plan("0", 3, 2),
        "simulated": True,
    }
    _dump("R1 锻造域（跨域查询 + 身份自述 + 不可预测计划表）", out)
    return 0


def cmd_anti() -> int:
    a = AntiLabelEngine(observations=["推荐里约七成是搞笑短视频", "偶尔推明星八卦"])
    inj = OfflineInjector()
    out = {
        "verify": a.verify(),
        "labels": a.infer_labels(),
        "plan": a.disruption_plan(),
        "injector_modes": inj.modes(),
        "batch": inj.build("batch", "1", ["抖音", "Bilibili", "知乎"]),
        "simulated": True,
    }
    _dump("R2 策略域（反标签计划 + 五模式离线清单，全部 human_manual）", out)
    return 0


def cmd_interop() -> int:
    pf = ProtocolFusion()
    reg = PlatformRegistry()
    out = {
        "verify": pf.verify(),
        "inner": [{"key": p[0], "name": p[1], "ops": list(p[2])} for p in pf.inner],
        "outer": [{"key": p[0], "name": p[1], "members": list(p[2])} for p in pf.outer],
        "platforms": [{"family": f[1], "members": list(f[2])} for f in reg.families],
        "registry": reg.verify(),
        "simulated": True,
    }
    _dump("R3 互操作域（23 协议族 + 10 平台族 / 168 分身 / 70 执行体）", out)
    return 0


def cmd_knowledge() -> int:
    k = Knowledge()
    _dump("四表台账", {
        "verify": k.verify(),
        "protocols": k.protocols(),
        "subjects": {"origin": k.subjects()["origin_count"],
                     "fusion": k.subjects()["fusion_count"],
                     "total": k.subjects()["total"]},
        "cases_by_cat": {c: sum(1 for x in k.cases_list() if x["category"] == c)
                         for c in spec.CASE_CATEGORIES},
    })
    return 0


def cmd_heartbeat() -> int:
    hub = HeartbeatHub()
    for _ in range(3):
        hub.run_round()
    _dump("全息心跳（70 体 / 9700-9769 / 768 维 / α0.18）",
          {"scan": hub.scan(), "holo": hub.holographic()})
    return 0


def cmd_hebb() -> int:
    h = HebbianField()
    h.coactivate(["tensor_vector_encoding", "query_forging", "compliance_gate"])
    _dump("赫布协作场（生命之花 19 圆 / 17 节点 / 42 几何边 / 28 流边）",
          {"verify": h.verify(), "summary": h.summary(),
           "strongest_query_forging": h.strongest("query_forging", 5)})
    return 0


def cmd_run() -> int:
    host = SovereignHost("0")
    rd = host.run_round()
    _dump(f"R0-R4 五阶闭环 · 第 {rd['round']} 轮（全程 simulated）", rd)
    return 0


def cmd_selftest() -> int:
    import selftest
    return selftest.main()


def cmd_redline() -> int:
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "tools"))
    import redline_scan
    return redline_scan.main()


def cmd_plugs() -> int:
    ph = PluginHost(os.path.dirname(os.path.abspath(__file__)), skin=SkinGate())
    cold = ph.cold_boot()
    _dump("插件宿主 · 冷装清单（manifests 扫描 + bootstrap 装载）",
          {"cold_boot": cold, "status": ph.status()})
    return 0


def _plug_host() -> PluginHost:
    return PluginHost(os.path.dirname(os.path.abspath(__file__)), skin=SkinGate())


def cmd_plug_hot(pid: str) -> int:
    ph = _plug_host()
    res = ph.hot_load(pid)
    _dump(f"热装 {pid}（运行期现场装载，不重启宿主）", {"load": res, "status": ph.status()})
    return 0 if res.get("ok") else 1


def cmd_plug_off(pid: str) -> int:
    ph = _plug_host()
    rec = ph.hot_load(pid)
    res = ph.hot_unload(pid)
    _dump(f"卸载回滚 {pid}", {"load": rec, "unload": res})
    return 0 if res.get("ok") else 1


def cmd_subdistill() -> int:
    ph = _plug_host()
    cold = ph.cold_boot()
    caps = ph.capabilities()
    run = caps["pipeline.run"](tau=1.4, gate=SkinGate(), epoch=1)
    loss = caps["losses.eval"]({"covered": run["S3"]["concepts"] - 6,
                                "total": run["S3"]["concepts"], "tp": run["S4"]["edges"],
                                "fp": 2, "fn": 1, "mappable_p": 0.6,
                                "dist": {"跨域同构": 0.5, "形式化可行": 0.3, "仅为隐喻": 0.2},
                                "max_hist_cos": 0.25, "retrievability": 0.7, "gate_hits": 0,
                                "tokens": 1200, "latency_ms": 40.0})
    stages = [caps["curriculum.stage"](e) for e in (0, 250, 600, 1100)]
    _dump("SD-Distill 亚学科辅助蒸馏（127 亚学科 · S1-S7 · 七项损失 · 温度课程）", {
        "cold_boot": cold,
        "locks": {"subdisciplines": spec.LOCK_SUBD, "domains": spec.LOCK_SUBD_DOMAINS,
                  "slots": spec.LOCK_SUBD_SLOTS, "reserved": spec.LOCK_SUBD_RESERVED,
                  "nodes": spec.LOCK_SUBD_NODES, "coord": spec.LOCK_SUBD_COORD},
        "stages": {k: run[k] for k in ("S1", "S2", "S3", "S4", "S5", "S6", "S7")},
        "sample_skc": run["skcs"][0] if run["skcs"] else None,
        "loss": loss,
        "curriculum": [{"name": s["name"], "tau": s["tau"], "window": s["window"]} for s in stages],
        "antilabel": caps["antilabel.score"]([
            caps["taxonomy.encode"]("范畴论 与 大模型对齐 伴随函子"), 
            caps["taxonomy.encode"]("经络 与 生物物理 相干态")]),
        "simulated": True,
    })
    return 0


def main(argv) -> int:
    if not argv:
        print(__doc__)
        return 0
    flag = argv[0]
    arg = argv[1] if len(argv) > 1 else "subdistill"
    table = {
        "--version": cmd_version, "--tensor": cmd_tensor, "--forge": cmd_forge,
        "--anti": cmd_anti, "--interop": cmd_interop, "--knowledge": cmd_knowledge,
        "--heartbeat": cmd_heartbeat, "--hebb": cmd_hebb, "--host": cmd_run,
        "--run": cmd_run, "--selftest": cmd_selftest, "--redline": cmd_redline,
        "--plugs": cmd_plugs, "--plug-hot": (lambda: cmd_plug_hot(arg)),
        "--plug-off": (lambda: cmd_plug_off(arg)), "--subdistill": cmd_subdistill,
    }
    if flag not in table:
        print(f"未知参数：{flag}")
        print(__doc__)
        return 2
    return table[flag]()


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
