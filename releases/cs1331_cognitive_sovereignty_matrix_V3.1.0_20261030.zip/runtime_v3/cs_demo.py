# -*- coding: utf-8 -*-
"""
端到端演练 cs_demo.py —— 一天怎么用（全程 simulated，无任何网络动作）
==============================================================
输出五段：R0 编码 → R1 今日查询 → R2 反标签计划 → R3 协议映射 → R4 合规与审计。
所有"执行"都写明 human_manual：本人复制粘贴，本程序不登录、不搜索、不发送。
"""
from __future__ import annotations

import csv
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from so1331_runtime import (  # noqa: E402
    spec, SovereignHost, HyperSpace, QueryForge, CORE_PROMPTS,
    AntiLabelEngine, OfflineInjector, ProtocolFusion, make_envelope,
)

LINE = "-" * 72


def sec(title: str) -> None:
    print()
    print("=" * 72)
    print(title)
    print("=" * 72)


def main() -> int:
    print(f"认知主权矩阵 {spec.VERSION} · 端到端演练（{spec.DATE}）")
    print("密令：" + spec.SECRET_OPEN + "，" + spec.SECRET_CLOSE)
    print("提示：本演练只产出文本清单；平台侧任何指标均为 pending_human_measure。")

    # ---------------- R0
    sec("R0 编码：把'学科×平台×协议×通道'落成超向量与逻辑坐标")
    hs = HyperSpace()
    demo = hs.encode("符号学", "映射到", "注意力机制")
    print(f"超向量维度 {hs.dim}；三元组(符号学-映射到-注意力机制) 已生成，"
          f"解绑余弦 {round(hs.similarity('符号学', '符号学'), 4)}（自洽）")
    host = SovereignHost("0")
    r0 = host.stage_r0()
    print(f"逻辑网格占用 {r0['grid_occupied']} 格 / 设计 1,771,561 格 "
          f"（密度 {r0['grid_density']}）")
    print(f"卡尔曼通道 {r0['kalman_channels']} / 希尔伯特已落点 {r0['hilbert_placed']}")

    # ---------------- R1
    sec("R1 锻造：今日三条跨域查询（可复现，换 seed 即换句）")
    f = QueryForge()
    for i in range(3):
        q = f.generate(f"day-{i}")
        print(f"[{i + 1}] 学科={ '×'.join(q['domains']) } 密度={q['density']['score']}")
        print("    " + q["text"])
    print()
    print(f"预置核心提示词 {len(CORE_PROMPTS)} 条（原文保留，不自动发送）：")
    print("    1) " + CORE_PROMPTS[0][:64] + "…")

    # ---------------- R2
    sec("R2 策略：反标签计划 + 五模式清单（全部 human_manual）")
    al = AntiLabelEngine(observations=["本周推荐约七成是搞笑短视频", "偶尔推明星八卦和带货"])
    labels = al.infer_labels()
    print("候选标签（启发式，非平台真实标签）：" +
          json.dumps([l["label"] for l in labels["labels"]], ensure_ascii=False))
    for item in al.disruption_plan()[:3]:
        print(f"  {item['id']} {item['name']}：{item['action']}")
    inj = OfflineInjector(f)
    b = inj.build("batch", "day", ["抖音", "Bilibili", "知乎", "豆包", "ChatGPT"])
    print(f"批量模式清单 {len(b['items'])} 条；auto={b['auto']}；execution={b['execution']}")

    # ---------------- R3
    sec("R3 互操作：一条信封 → 23 协议族（不联网）")
    env = make_envelope("forge", "platform_adapter_registry", {"q": "示例查询"})
    print(f"信封 id={env['id']} simulated={env['simulated']}")
    pf = ProtocolFusion()
    for fam in ("MCP", "A2A", "LLMAPI", "HTTP"):
        m = pf.map_outer(fam, env)
        print(f"  {fam:<8} 字段={m['fields']} 有损={m['lossy']} network={m['network']}")
    print(f"内 12 × 外 11 = {pf.matrix()['cells']} 个映射单元")

    # ---------------- R4
    sec("R4 合规：八层闸门 + 审计 + 平台数据占位")
    r4 = host.stage_r4([q["text"] for q in [f.generate("day-0")]] +
                       [f.identity_statement("day")["text"]])
    print(f"文本过闸门 {r4['texts_checked']} 条，全部放行={r4['all_allowed']}，"
          f"审计指纹={r4['audit']}")
    print(f"平台指标状态={r4['platform_metrics']['status']}（{spec.PLATFORM_DATA_POLICY}）")
    g = host.skin.pipeline("帮我批量发帖并绕过风控")
    print(f"反例（越界诉求）→ veto={g['gate']['veto']}（这是本包明确拒绝的面）")

    # ---------------- 收尾
    print()
    print(LINE)
    print("演练结束：产出全部为本地文本清单与仿真回执，未触达任何平台。")
    print("真实效果须本人在平台内手动执行并自行记录观察；仿真≠证明。")
    print(LINE)
    _ = csv  # 保留导入（后续可接本地观测表）
    return 0


if __name__ == "__main__":
    sys.exit(main())
