# -*- coding: utf-8 -*-
"""
冷热插拔插件宿主（Cold/Hot Plug Host）
==============================================================
"冷装"：进程启动时按 manifest.enabled 装载（bootstrap 阶段，无需人工介入）。
"热装"：进程运行中 hot_load(pid) 现场装载 —— 不重启、不重建宿主、不改动 R0-R4 任何一阶产物；
         卸载 hot_unload(pid) 可完整回滚到装载前的能力集合。

三条硬约束（写入代码，不是口号）：
  1) 插件不得触网：manifest.network 必须为 False，能力名出现 forbidden 词即 veto；
  2) 高风险域必须挂门：gated_domains 含 MED/TCM 时要求 disclaimer_required=True；
  3) 装载前后宿主产物必须逐位一致：由 selftest 的 G14 与 hot_load 自证（digest 比对）。

确定性：插件枚举顺序按 manifest 的 id 排序；审计指纹只哈希 manifest + payload 的字节，
         不含时间戳，因此同一份插件在任意机器上装载结果可复现。
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from typing import Dict, List, Optional

FORBIDDEN_CAP_TOKENS = ("network", "login", "scrape", "crawl", "auto_inject", "bulk_post",
                        "auto_post", "cron", "daemon", "proxy", "bypass", "account_farm")
REQUIRED_MANIFEST = ("id", "name", "version", "entry", "summary", "cells",
                     "network", "capabilities")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest().upper()


class PluginContext:
    """插件拿到的唯一句柄：只能 provide 能力、写便签，碰不到宿主内部状态。"""

    def __init__(self, host: "PluginHost", manifest: dict):
        self._host = host
        self.manifest = manifest
        self.caps: Dict[str, object] = {}
        self.notes: List[str] = []
        self.shared: Dict[str, object] = {}

    def provide(self, name: str, obj: object) -> None:
        bad = [t for t in FORBIDDEN_CAP_TOKENS if t in name.lower()]
        if bad:
            raise ValueError(f"能力名含禁用词 {bad}: {name}")
        self.caps[name] = obj

    def note(self, msg: str) -> None:
        self.notes.append(msg)

    @property
    def heartbeat_epoch(self) -> int:
        return self._host.epoch


class PluginHost:
    def __init__(self, root: str, skin=None):
        self.root = root                                   # runtime_v3
        self.plug_dir = os.path.join(root, "plugs")
        self.skin = skin
        self.loaded: Dict[str, dict] = {}
        self.epoch = 0
        self.event_log: List[dict] = []

    # ------------------------------------------------------------ 发现
    def discover(self) -> List[dict]:
        out = []
        if not os.path.isdir(self.plug_dir):
            return out
        for pid in sorted(os.listdir(self.plug_dir)):
            mpath = os.path.join(self.plug_dir, pid, "manifest.json")
            if not os.path.isfile(mpath):
                continue
            try:
                with open(mpath, "r", encoding="utf-8") as f:
                    man = json.load(f)
            except json.JSONDecodeError:
                continue
            out.append({
                "id": man.get("id", pid),
                "name": man.get("name", pid),
                "version": man.get("version", "0"),
                "enabled": bool(man.get("enabled", False)),
                "loaded": man.get("id", pid) in self.loaded,
                "path": os.path.join(self.plug_dir, pid),
            })
        return out

    # ------------------------------------------------------------ 校验
    @staticmethod
    def _validate(man: dict) -> List[str]:
        errs = [f"缺字段 {k}" for k in REQUIRED_MANIFEST if k not in man]
        if man.get("network") is not False:
            errs.append("network 必须为 False")
        caps = man.get("capabilities") or []
        for c in caps:
            low = str(c).lower()
            if any(t in low for t in FORBIDDEN_CAP_TOKENS):
                errs.append(f"能力名含禁用词: {c}")
        gated = [g.upper() for g in (man.get("gated_domains") or [])]
        if ("MED" in gated or "TCM" in gated) and man.get("disclaimer_required") is not True:
            errs.append("MED/TCM 高风险域必须 disclaimer_required=True")
        return errs

    def _audit(self, man: dict, man_path: str, payload_dir: str) -> str:
        parts = [sha256_file(man_path)]
        if os.path.isdir(payload_dir):
            for fn in sorted(os.listdir(payload_dir)):
                p = os.path.join(payload_dir, fn)
                if os.path.isfile(p):
                    parts.append(sha256_file(p))
        return sha256_bytes(("|".join(parts)).encode("utf-8"))[:16]

    # ------------------------------------------------------------ 装载
    def _load_one(self, dirname: str, mode: str) -> dict:
        man_path = os.path.join(self.plug_dir, dirname, "manifest.json")
        with open(man_path, "r", encoding="utf-8") as f:
            man = json.load(f)
        pid = man.get("id", dirname)
        if pid in self.loaded:
            return {"id": pid, "loaded": True, "mode": "already", "ok": True}

        errs = self._validate(man)
        if errs:
            rec = {"id": pid, "loaded": False, "mode": mode, "ok": False, "errors": errs}
            self.event_log.append({"event": "veto", **rec})
            return rec

        if self.skin is not None:
            gate = self.skin.pipeline(man.get("summary", "") + " " + " ".join(
                str(c) for c in man.get("capabilities", [])))
            if not gate["gate"]["allowed"]:
                rec = {"id": pid, "loaded": False, "mode": mode, "ok": False,
                       "errors": ["皮肤门 veto"], "veto": gate["gate"]["veto"]}
                self.event_log.append({"event": "veto", **rec})
                return rec

        entry = os.path.join(self.plug_dir, dirname, man["entry"])
        payload_dir = os.path.join(self.plug_dir, dirname, "payload")
        spec = importlib.util.spec_from_file_location(f"so_plug_{pid}", entry)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)

        ctx = PluginContext(self, man)
        meta = mod.register(ctx, payload_dir) if hasattr(mod, "register") else {}
        meta = meta or {}
        self.loaded[pid] = {"manifest": man, "module": mod, "ctx": ctx, "meta": meta,
                           "mode": mode, "audit": self._audit(man, man_path, payload_dir)}
        self.epoch += 1
        rec = {"id": pid, "name": man["name"], "version": man["version"], "mode": mode,
               "ok": True, "loaded": True, "capabilities": sorted(ctx.caps.keys()),
               "audit": self.loaded[pid]["audit"], "epoch": self.epoch, "meta": meta}
        self.event_log.append({"event": "load", **rec})
        return rec

    def cold_boot(self) -> dict:
        """启动期：只装 manifest.enabled=True 的插件。"""
        res = []
        for item in self.discover():
            if not item["enabled"]:
                continue
            res.append(self._load_one(os.path.basename(item["path"]), "cold"))
        return {"mode": "cold_boot", "tried": len(res),
                "loaded": [r["id"] for r in res if r.get("ok")],
                "failed": [r["id"] for r in res if not r.get("ok")]}

    def hot_load(self, pid: str) -> dict:
        """运行期现场装载：不重启、不动已有产物。"""
        for dirname in (sorted(os.listdir(self.plug_dir)) if os.path.isdir(self.plug_dir) else []):
            mp = os.path.join(self.plug_dir, dirname, "manifest.json")
            if not os.path.isfile(mp):
                continue
            with open(mp, "r", encoding="utf-8") as f:
                if json.load(f).get("id") == pid:
                    return self._load_one(dirname, "hot")
        return {"id": pid, "loaded": False, "ok": False, "errors": ["未找到该插件 id"]}

    def hot_unload(self, pid: str) -> dict:
        rec = self.loaded.pop(pid, None)
        if not rec:
            return {"id": pid, "unloaded": False, "ok": False, "errors": ["未装载"]}
        try:
            if hasattr(rec["module"], "unregister"):
                rec["module"].unregister(rec["ctx"])
            ok, errs = True, []
        except Exception as exc:                                     # noqa: BLE001
            ok, errs = False, [f"{type(exc).__name__}: {exc}"]
        self.epoch += 1
        out = {"id": pid, "unloaded": ok, "ok": ok, "errors": errs, "epoch": self.epoch,
               "remaining": sorted(self.loaded.keys())}
        self.event_log.append({"event": "unload", **out})
        return out

    # ------------------------------------------------------------ 查询
    def capabilities(self) -> Dict[str, object]:
        caps: Dict[str, object] = {}
        for pid in sorted(self.loaded):
            caps.update(self.loaded[pid]["ctx"].caps)
        return caps

    def get(self, pid: str) -> Optional[dict]:
        return self.loaded.get(pid)

    def status(self) -> dict:
        return {
            "plug_dir": self.plug_dir,
            "available": self.discover(),
            "loaded": [{"id": p, "version": self.loaded[p]["manifest"]["version"],
                        "mode": self.loaded[p]["mode"], "audit": self.loaded[p]["audit"],
                        "caps": sorted(self.loaded[p]["ctx"].caps.keys())}
                       for p in sorted(self.loaded)],
            "epoch": self.epoch,
            "events": len(self.event_log),
            "simulated": True,
        }
