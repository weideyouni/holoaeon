# -*- coding: utf-8 -*-
"""
全息心跳引擎 —— 认知主权 70 体 768 维 α=0.18，号段 9700-9769
==============================================================
确定性种子向量 + 每轮心跳的强度/节律/状态演化 + 全息自检指纹。
心跳只做"同步节拍"，不代表任何平台侧状态（平台数据一律 pending_human_measure）。
"""
from __future__ import annotations

import hashlib
import time
from typing import Dict, List

from .spec import HEARTBEAT_COUNT, HEARTBEAT_BASE, HEARTBEAT_DIM, HEARTBEAT_ALPHA, DOMAIN


def _seed_vec(uid: int, dim: int) -> List[float]:
    """确定性伪随机向量（纯标准库）。"""
    seed = hashlib.sha256(f"{DOMAIN}:{uid}".encode("utf-8")).digest()
    vec: List[float] = []
    for i in range(dim):
        b = seed[i % len(seed)]
        vec.append(((b + i * 7) % 256) / 255.0)
    return vec


class HeartbeatBody:
    """单个心跳体：768 维状态向量 + 强度 + 节律 + 状态。"""

    def __init__(self, uid: int, dim: int = HEARTBEAT_DIM, alpha: float = HEARTBEAT_ALPHA):
        self.uid = uid
        self.dim = dim
        self.alpha = alpha
        self.vec = _seed_vec(uid, dim)
        self.strength = 0.5
        self.rhythm = 1.0
        self.status = "idle"          # idle / active / degraded / fault
        self.fault_count = 0
        self.last_beat = time.time()

    def beat(self) -> float:
        now = time.time()
        self.last_beat = now
        self.strength = (1 - self.alpha) * self.strength + self.alpha * (0.5 + 0.5 * self.vec[0])
        self.rhythm = max(0.2, min(2.0, self.rhythm + 0.01 * (0.5 - self.vec[1])))
        if self.strength < 0.2:
            self.status = "degraded"
        elif self.strength > 0.85:
            self.status = "active"
        else:
            self.status = "idle"
        return self.strength

    def mark_fault(self) -> None:
        self.fault_count += 1
        self.strength *= 0.5
        if self.fault_count >= 3:
            self.status = "fault"

    def snapshot(self) -> dict:
        return {
            "uid": self.uid,
            "code": f"HB-{self.uid}",
            "strength": round(self.strength, 4),
            "rhythm": round(self.rhythm, 4),
            "status": self.status,
            "fault_count": self.fault_count,
            "dim": self.dim,
        }


class HeartbeatHub:
    """全息心跳中枢：70 体，号段 9700-9769。"""

    def __init__(self, count: int = HEARTBEAT_COUNT, base: int = HEARTBEAT_BASE):
        self.bodies: Dict[int, HeartbeatBody] = {
            base + i: HeartbeatBody(base + i) for i in range(count)
        }
        self.round = 0

    def run_round(self) -> Dict[int, float]:
        self.round += 1
        return {uid: body.beat() for uid, body in self.bodies.items()}

    def scan(self) -> dict:
        active = sum(1 for b in self.bodies.values() if b.status == "active")
        idle = sum(1 for b in self.bodies.values() if b.status == "idle")
        degraded = sum(1 for b in self.bodies.values() if b.status == "degraded")
        fault = sum(1 for b in self.bodies.values() if b.status == "fault")
        return {
            "total": len(self.bodies),
            "active": active,
            "idle": idle,
            "degraded": degraded,
            "fault": fault,
            "round": self.round,
            "healthy": fault == 0 and degraded <= 5,
        }

    def holographic(self) -> dict:
        probe = next(iter(self.bodies.values()))
        return {
            "domain": DOMAIN,
            "base": HEARTBEAT_BASE,
            "range": f"{HEARTBEAT_BASE}-{HEARTBEAT_BASE + HEARTBEAT_COUNT - 1}",
            "count": len(self.bodies),
            "dim": HEARTBEAT_DIM,
            "alpha": HEARTBEAT_ALPHA,
            "probe_uid": probe.uid,
            "probe_code": f"HB-{probe.uid}",
            "fingerprint": hashlib.sha256(
                "".join(f"{b.strength:.4f}" for b in self.bodies.values()).encode("utf-8")
            ).hexdigest()[:16],
        }

    def degrade(self, uid: int) -> None:
        if uid in self.bodies:
            self.bodies[uid].mark_fault()

    def stats(self) -> list:
        return [b.snapshot() for b in self.bodies.values()]

    def verify(self) -> dict:
        hub = HeartbeatHub()
        hub.run_round()
        hub.run_round()
        scan = hub.scan()
        holo = hub.holographic()
        return {
            "scan": scan,
            "holo": holo,
            "range_ok": HEARTBEAT_BASE == 9700 and HEARTBEAT_BASE + HEARTBEAT_COUNT - 1 == 9769,
            "ok": (
                scan["total"] == 70
                and scan["healthy"]
                and scan["fault"] == 0
                and holo["probe_uid"] == 9700
                and len(holo["fingerprint"]) == 16
                and HEARTBEAT_DIM == 768
                and abs(HEARTBEAT_ALPHA - 0.18) < 1e-9
                and holo["range"] == "9700-9769"
            ),
        }
