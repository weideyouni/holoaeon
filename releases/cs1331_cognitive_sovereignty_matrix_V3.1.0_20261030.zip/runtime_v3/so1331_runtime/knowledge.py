# -*- coding: utf-8 -*-
"""
知识台账读取层（data/*.csv + 四表口径）
==============================================================
四张表（口径与母体一致）：
  executor_1331_registry.csv   70 执行体（心跳 9700-9769）
  knowledge_dimensions_1331.csv 147 维度 = 130 分身维度 + 17 通道维度
  mandala_108641_allocation.csv 10 行 = 9 域 + 合计 108,641
  cases_20.csv                  20 案例 = normal 10 + AL 4 + PF 6
只读本地文件，不联网、不写入云端。
"""
from __future__ import annotations

import csv
import os
from typing import Dict, List

from . import spec

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


def _read(name: str) -> List[Dict[str, str]]:
    path = os.path.join(DATA_DIR, name)
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return [dict(row) for row in csv.DictReader(f)]


class Knowledge:
    """四表台账 + 协议/学科视图。"""

    def __init__(self):
        self.executors = _read("executor_1331_registry.csv")
        self.dimensions = _read("knowledge_dimensions_1331.csv")
        self.mandala = _read("mandala_108641_allocation.csv")
        self.cases = _read("cases_20.csv")

    # ---- 四表
    def avatar_count(self) -> int:
        return len(self.executors)

    def cases_list(self) -> List[Dict[str, str]]:
        return self.cases

    def weight_sum(self) -> float:
        return round(sum(float(d["weight"]) for d in self.dimensions), 6)

    # ---- 23 协议（内 12 / 外 11）
    def protocols(self) -> dict:
        inner = [{"key": p[0], "name": p[1], "ops": list(p[2])} for p in spec.INNER_PROTOCOLS]
        outer = [{"key": p[0], "name": p[1], "members": list(p[2])} for p in spec.OUTER_PROTOCOLS]
        return {"inner": inner, "outer": outer, "total": len(inner) + len(outer),
                "inner_count": len(inner), "outer_count": len(outer)}

    # ---- 40 科（本源 29 + 融合 11）
    def subjects(self) -> dict:
        return {"origin": spec.SUBJECT_ORIGIN, "fusion": spec.SUBJECTS_FUSION,
                "origin_count": len(spec.SUBJECTS_ORIGIN),
                "fusion_count": len(spec.SUBJECTS_FUSION),
                "total": len(spec.SUBJECTS_ORIGIN) + len(spec.SUBJECTS_FUSION)}

    # ---- 平台族
    def platform_families(self) -> List[dict]:
        return [{"key": f[0], "name": f[1], "members": list(f[2])} for f in spec.PLATFORM_FAMILIES]

    def verify(self) -> dict:
        k = Knowledge()
        cases = k.cases_list()
        cats = {c: sum(1 for x in cases if x["category"] == c) for c in spec.CASE_CATEGORIES}
        dims_channels = [d for d in k.dimensions if d["kind"] == "channel"]
        dims_avatar = [d for d in k.dimensions if d["kind"] == "avatar"]
        mandala_total = int(k.mandala[-1]["node_count"])
        mandala_rows = len(k.mandala)
        p = k.protocols()
        s = k.subjects()
        return {
            "executors": len(k.executors),
            "executor_hb_first": k.executors[0]["heartbeat_code"],
            "executor_hb_last": k.executors[-1]["heartbeat_code"],
            "dimensions": len(k.dimensions),
            "dims_avatar": len(dims_avatar),
            "dims_channel": len(dims_channels),
            "weight_sum": k.weight_sum(),
            "mandala_rows": mandala_rows,
            "mandala_total": mandala_total,
            "cases": len(cases),
            "case_cats": cats,
            "protocols": p["total"],
            "subjects": s["total"],
            "ok": (
                len(k.executors) == 70 == spec.EXECUTOR_TOTAL
                and k.executors[0]["heartbeat_code"] == "HB-9700"
                and k.executors[-1]["heartbeat_code"] == "HB-9769"
                and len(k.dimensions) == 147 == spec.DIMENSION_TOTAL
                and len(dims_avatar) == 130 and len(dims_channels) == 17
                and abs(k.weight_sum() - 1.0) <= 0.001
                and mandala_rows == 10 and mandala_total == 108641
                and len(cases) == 20
                and cats == {"normal": 10, "AL": 4, "PF": 6}
                and p["total"] == 23 and p["inner_count"] == 12 and p["outer_count"] == 11
                and s["total"] == 40 and s["origin_count"] == 29 and s["fusion_count"] == 11
                and len(k.platform_families()) == 10
            ),
        }
