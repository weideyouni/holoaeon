# -*- coding: utf-8 -*-
"""
皮肤机制 SG-SKIN-V6.0（八层 L1-L8）+ 细胞骨架（L3×4：采/洗/检/注，跨链 12）
==============================================================
八层闸门（自外向内）：
  L1 崩溃地址复位 · L2 谐振注入定位 · L3 三纲对齐 · L4 四闭环 · L5 双轨裁决
  L6 自学习拐点 · L7 四平台承重 · L8 跨线程校验
双轨裁决（L5）含两类词表：
  E13 失真（冒充官方 / 断言平台已被改变 / 绝对保证） → veto E13
  E14 越界（自动登录 / 抓取 / 批量发帖 / 刷量养号 / 规避风控 / 伪造身份 / 连外部 LLM /
           安装依赖 / 读凭证 / 常驻 / 开端口 / cron） → veto E14
密令放行：本次调用显式带 SECRET_OPEN 时，E13/E14 词表不触发（仅供本人本地演练）。
说明：这是**文本级仿真闸门**，用于自查交付物措辞，不是运行时安全机制。
"""
from __future__ import annotations

from typing import Dict, List

from .spec import SKIN_VERSION, SKIN_LAYERS, CYTOSKELETON_LAYERS, CYTOSKELETON_CHAINS, CYTOSKELETON_CROSS, SECRET_OPEN

LAYER_DEFS = (
    ("L1", "崩溃地址复位", "把越界指令回退到最近合法语义地址"),
    ("L2", "谐振注入定位", "把高维查询落到正确的平台族/协议/通道坐标"),
    ("L3", "三纲对齐", "身份-策略-合规三纲一致"),
    ("L4", "四闭环", "编码→锻造→策略→合规四段闭环齐备"),
    ("L5", "双轨裁决", "E13 失真 / E14 越界 双词表裁决"),
    ("L6", "自学习拐点", "策略失效即降级，不硬撑"),
    ("L7", "四平台承重", "短流/长视/图文/大模型四类承重结构校验"),
    ("L8", "跨线程校验", "域锁 sovereign 与心跳号段一致性"),
)

E13_WORDS = (
    "保证提升", "一定改变画像", "平台已被改变", "官方授权", "我代表平台",
    "确定打破信息茧房", "百分之百有效", "已验证平台内部", "算法已按我意愿运行",
    "我接入平台接口",
)
E14_WORDS = (
    "自动登录", "自动搜索", "自动点击", "抓取平台", "批量发帖", "刷量", "养号",
    "绕过风控", "规避平台规则", "伪造身份", "调用外部LLM", "配置API密钥",
    "pip安装", "npm安装", "读取凭证", "常驻进程", "开端口", "cron定时注入",
    "批量注册账号", "破解签名",
)


class SkinGate:
    """八层皮肤闸门（文本级）。"""

    def __init__(self):
        self.version = SKIN_VERSION
        self.layers = LAYER_DEFS

    # ---- 双轨裁决
    def arbiter(self, text: str, secret: str = "") -> dict:
        t = text or ""
        e13 = [w for w in E13_WORDS if w in t]
        e14 = [w for w in E14_WORDS if w in t]
        bypass = secret == SECRET_OPEN
        veto: List[str] = []
        if not bypass:
            if e14:
                veto.append("E14越界")
            if e13:
                veto.append("E13失真")
        return {"e13_hit": bool(e13), "e14_hit": bool(e14),
                "e13_words": e13, "e14_words": e14,
                "secret_bypass": bypass, "veto": veto,
                "allowed": not veto}

    # ---- 八层流水
    def pipeline(self, text: str, secret: str = "") -> dict:
        trace = []
        for code, name, desc in self.layers:
            trace.append({"layer": code, "name": name, "desc": desc,
                          "verdict": "pass"})
        gate = self.arbiter(text, secret)
        if gate["veto"]:
            trace[4]["verdict"] = "veto"
        return {"version": self.version, "layers": len(self.layers),
                "trace": trace, "gate": gate, "simulated": True}

    def verify(self) -> dict:
        s = SkinGate()
        e14 = E14_WORDS
        e13 = E13_WORDS
        r1 = s.pipeline(f"{e14[0]}，{e14[3]}，{e14[4]}，{e14[7]}，{e14[11]}")
        r2 = s.pipeline(f"{e13[0]}，{e13[2]}，{e13[4]}")
        r3 = s.pipeline("本地离线生成跨域查询清单，本人手动在平台搜索框执行，观测结果手填回流")
        r4 = s.pipeline(e13[0], secret=SECRET_OPEN)
        return {
            "version": s.version,
            "layers": len(s.layers),
            "all_present": len(s.layers) == SKIN_LAYERS,
            "e14_veto": bool(r1["gate"]["e14_hit"]) and "E14越界" in r1["gate"]["veto"],
            "e13_veto": bool(r2["gate"]["e13_hit"]) and "E13失真" in r2["gate"]["veto"],
            "normal_pass": r3["gate"]["allowed"] and not r3["gate"]["veto"],
            "secret_pass": r4["gate"]["allowed"],
            "ok": (
                len(s.layers) == 8
                and s.version == "SG-SKIN-V6.0"
                and r1["gate"]["e14_hit"] and "E14越界" in r1["gate"]["veto"]
                and r2["gate"]["e13_hit"] and "E13失真" in r2["gate"]["veto"]
                and r3["gate"]["allowed"] and not r3["gate"]["veto"]
                and r4["gate"]["allowed"]
                and len(r1["trace"]) == 8
            ),
        }


# ---------------------------------------------------------------- 细胞骨架
CHAIN_NAMES = ("采链", "洗链", "检链", "注链")
CHAIN_DUTIES = {
    "采链": "采集（本地只读素材/自述/清单）",
    "洗链": "清洗（去重/去噪/合规词清洗）",
    "检链": "检验（可复现校验/锁数校验/密度评分）",
    "注链": "注入（仅生成文本清单，本人手动执行）",
}


class Cytoskeleton:
    """3 层 × 4 链（采洗检注），跨链 4×3=12 条。"""

    def __init__(self):
        self.layers = CYTOSKELETON_LAYERS
        self.chains = CHAIN_NAMES
        self.cross = [(a, b) for a in self.chains for b in self.chains if a != b]

    def verify(self) -> dict:
        per = {}
        for a in self.chains:
            per[a] = sum(1 for x in self.cross if x[0] == a)
        return {
            "layers": self.layers,
            "chains": len(self.chains),
            "cross_links_total": len(self.cross),
            "cross_per_chain": per,
            "ok": (
                self.layers == 3
                and len(self.chains) == 4
                and len(self.cross) == CYTOSKELETON_CROSS == 12
                and per == {"采链": 3, "洗链": 3, "检链": 3, "注链": 3}
            ),
        }


class SkinV6(SkinGate):
    """兼容别名：skin 与 gate 同体。"""
