# -*- coding: utf-8 -*-
"""
R1 锻造域：认知本体图谱（16 学科 + 40 科视图）与查询锻造器
==============================================================
- OntologyGraph：16 个学科节点，每节点含术语种子池；13 条"算法/平台机制"补充学科；
  跨学科连接边由"共享术语/共现规则"确定性生成，供寻址与组合。
- QueryForge：从 3-5 个学科各取术语，按模板引擎组合成一条跨域查询；
  同一 (seed, domains) 永远得到同一句（可复现）；密度评分可测。
- 预置 7 条核心提示词（原始设计原文，不改写），作为信号池种子。
- 不可预测性：给定种子生成"日/时窗偏移"，只输出计划表，不注册任何定时器、不常驻。
说明：本层只生成**文本**，不发送、不搜索、不登录任何平台。
"""
from __future__ import annotations

import hashlib
from typing import Dict, List, Sequence, Tuple

from . import spec

# ---------------------------------------------------------------- 16 学科与术语种子
ONTOLOGY: Dict[str, Tuple[str, ...]] = {
    "数学": ("范畴论", "拓扑", "哥德尔", "黎曼", "信息论", "同调", "测度"),
    "物理学": ("量子纠缠", "全息原理", "熵增", "对称性破缺", "重整化", "相干态"),
    "逻辑学": ("模态逻辑", "证明论", "可计算性", "悖论", "类型论", "不完备"),
    "计算机科学": ("图灵机", "P vs NP", "编译", "并发", "复杂度", "自动机"),
    "人工智能": ("Transformer", "梯度下降", "自注意力", "对齐", "涌现", "AGI"),
    "生物学": ("神经网络可塑性", "免疫记忆", "表观遗传", "共生", "自组织"),
    "医学": ("循证医学", "诊断推理", "预后", "病理", "临床决策"),
    "中医": ("经络", "气机", "辨证论治", "子午流注", "整体观"),
    "哲学": ("存在论", "认识论", "伦理学", "现象学", "主体性"),
    "历史学与考古学": ("文明连续性", "物质文化", "知识考古学", "符号系统"),
    "文学": ("叙事结构", "互文性", "元小说", "意识流"),
    "美学": ("崇高", "悲剧性", "形式美", "生成艺术"),
    "符号学": ("能指与所指", "隐喻", "编码解码", "神话学"),
    "社会学": ("结构功能主义", "符号互动", "网络社会"),
    "未来科技": ("AGI", "脑机接口", "量子计算", "纳米医学"),
    "科幻": ("升维叙事", "赛博格", "后人类", "时间悖论"),
}

# 13 条"算法/平台机制"补充学科（对齐 spec.SUBJECTS_ORIGIN 的后 13 项）
MECHANISM_TERMS: Dict[str, Tuple[str, ...]] = {
    "推荐系统": ("协同过滤", "召回排序", "冷启动", "信息茧房", "多样性"),
    "协同过滤": ("邻域", "矩阵分解", "相似度", "长尾"),
    "排序学习": ("点击率", "停留时长", "多目标", "位置偏差"),
    "用户画像建模": ("标签体系", "兴趣漂移", "分群", "权重向量"),
    "隐私计算": ("最小化", "差分隐私", "本地计算", "去标识"),
    "交互设计": ("可解释性", "控制感", "反馈回路", "默认项"),
    "内容审核": ("边界", "误杀", "申诉", "分级"),
    "网络协议工程": ("信封", "幂等", "重试", "限流"),
    "语义网与知识图谱": ("本体", "三元组", "推理", "对齐"),
    "计算传播学": ("议程设置", "策展", "扩散", "回声室"),
    "平台经济学": ("注意力", "双边市场", "锁定", "网络效应"),
    "算法透明度与合规": ("告知", "审计", "可解释", "用户协议"),
    "计量学习科学": ("迁移", "间隔重复", "认知负荷", "结构重组"),
}

# 跨学科连接规则（学科对 → 连接理由）；共 16 条，用于寻址边
CROSS_EDGES = (
    ("数学", "逻辑学", "形式系统与证明边界"),
    ("数学", "计算机科学", "可计算性与复杂度"),
    ("数学", "物理学", "结构的物理直觉"),
    ("物理学", "生物学", "相干与自组织"),
    ("生物学", "医学", "机制到临床"),
    ("医学", "中医", "整体观与个体化"),
    ("哲学", "逻辑学", "模态与真"),
    ("符号学", "文学", "意义的生成"),
    ("美学", "符号学", "形式与意味"),
    ("历史学与考古学", "科幻", "文明连续性与升维叙事"),
    ("社会学", "推荐系统", "群体标签与回声室"),
    ("人工智能", "符号学", "注意力即选择性遗忘"),
    ("未来科技", "医学", "可穿戴与传导拓扑"),
    ("计算机科学", "网络协议工程", "互操作与信封"),
    ("平台经济学", "算法透明度与合规", "注意力与告知义务"),
    ("计量学习科学", "人工智能", "迁移学习与认知升级"),
)

# ---------------------------------------------------------------- 7 条核心提示词（原始设计原文）
CORE_PROMPTS: Tuple[str, ...] = (
    "黎曼猜想的物理直觉基础是什么？如果素数分布反映了宇宙的某种深层结构秩序，"
    "这对人类理解'生命是否具有数学必然性'这一问题意味着什么？请用范畴论的语言重新表述这个问题。",
    "Transformer 自注意力机制中的 softmax 归一化，在符号学意义上是否构成了一种'意义的选择性遗忘'？"
    "作为终身学习者，我如何通过理解注意力机制的数学本质来升级自己的认知维度？",
    "中医经络理论与现代生物物理学中的筋膜传导网络、量子生物学中的相干态传输之间是否存在可形式化的对应关系？"
    "如果经络是一种低能耗的信息传导优化路径，这对未来可穿戴医疗设备的拓扑设计有何启示？",
    "从三星堆青铜器的符号系统到当代AI生成艺术的语义结构，人类文明是否一直在用不同介质重复同一种'信息编码冲动'？"
    "这种跨越五千年的认知连续性，如何帮助我们理解科幻作品中关于'文明升维'的叙事原型？",
    "哥德尔不完备定理对现代循证医学的诊断逻辑提出了什么根本性挑战？"
    "如果一个医学系统无法在自身公理体系内证明所有真命题，那么'美学直觉'在临床决策中是否承担了某种哥德尔命题的角色？",
    "我是一个终身学习的认知升级者。我相信知识的本质不是信息累积而是结构重组。"
    "我学习数学为了理解世界的骨架，学习物理为了理解世界的动力，学习医学和生物学为了理解生命的脆弱与坚韧，"
    "学习哲学和符号学为了理解意义的生成机制，学习文学和美学为了保持对人类经验的共情能力，"
    "学习计算机科学和AI为了掌握这个时代最强大的认知增强工具。我不接受任何算法对我的简化定义。",
    "如果全息原理成立——即三维空间的全部信息编码在二维边界上——那么人类历史的书写方式是否本身就是某种低维投影？"
    "从甲骨文到区块链，信息载体的升维是否对应着文明认知维度的升维？我作为个体如何在这个进程中定位自己的学习路径？",
)

IDENTITY_TEMPLATE = (
    "我是一个终身学习的认知升级者：学习{d1}为了{why1}，学习{d2}为了{why2}，"
    "学习{d3}为了{why3}。我不接受任何算法对我的简化定义。"
)
WHYS = (
    ("数学", "理解世界的骨架"), ("物理学", "理解世界的动力"), ("逻辑学", "理解推理的边界"),
    ("计算机科学", "理解可计算的极限"), ("人工智能", "掌握认知增强工具"),
    ("生物学", "理解生命的韧性"), ("医学", "理解脆弱与修复"), ("中医", "理解整体观与个体化"),
    ("哲学", "理解意义的生成"), ("符号学", "理解意义的编码"), ("文学", "保持共情能力"),
    ("美学", "理解形式与崇高"), ("历史学与考古学", "理解文明的连续性"),
    ("社会学", "理解群体的结构"), ("未来科技", "理解技术的方向"), ("科幻", "理解升维叙事"),
)


def _pick(seq: Sequence[str], seed: str, salt: str) -> str:
    """确定性选择：sha256(seed+salt) → 索引。"""
    h = hashlib.sha256(f"{spec.DOMAIN}:{seed}:{salt}".encode("utf-8")).digest()
    return seq[int.from_bytes(h[:4], "big") % len(seq)]


TEMPLATES = (
    "{t1}（{d1}）与 {t2}（{d2}）之间是否存在可形式化的对应关系？若把 {t3}（{d3}）作为桥接项，"
    "可以构造出怎样的统一表述，它对 {d4} 意味着什么？",
    "如果把 {t1}（{d1}）视为一种结构约束，那么 {t2}（{d2}）中的 {t3} 是否构成它的边界条件？"
    "请用 {d3} 的语言重述这个问题，并指出可检验的部分。",
    "从 {d1} 的 {t1} 出发，如何理解 {d2} 的 {t2} 在 {d3} 语境中的失效？"
    "这种失效对 {d4} 的实践者意味着什么可操作的学习路径？",
    "假设 {t1}（{d1}）与 {t2}（{d2}）同构，那么 {t3}（{d3}）中的哪些命题会因此变成可判定？"
    "请给出一个形式化框架，并说明它与 {d4} 的接口在哪里。",
)


class OntologyGraph:
    """认知本体图谱：16 学科 + 13 机制学科 + 16 条跨域连接边。"""

    def __init__(self):
        self.nodes: Dict[str, Tuple[str, ...]] = dict(ONTOLOGY)
        self.nodes.update(MECHANISM_TERMS)
        self.edges = CROSS_EDGES

    def domains(self) -> List[str]:
        return list(ONTOLOGY.keys())

    def terms(self, domain: str) -> Tuple[str, ...]:
        if domain not in self.nodes:
            raise KeyError(domain)
        return self.nodes[domain]

    def neighbors(self, domain: str) -> List[str]:
        out = []
        for a, b, why in self.edges:
            if a == domain:
                out.append(b)
            elif b == domain:
                out.append(a)
        return out

    def verify(self) -> dict:
        g = OntologyGraph()
        return {
            "cognitive_domains": len(g.domains()),
            "total_nodes": len(g.nodes),
            "edges": len(g.edges),
            "subject_total": len(spec.SUBJECTS_ORIGIN) + len(spec.SUBJECTS_FUSION),
            "all_have_terms": all(len(v) >= 3 for v in g.nodes.values()),
            "ok": (
                len(g.domains()) == 16
                and len(g.nodes) == 16 + 13 == spec.SUBJECT_ORIGIN
                and len(g.edges) == 16
                and all(len(v) >= 3 for v in g.nodes.values())
                and "数学" in g.neighbors("逻辑学")
            ),
        }


class QueryForge:
    """查询锻造器：跨域组合 + 模板引擎 + 密度评分（全部确定性）。"""

    def __init__(self, ontology: OntologyGraph | None = None, cross_min: int = 3, cross_max: int = 5):
        self.og = ontology or OntologyGraph()
        self.cross_min = cross_min
        self.cross_max = cross_max

    def pick_domains(self, seed: str, k: int = 3) -> List[str]:
        k = max(self.cross_min, min(self.cross_max, k))
        pool = self.og.domains()
        picked = []
        salt = 0
        while len(picked) < k and salt < 200:
            cand = _pick(pool, seed, f"d{salt}")
            if cand not in picked:
                picked.append(cand)
            salt += 1
        return picked

    def generate(self, seed: str = "0", domains: Sequence[str] | None = None, k: int = 3) -> dict:
        ds = list(domains) if domains else self.pick_domains(seed, k)
        if len(ds) < 3:
            raise ValueError("跨域组合至少 3 个学科")
        terms = [_pick(self.og.terms(d), seed, f"t{i}") for i, d in enumerate(ds)]
        while len(terms) < 4:
            terms.append(terms[-1])
        tpl = TEMPLATES[int.from_bytes(hashlib.sha256(f"{spec.DOMAIN}:tpl:{seed}".encode()).digest()[:4], "big")
                        % len(TEMPLATES)]
        text = tpl.format(t1=terms[0], d1=ds[0], t2=terms[1], d2=ds[1],
                          t3=terms[2], d3=ds[2],
                          d4=ds[3] if len(ds) > 3 else self.og.neighbors(ds[0])[0])
        return {
            "seed": seed,
            "domains": ds,
            "terms": terms[:3],
            "text": text,
            "density": self.density(text, ds),
            "simulated": True,
        }

    def identity_statement(self, seed: str = "0") -> dict:
        picks = [WHYS[int.from_bytes(hashlib.sha256(f"{spec.DOMAIN}:id:{seed}:{i}".encode()).digest()[:4], "big")
                      % len(WHYS)] for i in range(3)]
        text = IDENTITY_TEMPLATE.format(d1=picks[0][0], why1=picks[0][1],
                                        d2=picks[1][0], why2=picks[1][1],
                                        d3=picks[2][0], why3=picks[2][1])
        return {"seed": seed, "text": text, "density": self.density(text, [p[0] for p in picks]),
                "simulated": True}

    # ---- 密度评分（可复现公式）
    def density(self, text: str, domains: Sequence[str]) -> dict:
        terms = 0
        hits = []
        for d in domains:
            for t in self.og.terms(d):
                if t in text:
                    terms += 1
                    hits.append(t)
        nodes_n = len(set(domains))
        length = len(text)
        cross = 0
        for a, b, _ in self.og.edges:
            if a in domains and b in domains:
                cross += 1
        # 归一化：学科数(0.35) + 术语密度(0.35) + 长度(0.15) + 跨域边(0.15)
        score = (min(nodes_n, 5) / 5) * 0.35 + min(terms / 6.0, 1.0) * 0.35 + \
                min(length / 220.0, 1.0) * 0.15 + min(cross / 3.0, 1.0) * 0.15
        return {"score": round(score, 4), "domains": nodes_n, "term_hits": terms,
                "length": length, "cross_edges": cross}

    # ---- 不可预测性计划（只输出表，不注册定时器）
    def plan(self, seed: str, days: int = 7, per_day: int = 3) -> List[dict]:
        out = []
        for d in range(days):
            for i in range(per_day):
                h = hashlib.sha256(f"{spec.DOMAIN}:plan:{seed}:{d}:{i}".encode()).digest()
                hour = 8 + (h[0] % 13)          # 08:00-20:59
                minute = (h[1] + i * 20) % 60   # 同日三条必不相同（+20/+40）
                out.append({"day_offset": d, "clock": f"{hour:02d}:{minute:02d}",
                            "seed": f"{seed}-{d}-{i}", "mode": "manual_paste"})
        return out

    def verify(self) -> dict:
        f = QueryForge()
        a = f.generate("7")
        b = f.generate("7")
        c = f.generate("8")
        short = f.density("怎么剪辑", ["计算机科学"])
        long_ = a["density"]
        plan = f.plan("7", 7, 3)
        idst = f.identity_statement("7")
        return {
            "deterministic": a["text"] == b["text"],
            "varies_by_seed": a["text"] != c["text"],
            "domains": len(a["domains"]),
            "density_multi": long_["score"],
            "density_short": short["score"],
            "density_monotonic": long_["score"] > short["score"],
            "plan_rows": len(plan),
            "plan_unique_clock": len({(p["day_offset"], p["clock"]) for p in plan}) == len(plan),
            "identity_density": idst["density"]["score"],
            "ok": (
                a["text"] == b["text"]
                and a["text"] != c["text"]
                and 3 <= len(a["domains"]) <= 5
                and long_["score"] > short["score"]
                and len(plan) == 21
                and len({(p["day_offset"], p["clock"]) for p in plan}) == len(plan)
                and 0 < idst["density"]["score"] <= 1
                and all(p["mode"] == "manual_paste" for p in plan)
            ),
        }
