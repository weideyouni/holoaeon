# -*- coding: utf-8 -*-
"""
语义通信底座（十模块）—— SO 语义总线
==============================================================
十模块：采集 / 编码 / 锻造 / 策略 / 协议 / 平台 / 合规 / 审计 / 时序 / 运维。
职责是把任意一段本地文本按关键词路由到对应模块，并给出可复现的语义头（不联网、不调模型）。
"""
from __future__ import annotations

import hashlib
from typing import Dict, List

from .spec import SEMANTIC_MODULES, DOMAIN

MODULES = (
    ("采集", ("素材", "读取", "本地", "清单", "输入", "整理")),
    ("编码", ("超向量", "张量", "768", "bind", "bundle", "cosine", "指纹", "编码")),
    ("锻造", ("查询", "跨域", "学科", "模板", "组合", "跳域", "密度")),
    ("策略", ("反标签", "刻板", "画像", "自测", "清单", "校准", "观测")),
    ("协议", ("协议", "信封", "envelope", "http", "mcp", "a2a", "graphql", "oauth", "rss")),
    ("平台", ("平台", "短视频", "长视频", "图文", "搜索", "社交", "电商", "大模型", "开发者")),
    ("合规", ("合规", "边界", "用户协议", "不抓取", "不自动", "不刷量", "闸门", "留痕")),
    ("审计", ("审计", "sha256", "复现", "校验", "台账", "回执", "simulated")),
    ("时序", ("心跳", "节拍", "轮次", "调度", "时间窗", "9700")),
    ("运维", ("运维", "健康", "降级", "熔断", "回滚", "备份")),
)


class SemanticBus:
    """十模块语义路由 + 语义头。"""

    def __init__(self):
        self.modules = MODULES
        self.name = DOMAIN

    def route(self, text: str) -> List[str]:
        t = (text or "").lower()
        hits = []
        for name, kws in self.modules:
            if any(k.lower() in t for k in kws):
                hits.append(name)
        return hits

    def header(self, text: str) -> Dict[str, object]:
        h = hashlib.sha256((text or "").encode("utf-8")).hexdigest()[:16]
        return {
            "domain": self.name,
            "modules_hit": self.route(text),
            "digest": h,
            "length": len(text or ""),
            "simulated": True,
        }

    def verify(self) -> dict:
        bus = SemanticBus()
        routes = bus.route("本地采集素材 超向量编码 跨域查询锻造 反标签自测 协议信封 http mcp "
                           "平台短视频与长视频 合规边界不抓取 审计sha256复现 心跳轮次调度 运维降级回滚")
        core = bus.route("锻造 跨域学科查询模板")
        hd = bus.header("锻造")
        return {
            "modules_total": len(bus.modules),
            "routes": routes,
            "ok": (
                len(bus.modules) == SEMANTIC_MODULES == 10
                and {"采集", "编码", "锻造", "策略", "协议", "平台", "合规", "审计", "时序", "运维"} == set(routes)
                and "锻造" in core
                and len(hd["digest"]) == 16
            ),
        }
