# -*- coding: utf-8 -*-
"""
认知主权矩阵运行时 so1331_runtime —— 对外出口
==============================================================
纯标准库、离线、确定性。五机制 + 张量向量化 + 内外协议融通 + 平台全域族谱。
"""
from . import spec
from .spec import (MATRIX_ID, RUNTIME_ID, PROTOCOL_ID, BUS_ID, THREADBUS_ID, DOMAIN,
                   VERSION, DATE, SECRET_OPEN, SECRET_CLOSE,
                   SOVEREIGN_CHANNELS, PLATFORM_FAMILIES, INNER_PROTOCOLS, OUTER_PROTOCOLS)
from .tensor import (HyperSpace, LogicGrid, KalmanChannels, HilbertLayers, MandalaSpace,
                     seed_bipolar, bind, bundle, permute, cosine, xor_distance, encode_all)
from .heartbeat_engine import HeartbeatHub, HeartbeatBody
from .threadbus import ThreadBus
from .skin import SkinGate, SkinV6, Cytoskeleton
from .semantic_bus import SemanticBus
from .hebbian_field import HebbianField, FLOW_EDGES, flower_of_life_positions
from .forge import OntologyGraph, QueryForge, CORE_PROMPTS, ONTOLOGY, MECHANISM_TERMS
from .strategy import AntiLabelEngine, OfflineInjector, STRATEGIES, MODE_DEFS
from .interop import ProtocolFusion, PlatformRegistry, make_envelope, INNER_MAPPING, OUTER_MAPPING
from .knowledge import Knowledge
from .host import SovereignHost
from .plugins import PluginHost, PluginContext, FORBIDDEN_CAP_TOKENS

__all__ = [
    "spec", "MATRIX_ID", "RUNTIME_ID", "PROTOCOL_ID", "BUS_ID", "THREADBUS_ID", "DOMAIN",
    "VERSION", "DATE", "SECRET_OPEN", "SECRET_CLOSE",
    "SOVEREIGN_CHANNELS", "PLATFORM_FAMILIES", "INNER_PROTOCOLS", "OUTER_PROTOCOLS",
    "HyperSpace", "LogicGrid", "KalmanChannels", "HilbertLayers", "MandalaSpace",
    "seed_bipolar", "bind", "bundle", "permute", "cosine", "xor_distance", "encode_all",
    "HeartbeatHub", "HeartbeatBody", "ThreadBus", "SkinGate", "SkinV6", "Cytoskeleton",
    "SemanticBus", "HebbianField", "FLOW_EDGES", "flower_of_life_positions",
    "OntologyGraph", "QueryForge", "CORE_PROMPTS", "ONTOLOGY", "MECHANISM_TERMS",
    "AntiLabelEngine", "OfflineInjector", "STRATEGIES", "MODE_DEFS",
    "ProtocolFusion", "PlatformRegistry", "make_envelope", "INNER_MAPPING", "OUTER_MAPPING",
    "Knowledge", "SovereignHost", "PluginHost", "PluginContext", "FORBIDDEN_CAP_TOKENS",
]
