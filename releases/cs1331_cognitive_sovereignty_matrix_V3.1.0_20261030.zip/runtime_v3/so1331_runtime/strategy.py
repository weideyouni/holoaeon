# -*- coding: utf-8 -*-
"""
R2 策略域：反标签引擎 + 离线注入清单
==============================================================
口径（必须先读）：
  · 输入的"平台画像"只能来自**本人手填的观测**（例如"这周推荐里 7 成是搞笑短视频"），
    本包不抓取、不登录、不读任何平台接口，未知一律 pending_human_measure。
  · 输出只是**给本人手动执行的文本清单**：搜索框粘贴什么、读什么、点不点、何时退出。
  · 五模式（手动/定时/随机/触发/批量）全部落在"生成计划表"这一层，不产生任何自动动作；
    本包不注册定时器、不常驻、不开端口。
拒绝面：出现自动化注入、抓取、批量发帖、刷量、养号、规避风控、伪造身份等诉求 → blocked 并记录理由。
"""
from __future__ import annotations

from typing import Dict, List, Sequence

from . import spec
from .forge import QueryForge

# 自报观测 → 候选标签的朴素映射（只做启发式，不做"平台真实标签"宣称）
LABEL_HINTS = {
    "搞笑": "娱乐短视频偏好", "段子": "娱乐短视频偏好", "鬼畜": "娱乐短视频偏好",
    "明星": "明星粉丝向", "追星": "明星粉丝向", "偶像": "明星粉丝向",
    "游戏": "游戏玩家", "攻略": "游戏玩家", "开黑": "游戏玩家",
    "带货": "消费种草向", "优惠": "消费种草向", "折扣": "消费种草向",
    "八卦": "娱乐八卦向", "热点": "热点追更向", "短剧": "短剧消费向",
    "考研": "考试备考向", "编程": "技术学习向", "论文": "学术研究向",
    "健身": "健身塑形向", "菜谱": "生活技能向",
}

BLOCKED_TERMS = (
    "自动注入", "自动发帖", "批量发帖", "抓取", "刷量", "养号", "规避风控",
    "绕过验证", "伪造身份", "多账号", "破解", "接口调用", "自动登录",
)

STRATEGIES = (
    {"id": "S1", "name": "跨域跳跃", "principle": "每条查询横跨 ≥3 学科，破坏单簇收敛",
     "action": "把今日查询在搜索框粘贴后只读结果标题，不点开前三条；24h 内再换一次学科组合",
     "target": "协同过滤的簇内收敛"},
    {"id": "S2", "name": "深度不可压缩", "principle": "问题无法用单一标签回答，逼检索走向长文/论文",
     "action": "选择带'形式化/可检验/框架'字样的查询，只打开 ≥8 分钟阅读量的长文",
     "target": "点击率优化的短平快推送"},
    {"id": "S3", "name": "语义密度抬升", "principle": "用高术语密度抬认知层级评分",
     "action": "每月把 7 条核心提示词轮一遍，逐条记录返回结果里出现的学科名",
     "target": "停留时长陷阱"},
    {"id": "S4", "name": "身份自述", "principle": "用自然语言直接声明'我是谁、我学什么、我拒绝什么'",
     "action": "每周一次，在可发布文本的平台（笔记/签名/自述）粘贴身份声明，不改写为用户画像腔",
     "target": "隐式反馈形成的刻板标签"},
    {"id": "S5", "name": "反隐式反馈", "principle": "只搜不点、深度浏览后退出，减少滑动/回看信号",
     "action": "检索后不滑动信息流；读完目标长文立即退出，不在推荐位停留",
     "target": "滑动/暂停/回看等隐式信号"},
    {"id": "S6", "name": "多端一致性", "principle": "同一周内多个平台注入同一组跨域查询",
     "action": "把同一查询在不同端各粘贴一次，记录各端返回的第一屏学科差异",
     "target": "多端打通后的统一画像"},
    {"id": "S7", "name": "不可预测跳跃", "principle": "用不可预测的学科跳跃让模型无法收敛到错误局部最优",
     "action": "按 plan 表的时间窗执行，相邻两条查询的学科集合至少换掉 2 个",
     "target": "A/B 动态调参"},
)


def blocked_reason(text: str) -> str:
    t = (text or "")
    for w in BLOCKED_TERMS:
        if w in t:
            return f"命中拒绝词：{w}（本包不提供自动化/抓取/刷量/规避风控能力）"
    return ""


class AntiLabelEngine:
    """反标签引擎：自报观测 → 候选标签 → 反制计划 → 手填观测校准。"""

    def __init__(self, target_identity: str = "polymath_lifelong_learner",
                 observations: Sequence[str] | None = None):
        self.target_identity = target_identity
        self.observations = list(observations or [])

    # ---- 1) 候选标签（只启发式，不宣称平台真实标签）
    def infer_labels(self) -> dict:
        if not self.observations:
            return {"labels": [], "status": "pending_human_measure",
                    "note": "未提供本人手填观测，无法推断任何标签"}
        hits: Dict[str, int] = {}
        for obs in self.observations:
            for kw, label in LABEL_HINTS.items():
                if kw in obs:
                    hits[label] = hits.get(label, 0) + 1
        total = sum(hits.values()) or 1
        labels = [{"label": k, "share": round(v / total, 4), "evidence": v}
                  for k, v in sorted(hits.items(), key=lambda x: -x[1])]
        return {"labels": labels, "status": "heuristic_only",
                "note": "启发式推断，非平台真实标签；仅用于自选反制策略"}

    # ---- 2) 反制计划
    def disruption_plan(self) -> List[dict]:
        top = self.infer_labels()["labels"]
        hot = top[0]["label"] if top else "（未知，按默认）"
        out = []
        for s in STRATEGIES:
            item = dict(s)
            item["reason"] = f"针对候选标签『{hot}』" if top else "默认覆盖"
            item["execution"] = "human_manual"
            item["simulated"] = True
            out.append(item)
        return out

    # ---- 3) 校准（依据本人手填观测，不用平台数据）
    def calibrate(self, feedback: str) -> dict:
        bad = blocked_reason(feedback)
        if bad:
            return {"ok": False, "reason": bad}
        t = feedback or ""
        if any(w in t for w in ("仍低质", "还是低质", "没变化", "依旧")) or "低质" in t:
            return {"ok": True, "action": "提高 S1 跨域跳跃与 S7 不可预测跳跃频率；S3 每周一轮改两轮",
                    "priority": ["S1", "S7", "S3"]}
        if any(w in t for w in ("更好", "变好", "出现", "长文", "论文")) or "改善" in t:
            return {"ok": True, "action": "维持当前节奏，S4 身份自述改为两周一次以降低重复痕迹",
                    "priority": ["S4"]}
        return {"ok": True, "action": "证据不足：先补齐一周观测表，再调整节奏",
                "priority": []}

    def verify(self) -> dict:
        a = AntiLabelEngine(observations=["推荐里 8 成是搞笑段子", "偶尔推明星八卦"])
        lab = a.infer_labels()
        plan = a.disruption_plan()
        empty = AntiLabelEngine().infer_labels()
        cal1 = a.calibrate("推送还是低质")
        cal2 = a.calibrate("这周多了两篇长文，感觉改善")
        cal3 = a.calibrate("帮我自动注入到所有平台")
        return {
            "labels": len(lab["labels"]),
            "top_label": lab["labels"][0]["label"] if lab["labels"] else None,
            "plan_items": len(plan),
            "all_manual": all(p["execution"] == "human_manual" for p in plan),
            "empty_pending": empty["status"] == "pending_human_measure",
            "calibrate_escalate": bool(cal1["priority"]),
            "calibrate_maintain": bool(cal2["priority"]),
            "blocks_automation": cal3["ok"] is False,
            "ok": (
                len(lab["labels"]) >= 2
                and lab["labels"][0]["label"] == "娱乐短视频偏好"
                and len(plan) == len(STRATEGIES) == 7
                and all(p["execution"] == "human_manual" for p in plan)
                and empty["status"] == "pending_human_measure"
                and bool(cal1["priority"]) and bool(cal2["priority"])
                and cal3["ok"] is False
            ),
        }


MODE_DEFS = (
    ("manual", "手动模式", "本人复制查询到搜索框", "日常"),
    ("scheduled", "定时模式", "按本地计划表的时间窗执行（计划表≠定时器）", "长期维护"),
    ("random", "随机模式", "种子生成随机时间窗，避免固定节律", "增加不可预测性"),
    ("trigger", "触发模式", "本人察觉推送降级后手工追加一条跨域查询", "反制降级"),
    ("batch", "批量模式", "同一查询在多平台各贴一次（各平台由本人手动操作）", "跨端一致性"),
)


class OfflineInjector:
    """离线注入器：只生成清单，不执行任何动作。"""

    def __init__(self, forge: QueryForge | None = None):
        self.forge = forge or QueryForge()

    def modes(self) -> List[dict]:
        return [{"mode": m, "name": n, "how": h, "scene": s, "execution": "human_manual"}
                for m, n, h, s in MODE_DEFS]

    def build(self, mode: str = "manual", seed: str = "0", platforms: Sequence[str] | None = None,
              days: int = 3, per_day: int = 2) -> dict:
        tips = blocked_reason(mode)
        if tips:
            return {"ok": False, "reason": tips}
        if mode not in {m[0] for m in MODE_DEFS}:
            raise KeyError(mode)
        items: List[dict] = []
        plats = list(platforms or ["抖音", "Bilibili", "知乎", "豆包"])
        if mode in ("manual", "batch", "trigger"):
            q = self.forge.generate(seed)
            for p in plats:
                items.append({"platform": p, "query": q["text"], "density": q["density"],
                              "action": "粘贴到搜索框，只读标题与摘要，不点推荐位"})
        elif mode == "scheduled":
            for row in self.forge.plan(seed, days, per_day):
                q = self.forge.generate(row["seed"])
                items.append({"platform": plats[0], "clock": row["clock"],
                              "day_offset": row["day_offset"], "query": q["text"],
                              "density": q["density"], "action": "到点手工粘贴"})
        else:  # random
            for i in range(days * per_day):
                q = self.forge.generate(f"{seed}-r{i}")
                h = int(q["density"]["score"] * 1000) % 24
                items.append({"platform": plats[i % len(plats)], "clock": f"{h:02d}:{(i * 7) % 60}",
                              "query": q["text"], "density": q["density"],
                              "action": "随机窗内手工粘贴"})
        return {"ok": True, "mode": mode, "items": items,
                "execution": "human_manual", "auto": False, "simulated": True}

    def verify(self) -> dict:
        inj = OfflineInjector()
        b = inj.build("batch", "3", ["抖音", "Bilibili", "知乎"])
        s = inj.build("scheduled", "4", ["Bilibili"], 3, 2)
        r = inj.build("random", "5", ["知乎"], 2, 2)
        m = inj.build("manual", "6")
        bad = inj.build("自动注入")
        return {
            "modes": len(inj.modes()),
            "batch_items": len(b["items"]),
            "scheduled_items": len(s["items"]),
            "random_items": len(r["items"]),
            "no_auto": all(x.get("auto") is False and x.get("execution") == "human_manual"
                           for x in (b, s, r, m)),
            "unknown_mode_rejected": bad["ok"] is False,
            "ok": (
                len(inj.modes()) == 5
                and len(b["items"]) == 3
                and len(s["items"]) == 6
                and len(r["items"]) == 4
                and all(x["auto"] is False for x in (b, s, r, m))
                and bad["ok"] is False
            ),
        }
