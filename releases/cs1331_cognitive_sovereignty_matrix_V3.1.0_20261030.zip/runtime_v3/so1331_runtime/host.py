# -*- coding: utf-8 -*-
"""
认知主权宿主（Sovereign Host）—— R0-R4 五阶闭环
==============================================================
R0 编码  ：张量向量化（超向量 + 1331×1331 逻辑网格 + 卡尔曼 17 通道 + 希尔伯特 6 层 + 曼陀罗）
R1 锻造  ：跨域查询 + 身份自述（确定性、可复现、可 cosine 比较）
R2 策略  ：反标签计划 + 五模式离线清单（全部 human_manual）
R3 互操作：12 内 × 11 外 = 132 映射单元（不联网）
R4 合规  ：皮肤八层闸门 + 审计指纹 + 平台数据 pending_human_measure + 碳基终裁
任何一阶缺项即 round_ok=False；每阶产物带 simulated=True。
"""
from __future__ import annotations

import hashlib
import json
from typing import Dict, List

from . import spec
from .tensor import HyperSpace, LogicGrid, KalmanChannels, HilbertLayers, MandalaSpace
from .heartbeat_engine import HeartbeatHub
from .threadbus import ThreadBus
from .skin import SkinGate, Cytoskeleton
from .semantic_bus import SemanticBus
from .forge import QueryForge, OntologyGraph, CORE_PROMPTS
from .strategy import AntiLabelEngine, OfflineInjector
from .interop import ProtocolFusion, PlatformRegistry, make_envelope
from .hebbian_field import HebbianField


class SovereignHost:
    """五阶闭环宿主：只做本地仿真，不触达任何平台。"""

    def __init__(self, seed: str = "0"):
        self.seed = seed
        self.bus = ThreadBus()
        self.hub = HeartbeatHub()
        self.skin = SkinGate()
        self.skel = Cytoskeleton()
        self.sem = SemanticBus()
        self.forge = QueryForge(OntologyGraph())
        self.injector = OfflineInjector(self.forge)
        self.pf = ProtocolFusion()
        self.reg = PlatformRegistry()
        self.field = HebbianField()
        self.tensor = {"hyper": HyperSpace(), "grid": LogicGrid(), "kalman": KalmanChannels(),
                       "hilbert": HilbertLayers(), "mandala": MandalaSpace(MandalaSpace.default_allocations())}
        self.rounds = 0

    # ---------------------------------------------------------------- R0 编码
    def stage_r0(self) -> dict:
        hs: HyperSpace = self.tensor["hyper"]
        grid: LogicGrid = self.tensor["grid"]
        kal: KalmanChannels = self.tensor["kalman"]
        hil: HilbertLayers = self.tensor["hilbert"]
        grid.sweep()
        kal.sweep()
        hil.sweep()
        triple = hs.encode("数学", "映射到", "人工智能")
        return {
            "stage": "R0",
            "hyper_ok": hs.verify()["ok"],
            "grid_occupied": grid.occupied(),
            "grid_density": round(grid.density(), 6),
            "kalman_channels": len(kal.state),
            "hilbert_placed": len(hil.nodes),
            "triple_cosine": round(hs.similarity("数学", "人工智能"), 4),
            "triple_recover": round(hs.recover(triple, "映射到") == hs.get("人工智能"), 4),
            "simulated": True,
        }

    # ---------------------------------------------------------------- R1 锻造
    def stage_r1(self) -> dict:
        queries = [self.forge.generate(f"{self.seed}-q{i}", k=3 + i % 2) for i in range(3)]
        ident = self.forge.identity_statement(self.seed)
        return {
            "stage": "R1",
            "queries": [{"text": q["text"], "domains": q["domains"],
                         "density": q["density"]["score"]} for q in queries],
            "identity": {"text": ident["text"], "density": ident["density"]["score"]},
            "core_prompts_available": len(CORE_PROMPTS),
            "deterministic": queries[0]["text"] == self.forge.generate(f"{self.seed}-q0", k=3)["text"],
            "simulated": True,
        }

    # ---------------------------------------------------------------- R2 策略
    def stage_r2(self, observations: List[str] | None = None) -> dict:
        obs = observations if observations is not None else [
            "本周推荐里约七成是搞笑短视频", "偶尔推送明星八卦与带货",
        ]
        engine = AntiLabelEngine(observations=obs)
        labels = engine.infer_labels()
        plan = engine.disruption_plan()
        inj = self.injector.build("manual", self.seed,
                                 ["抖音", "Bilibili", "知乎", "豆包", "ChatGPT"])
        return {
            "stage": "R2",
            "labels": labels,
            "plan_items": len(plan),
            "all_manual": all(p["execution"] == "human_manual" for p in plan),
            "injector_items": len(inj["items"]),
            "injector_auto": inj["auto"],
            "simulated": True,
        }

    # ---------------------------------------------------------------- R3 互操作
    def stage_r3(self) -> dict:
        env = make_envelope("forge", "platform_adapter_registry", {"q": self.seed})
        m = self.pf.matrix()
        cov = self.reg.family_coverage()
        return {
            "stage": "R3",
            "envelope_id": env["id"],
            "matrix_cells": m["cells"],
            "inner": m["inner"],
            "outer": m["outer"],
            "platform_families": len(cov),
            "platform_members_total": sum(cov.values()),
            "oa_avatar_total": len(self.reg.avatars),
            "executors": len(self.reg.executors),
            "network": False,
            "simulated": True,
        }

    # ---------------------------------------------------------------- R4 合规
    def stage_r4(self, texts: List[str]) -> dict:
        verdict = []
        for t in texts:
            r = self.skin.pipeline(t)
            verdict.append({"allowed": r["gate"]["allowed"], "veto": r["gate"]["veto"],
                            "e13": r["gate"]["e13_words"], "e14": r["gate"]["e14_words"]})
        audit = hashlib.sha256(
            json.dumps({"texts": texts, "seed": self.seed}, ensure_ascii=False,
                       sort_keys=True).encode("utf-8")).hexdigest()[:16]
        return {
            "stage": "R4",
            "texts_checked": len(texts),
            "all_allowed": all(v["allowed"] for v in verdict),
            "verdicts": verdict,
            "audit": audit,
            "platform_metrics": {"status": "pending_human_measure",
                                "policy": spec.PLATFORM_DATA_POLICY},
            "human_final": True,
            "simulated": True,
        }

    # ---------------------------------------------------------------- 一轮
    def run_round(self, observations: List[str] | None = None) -> dict:
        self.rounds += 1
        hb = self.hub.run_round()
        r0 = self.stage_r0()
        r1 = self.stage_r1()
        r2 = self.stage_r2(observations)
        r3 = self.stage_r3()
        texts = [q["text"] for q in r1["queries"]] + [r1["identity"]["text"]]
        r4 = self.stage_r4(texts)
        self.field.coactivate(["tensor_vector_encoding", "query_forging",
                               "anti_stereotype_strategy", "compliance_gate"])
        stages = {"R0": r0, "R1": r1, "R2": r2, "R3": r3, "R4": r4}
        round_ok = (
            r0["hyper_ok"] and r0["kalman_channels"] == 17
            and len(r1["queries"]) == 3 and r1["deterministic"]
            and r2["plan_items"] == 7 and r2["all_manual"] and r2["injector_auto"] is False
            and r3["matrix_cells"] == 132 and r3["network"] is False
            and r4["all_allowed"] and len(r4["audit"]) == 16
        )
        return {
            "round": self.rounds,
            "seed": self.seed,
            "domain": self.bus.domain,
            "heartbeat": {"bodies": len(hb), "scan": self.hub.scan()},
            "stages": stages,
            "hebbian": self.field.summary(),
            "semantic": self.sem.header("编码 锻造 策略 协议 平台 合规 审计 心跳 运维"),
            "round_ok": round_ok,
            "threadbus": self.bus.bus_id,
            "simulated": True,
        }

    def verify(self) -> dict:
        host = SovereignHost("0")
        rd = host.run_round()
        st = rd["stages"]
        return {
            "round_ok": rd["round_ok"],
            "stages": sorted(st.keys()),
            "heartbeat_healthy": rd["heartbeat"]["scan"]["healthy"],
            "hebbian_rounds": rd["hebbian"]["rounds"],
            "audit": st["R4"]["audit"],
            "no_network": st["R3"]["network"] is False,
            "platform_pending": st["R4"]["platform_metrics"]["status"] == "pending_human_measure",
            "all_simulated": all(st[s]["simulated"] for s in st),
            "skeleton_ok": host.skel.verify()["ok"],
            "ok": (
                rd["round_ok"] and rd["domain"] == "sovereign"
                and sorted(st.keys()) == ["R0", "R1", "R2", "R3", "R4"]
                and rd["heartbeat"]["scan"]["healthy"]
                and st["R3"]["network"] is False
                and st["R4"]["platform_metrics"]["status"] == "pending_human_measure"
                and all(st[s]["simulated"] for s in st)
                and host.skel.verify()["ok"]
                and len(st["R4"]["audit"]) == 16
            ),
        }
