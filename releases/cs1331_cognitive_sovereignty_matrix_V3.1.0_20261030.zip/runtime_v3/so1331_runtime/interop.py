# -*- coding: utf-8 -*-
"""
R3 互操作域：内外协议融通 + 平台族注册表
==============================================================
1) ProtocolFusion：把 12 条内部协议（Envelope/Bus/Skill/Memory/Scheduler/Skin/Graph/
   Cluster/Hypervector/ModelAdapter/ThreadBus/SO-DATAPROTO）与 11 个外部协议族
   （HTTP / OpenAPI / GraphQL / gRPC / 实时推送 / MCP / A2A / 大模型 API / 订阅分发 /
   身份授权 / 开放社交）统一到**一个信封**做确定性映射。
   —— 只产出映射表与字段对应，**不发起任何网络请求**；family 里列的是"若接线时的字段口径"。
2) PlatformRegistry：10 个平台族（短视频/长视频/图文/搜索/社交/电商/知识/大模型国内/
   大模型海外/开发者）× 13 职责 = 130 分身，加 26 专项 + 12 桥接 = 168；
   70 执行体绑定心跳号 9700-9769，与 17 通道一一落位。
说明：平台族只是"人手动要去的入口清单"，本包不登录、不抓取、不代操作。
"""
from __future__ import annotations

import hashlib
from typing import Dict, List, Sequence

from . import spec

# 内部信封字段（12 条内部协议共享的最小公共面）
ENVELOPE_FIELDS = ("id", "type", "sender", "receiver", "payload", "trace", "simulated")


def make_envelope(sender: str, receiver: str, payload: Dict[str, object],
                  etype: str = "query", trace: str = "") -> dict:
    raw = f"{sender}|{receiver}|{etype}|{sorted(payload.keys())}|{trace}"
    return {
        "id": hashlib.sha256(f"{spec.DOMAIN}:{raw}".encode("utf-8")).hexdigest()[:16],
        "type": etype,
        "sender": sender,
        "receiver": receiver,
        "payload": dict(payload),
        "trace": trace or "local-only",
        "simulated": True,
    }


# 外部族 → 信封字段映射口径 + 有损点（离线声明，不联网）
OUTER_MAPPING = {
    "HTTP":       (["method", "path", "headers", "body(JSON)"], "无会话态；trace 需落到 header"),
    "OPENAPI":    (["operationId", "requestBody", "responses"], "schema 与 payload 需类型对齐"),
    "GRAPHQL":    (["query", "variables", "operationName"], "多字段嵌套需展平到 payload"),
    "GRPC":       (["service", "method", "proto-message"], "二进制需序列化层"),
    "REALTIME":   (["channel", "event", "seq"], "流式语义需 seq 补偿"),
    "MCP":        (["tool.name", "tool.args", "tool.result"], "工具边界需能力白名单"),
    "A2A":        (["agentCard", "task.id", "task.state"], "状态机需与信封 type 对齐"),
    "LLMAPI":     (["model", "messages", "temperature", "usage"], "模型侧按键计费/配额，需本人自担"),
    "FEED":       (["feed.title", "entry.id", "entry.updated"], "时效性靠 updated 补偿"),
    "IDENTITY":   (["grant", "subject", "scope", "expiry"], "授权由本人完成，本包不持有凭证"),
    "FEDIVERSE":  (["actor", "object", "activity"], "联邦语义需 actor 映射"),
}

INNER_MAPPING = {
    "ENV":  ["id", "type", "sender", "receiver", "payload", "trace", "simulated"],
    "BUS":  ["topic", "subscriber", "delivery"],
    "SKL":  ["skill.name", "inputs", "outputs", "tags"],
    "MEM":  ["layer(working|longterm|archive)", "key", "value", "ttl"],
    "HBT":  ["uid", "strength", "rhythm", "status"],
    "SKN":  ["layer L1-L8", "verdict", "veto"],
    "GRP":  ["nodes", "edges", "path"],
    "CLS":  ["shard", "mailbox", "barrier"],
    "HVEC": ["dim", "vector", "op(bind|bundle|permute)"],
    "MADP": ["backend", "route-policy", "format-mask"],
    "TBUS": ["domain(sovereign)", "round"],
    "SODP": ["lock", "csv", "sha256", "simulated"],
}


class ProtocolFusion:
    """23 协议族融通：统一信封 + 双向映射（离线）。"""

    def __init__(self):
        self.inner = spec.INNER_PROTOCOLS
        self.outer = spec.OUTER_PROTOCOLS

    def inner_keys(self) -> List[str]:
        return [p[0] for p in self.inner]

    def outer_keys(self) -> List[str]:
        return [p[0] for p in self.outer]

    def map_outer(self, family: str, envelope: dict) -> dict:
        if family not in OUTER_MAPPING:
            raise KeyError(f"未知外部协议族：{family}")
        fields, lossy = OUTER_MAPPING[family]
        return {
            "family": family,
            "family_name": next(p[1] for p in self.outer if p[0] == family),
            "concrete_protocols": next(p[2] for p in self.outer if p[0] == family),
            "fields": fields,
            "lossy": lossy,
            "envelope_id": envelope["id"],
            "network": False,
            "simulated": True,
        }

    def map_inner(self, key: str, envelope: dict) -> dict:
        if key not in INNER_MAPPING:
            raise KeyError(f"未知内部协议：{key}")
        return {"protocol": key, "fields": INNER_MAPPING[key],
                "envelope_id": envelope["id"], "simulated": True}

    def matrix(self) -> dict:
        """12 内部 × 11 外部 = 132 个可映射单元（不联网，只出表）。"""
        env = make_envelope("forge", "platform_adapter_registry", {"q": "示例"})
        cells = []
        for ik in self.inner_keys():
            for ok in self.outer_keys():
                cells.append({"inner": ik, "outer": ok,
                              "lossy": OUTER_MAPPING[ok][1]})
        return {"cells": len(cells), "env": env,
                "inner": len(self.inner_keys()), "outer": len(self.outer_keys())}

    def verify(self) -> dict:
        pf = ProtocolFusion()
        env = make_envelope("forge", "platform_adapter_registry", {"q": "示例"})
        m = pf.matrix()
        outer_ok = all(pf.map_outer(k, env)["network"] is False for k in pf.outer_keys())
        inner_ok = all(len(INNER_MAPPING[k]) >= 2 for k in pf.inner_keys())
        unknown = False
        try:
            pf.map_outer("SOAP", env)
        except KeyError:
            unknown = True
        members_inner = sum(len(p[2]) for p in pf.inner)
        members_outer = sum(len(p[2]) for p in pf.outer)
        return {
            "inner": len(pf.inner), "outer": len(pf.outer), "total": len(pf.inner) + len(pf.outer),
            "cells": m["cells"],
            "members_inner": members_inner, "members_outer": members_outer,
            "no_network": outer_ok,
            "inner_ok": inner_ok,
            "unknown_rejected": unknown,
            "envelope_fields": len(env) == 7,
            "ok": (
                len(pf.inner) == 12 and len(pf.outer) == 11 and len(pf.inner) + len(pf.outer) == 23
                and m["cells"] == 132
                and outer_ok and inner_ok and unknown
                and members_inner >= 30 and members_outer >= 40
                and len(env) == 7
            ),
        }


class PlatformRegistry:
    """平台族 → 168 分身（130 + 26 + 12）→ 70 执行体（9700-9769）。"""

    def __init__(self):
        self.families = spec.PLATFORM_FAMILIES
        self.duties = spec.AVATAR_DUTIES
        self.avatars: List[dict] = self._build_avatars()
        self.executors: List[dict] = self._build_executors()

    def _build_avatars(self) -> List[dict]:
        out = []
        idx = 0
        for fam_key, fam_cn, members in self.families:
            for duty in self.duties:
                idx += 1
                out.append({
                    "avatar_id": f"AV-{idx:03d}",
                    "kind": "group",
                    "family": fam_key,
                    "family_cn": fam_cn,
                    "duty": duty,
                    "entry_platforms": list(members),
                    "name": f"{fam_cn}·{duty}分身",
                })
        for name in spec.SPECIAL_AVATARS:
            idx += 1
            out.append({"avatar_id": f"AV-{idx:03d}", "kind": "special",
                        "family": "cross", "family_cn": "专项",
                        "duty": name, "entry_platforms": [], "name": f"{name}分身"})
        for name in spec.BRIDGE_AVATARS:
            idx += 1
            out.append({"avatar_id": f"AV-{idx:03d}", "kind": "bridge",
                        "family": "bridge", "family_cn": "桥接",
                        "duty": name, "entry_platforms": [], "name": name})
        return out

    def _build_executors(self) -> List[dict]:
        out = []
        chans = spec.SOVEREIGN_CHANNELS
        for i in range(spec.EXECUTOR_TOTAL):
            fam = self.families[i % len(self.families)]
            chan = chans[i % len(chans)]
            out.append({
                "executor_id": f"EX-{spec.HEARTBEAT_BASE + i}",
                "heartbeat": spec.HEARTBEAT_BASE + i,
                "family": fam[0],
                "channel": chan,
                "duty": self.duties[i % len(self.duties)],
                "permission": 0 if chan != "human_final_arbiter" else 4,
            })
        return out

    def counts(self) -> dict:
        by_kind = {}
        for a in self.avatars:
            by_kind[a["kind"]] = by_kind.get(a["kind"], 0) + 1
        return by_kind

    def family_coverage(self) -> dict:
        return {k: len(v) for k, _, v in [(f[0], f[1], f[2]) for f in self.families]}

    def verify(self) -> dict:
        pr = PlatformRegistry()
        c = pr.counts()
        return {
            "avatars": len(pr.avatars),
            "groups": c.get("group", 0),
            "special": c.get("special", 0),
            "bridge": c.get("bridge", 0),
            "families": len(pr.families),
            "duties": len(pr.duties),
            "executors": len(pr.executors),
            "hb_first": pr.executors[0]["heartbeat"],
            "hb_last": pr.executors[-1]["heartbeat"],
            "coverage": pr.family_coverage(),
            "all_families_members": all(len(f[2]) == 13 for f in pr.families),
            "ok": (
                len(pr.avatars) == 168 and c.get("group") == 130 and c.get("special") == 26
                and c.get("bridge") == 12
                and len(pr.families) == 10 and len(pr.duties) == 13
                and len(pr.executors) == 70
                and pr.executors[0]["heartbeat"] == 9700 and pr.executors[-1]["heartbeat"] == 9769
                and all(len(f[2]) == 13 for f in pr.families)
                and len(pr.family_coverage()) == 10
            ),
        }
