# -*- coding: utf-8 -*-
"""
ThreadBus —— 认知主权线程总线（域锁 sovereign）
==============================================================
线程域锁：任何线程创建时绑定 domain=sovereign，越域创建直接 ValueError。
只做本地进程内的一致性标记，不联网、不开端口、不常驻。
"""
from __future__ import annotations

import hashlib
import time
from typing import Dict

from .spec import DOMAIN, BUS_ID, THREADBUS_ID, SECRET_OPEN, SECRET_CLOSE


class ThreadBus:
    """域锁总线：域必须是 sovereign，否则拒绝。"""

    def __init__(self, domain: str = DOMAIN):
        if domain != DOMAIN:
            raise ValueError(f"ThreadBus 域锁拒绝：{domain} != {DOMAIN}")
        self.domain = domain
        self.bus_id = THREADBUS_ID
        self.spec_bus = BUS_ID
        self.created = time.time()
        self.round = 0
        self.secret_open = SECRET_OPEN
        self.secret_close = SECRET_CLOSE

    def heartbeat(self) -> Dict[str, object]:
        self.round += 1
        return {
            "domain": self.domain,
            "threadbus_id": self.bus_id,
            "bus_id": self.spec_bus,
            "round": self.round,
            "epoch": round(time.time() - self.created, 3),
            "closed": False,
        }

    def channel_key(self, name: str) -> str:
        return hashlib.sha256(f"{self.domain}:{name}".encode("utf-8")).hexdigest()[:12]

    def seal(self) -> Dict[str, str]:
        return {"open": self.secret_open, "close": self.secret_close,
                "simulated": "true"}

    def verify(self) -> dict:
        bus = ThreadBus()
        hb = bus.heartbeat()
        crossed = True
        try:
            ThreadBus(domain="other")
        except ValueError:
            crossed = False
        return {
            "domain": bus.domain,
            "bus_id": bus.bus_id,
            "heartbeat": hb,
            "cross_domain_rejected": crossed is False,
            "ok": (
                bus.domain == "sovereign"
                and bus.bus_id == "SO-THREADBUS-V1.0"
                and hb["domain"] == "sovereign"
                and crossed is False
            ),
        }
