# -*- coding: utf-8 -*-
"""
赫布协作场（SG-HEBBIAN-FIELD-FOL-V1.0，生命之花）—— 认知主权版
==============================================================
17 个能力域（SO01-SO17 = 卡尔曼 17 通道）在 R0-R4 闭环中"共同激活"，
按"fire together, wire together"沉淀能力域间的协作权重。
- 拓扑：生命之花 19 圆（中心 1 + 内 6 + 外 12），17 通道投影到前 17 圆，几何相邻给 GEOM_W。
- 先验边：28 条闭环流边（编码→锻造→策略→互操作→合规→终裁回流）。
- 学习：每轮衰减 0.99，共同激活组两两 Δw=η=0.12，裁剪到 [0,1]，对称矩阵。
- 确定性：无随机、同序列重放一致。仿真≠证明。
"""
from __future__ import annotations

from . import spec

_HEX_DIRS = ((1, -1), (1, 0), (0, 1), (-1, 1), (-1, 0), (0, -1))


def _hex_dist(a: tuple, b: tuple) -> int:
    dq = a[0] - b[0]
    dr = a[1] - b[1]
    return (abs(dq) + abs(dq + dr) + abs(dr)) // 2


def flower_of_life_positions(radius: int = 2) -> list:
    """生命之花：中心 + 逐环，radius=2 共 19 圆（螺旋序）。"""
    positions = [(0, 0)]
    for r in range(1, radius + 1):
        cur = (-r, 0)
        for edge in range(6):
            for _ in range(r):
                positions.append(cur)
                d = _HEX_DIRS[edge]
                cur = (cur[0] + d[0], cur[1] + d[1])
    return positions


FLOW_EDGES = (
    ("tensor_vector_encoding", "cross_domain_binding"),
    ("cross_domain_binding", "identity_fingerprint"),
    ("identity_fingerprint", "ontology_graph_addr"),
    ("tensor_vector_encoding", "ontology_graph_addr"),
    ("ontology_graph_addr", "query_forging"),
    ("cross_domain_binding", "query_forging"),
    ("query_forging", "template_engine"),
    ("template_engine", "semantic_density"),
    ("semantic_density", "unpredictability_schedule"),
    ("query_forging", "unpredictability_schedule"),
    ("query_forging", "label_profile_inference"),
    ("identity_fingerprint", "label_profile_inference"),
    ("label_profile_inference", "anti_stereotype_strategy"),
    ("anti_stereotype_strategy", "feedback_loop_calibration"),
    ("semantic_density", "feedback_loop_calibration"),
    ("unpredictability_schedule", "feedback_loop_calibration"),
    ("anti_stereotype_strategy", "platform_adapter_registry"),
    ("template_engine", "platform_adapter_registry"),
    ("inner_protocol_fusion", "outer_protocol_fusion"),
    ("outer_protocol_fusion", "platform_adapter_registry"),
    ("ontology_graph_addr", "inner_protocol_fusion"),
    ("identity_fingerprint", "compliance_gate"),
    ("platform_adapter_registry", "compliance_gate"),
    ("compliance_gate", "audit_reproducibility"),
    ("audit_reproducibility", "human_final_arbiter"),
    ("compliance_gate", "human_final_arbiter"),
    ("human_final_arbiter", "tensor_vector_encoding"),
    ("audit_reproducibility", "query_forging"),
)

GEOM_W = 0.10
FLOW_W = 0.20


class HebbianField:
    """生命之花赫布协作场：17 节点、对称权重、共同激活增强、衰减。"""

    def __init__(self, channels=spec.SOVEREIGN_CHANNELS,
                 lr: float = spec.HEBBIAN_LR,
                 decay: float = spec.HEBBIAN_DECAY,
                 clip: float = spec.HEBBIAN_CLIP):
        self.channels = list(channels)
        self.n = len(self.channels)
        self.idx = {c: i for i, c in enumerate(self.channels)}
        self.lr = lr
        self.decay = decay
        self.clip = clip
        self.rounds = 0
        self.positions = flower_of_life_positions(2)
        self.W = [[0.0] * self.n for _ in range(self.n)]
        self._seed_edges()

    def _seed_edges(self) -> None:
        for i in range(self.n):
            for j in range(i + 1, self.n):
                if _hex_dist(self.positions[i], self.positions[j]) == 1:
                    self._set(i, j, GEOM_W)
        for a, b in FLOW_EDGES:
            if a in self.idx and b in self.idx:
                i, j = self.idx[a], self.idx[b]
                self._set(i, j, max(self.W[i][j], FLOW_W))

    def _set(self, i: int, j: int, w: float) -> None:
        if i == j:
            return
        self.W[i][j] = self.W[j][i] = float(w)

    def weight(self, a: str, b: str) -> float:
        return self.W[self.idx[a]][self.idx[b]]

    def coactivate(self, group) -> dict:
        """一组能力域共同激活：组内两两增强，其余衰减。"""
        self.rounds += 1
        ids = [self.idx[g] for g in group if g in self.idx]
        before = {self.channels[i]: [self.W[i][j] for j in range(self.n)] for i in ids}
        for i in range(self.n):
            for j in range(i + 1, self.n):
                w = self.W[i][j] * self.decay
                if i in ids and j in ids:
                    w += self.lr
                self.W[i][j] = self.W[j][i] = max(0.0, min(self.clip, round(w, 6)))
        after = {self.channels[i]: [self.W[i][j] for j in range(self.n)] for i in ids}
        changed = sum(1 for i in ids for j in ids if before[self.channels[i]][j] != after[self.channels[i]][j])
        return {"round": self.rounds, "group": [self.channels[i] for i in ids],
                "changed_cells": changed, "simulated": True}

    def strongest(self, node: str, k: int = 3) -> list:
        i = self.idx[node]
        rows = sorted(((self.W[i][j], self.channels[j]) for j in range(self.n) if j != i),
                      reverse=True)
        return [(name, round(w, 4)) for w, name in rows[:k]]

    def summary(self) -> dict:
        pairs = [(a, b) for a in self.channels for b in self.channels if a < b]
        ws = [self.weight(a, b) for a, b in pairs]
        return {"nodes": self.n, "rounds": self.rounds,
                "mean_weight": round(sum(ws) / len(ws), 6),
                "max_weight": max(ws), "active_edges": sum(1 for w in ws if w > 0),
                "simulated": True}

    def verify(self) -> dict:
        h = HebbianField()
        # 19 圆几何拓扑总边数（母体口径：生命之花 19 圆 = 42 条几何邻接）
        geom_all = 0
        for i in range(len(h.positions)):
            for j in range(i + 1, len(h.positions)):
                if _hex_dist(h.positions[i], h.positions[j]) == 1:
                    geom_all += 1
        # 17 能力节点之间的几何边（节点=前 17 圆）
        node_edges = 0
        for i in range(h.n):
            for j in range(i + 1, h.n):
                if _hex_dist(h.positions[i], h.positions[j]) == 1:
                    node_edges += 1
        center_deg = sum(1 for j in range(1, len(h.positions))
                         if _hex_dist(h.positions[0], h.positions[j]) == 1)
        before = h.weight("tensor_vector_encoding", "cross_domain_binding")
        h.coactivate(["tensor_vector_encoding", "cross_domain_binding", "identity_fingerprint"])
        after = h.weight("tensor_vector_encoding", "cross_domain_binding")
        h2 = HebbianField()
        h2.coactivate(["tensor_vector_encoding", "cross_domain_binding", "identity_fingerprint"])
        symmetric = all(abs(h.W[i][j] - h.W[j][i]) < 1e-12 for i in range(h.n) for j in range(h.n))
        diag_zero = all(h.W[i][i] == 0.0 for i in range(h.n))
        in_range = all(0.0 <= w <= 1.0 for row in h.W for w in row)
        return {
            "nodes": h.n,
            "fol_circles": len(h.positions),
            "fol_center_degree": center_deg,
            "fol_edges_19": geom_all,
            "node_edges_17": node_edges,
            "flow_edges": len(FLOW_EDGES),
            "symmetric": symmetric,
            "diagonal_zero": diag_zero,
            "weights_in_range": in_range,
            "hebbian_potentiation": after > before,
            "decay_present": h.decay < 1.0,
            "deterministic": all(abs(a - b) < 1e-12 for a, b in zip(h.W[0], h2.W[0])),
            "ok": (
                h.n == spec.HEBBIAN_NODES == 17
                and len(h.positions) == spec.HEBBIAN_FOL_CIRCLES == 19
                and center_deg == 6
                and geom_all == 42
                and node_edges == 36
                and len(FLOW_EDGES) == 28
                and symmetric and diag_zero and in_range
                and after > before and h.decay < 1.0
                and all(abs(a - b) < 1e-12 for a, b in zip(h.W[0], h2.W[0]))
            ),
        }
