# -*- coding: utf-8 -*-
"""
张量向量化层（Tensor / Vector Encoding）—— 认知主权矩阵 R0 编码域
==============================================================
三件事，全部纯标准库、确定性、离线：
  1) 超向量 HRR：768 维双极（±1）超向量，bind=逐元素乘、bundle=符号求和的多数表决、
     permute=循环移位、cosine=余弦相似度。同一名字永远得到同一向量（sha256 派生）。
  2) 逻辑网格 1331×1331：构造时**不预分配** 1,771,561 个格，只维护稀疏激活字典；
     地址 = (平台族序号×17 + 通道序号) mod 1331 为行、(协议族序号) mod 1331 为列。
  3) 三处空间：卡尔曼 17 通道（α=0.18 指数平滑）／希尔伯特 6 层（每层 108,641 容量、
     稀疏占用）／曼陀罗 10 行（9 域 + 合计 108,641）。
说明：HRR 是**可测工程属性**（可复现、可 cosine 比较），不是"平台认知已改变"的证明。
"""
from __future__ import annotations

import hashlib
from typing import Dict, Iterable, List, Tuple

from . import spec

_EPS = 1e-12


# ---------------------------------------------------------------- 超向量
def seed_bipolar(name: str, dim: int = spec.HEARTBEAT_DIM) -> List[int]:
    """确定性双极向量：同名同维必得同一串 ±1。"""
    out: List[int] = []
    counter = 0
    while len(out) < dim:
        digest = hashlib.sha256(f"{spec.DOMAIN}:{name}:{counter}".encode("utf-8")).digest()
        for b in digest:
            out.append(1 if b & 0x80 else -1)
            if len(out) >= dim:
                break
        counter += 1
    return out


def bind(a: List[int], b: List[int]) -> List[int]:
    """绑定（圆卷积的简化代表：逐元素乘，保持正交性）。"""
    if len(a) != len(b):
        raise ValueError("维度不一致")
    return [x * y for x, y in zip(a, b)]


def bundle(vectors: Iterable[List[int]]) -> List[int]:
    """叠加（多数表决，平票取 +1）。"""
    vs = list(vectors)
    if not vs:
        raise ValueError("空叠加")
    dim = len(vs[0])
    if any(len(v) != dim for v in vs):
        raise ValueError("维度不一致")
    out: List[int] = []
    for i in range(dim):
        total = sum(v[i] for v in vs)
        out.append(1 if total >= 0 else -1)
    return out


def permute(v: List[int], shift: int = 1) -> List[int]:
    """置换（循环移位，用于编码顺序/位置）。"""
    if not v:
        return []
    s = shift % len(v)
    return v[-s:] + v[:-s] if s else list(v)


def cosine(a: List[int], b: List[int]) -> float:
    """余弦相似度（双极向量等价于归一化点积）。"""
    if len(a) != len(b):
        raise ValueError("维度不一致")
    dot = sum(x * y for x, y in zip(a, b))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(y * y for y in b) ** 0.5
    return dot / (na * nb + _EPS)


def xor_distance(a: List[int], b: List[int]) -> int:
    """汉明距离（符号不一致位数）。"""
    return sum(1 for x, y in zip(a, b) if x != y)


class HyperSpace:
    """超向量空间：名字 → 固定向量，可 bind/bundle/permute 出复合语义。"""

    def __init__(self, dim: int = spec.HEARTBEAT_DIM):
        self.dim = dim
        self._cache: Dict[str, List[int]] = {}

    def get(self, name: str) -> List[int]:
        if name not in self._cache:
            self._cache[name] = seed_bipolar(name, self.dim)
        return self._cache[name]

    def encode(self, subject: str, relation: str, obj: str) -> List[int]:
        """三元组编码：bind(subject, relation) ⊕ obj（bind 自逆，故可解绑主语）。"""
        left = bind(self.get(subject), self.get(relation))
        return bundle([left, self.get(obj)])

    def similarity(self, name_a: str, name_b: str) -> float:
        return cosine(self.get(name_a), self.get(name_b))

    def recover(self, composite: List[int], relation: str) -> List[int]:
        """解绑：bind 是自逆运算，再乘一次关系向量即近似还原主语。"""
        return bind(composite, self.get(relation))

    def encode_ordered(self, subject: str, relation: str, obj: str, shift: int = 1) -> List[int]:
        """带顺序的三元组编码（用置换标注槽位）；解绑需用同一 shift 反置换。"""
        left = bind(permute(self.get(subject), shift), self.get(relation))
        return bundle([left, self.get(obj)])

    def recover_ordered(self, composite: List[int], relation: str, shift: int = 1) -> List[int]:
        rec = bind(composite, self.get(relation))
        return permute(rec, -shift)

    def verify(self) -> dict:
        a = self.get("数学")
        b = self.get("物理")
        c = self.encode("数学", "映射到", "物理")
        rec = self.recover(c, "映射到")
        same = cosine(self.get("数学"), self.get("数学"))
        other = cosine(a, b)
        ordered = self.encode_ordered("数学", "映射到", "物理")
        back = self.recover_ordered(ordered, "映射到")
        return {
            "dim": self.dim,
            "self_cosine": round(same, 6),
            "cross_cosine": round(other, 6),
            "recover_cosine": round(cosine(rec, self.get("数学")), 6),
            "ordered_recover_cosine": round(cosine(back, self.get("数学")), 6),
            "deterministic": seed_bipolar("数学", self.dim) == a,
            "bipolar": set(a) <= {1, -1},
            "ok": (
                self.dim == 768
                and abs(same - 1.0) < 1e-9
                and abs(other) < 0.2
                and cosine(rec, self.get("数学")) > 0.3
                and cosine(back, self.get("数学")) > 0.25
                and seed_bipolar("数学", self.dim) == a
                and set(a) <= {1, -1}
            ),
        }


# ---------------------------------------------------------------- 逻辑网格 1331×1331
class LogicGrid:
    """1331×1331 逻辑网格：稀疏激活，不预分配 1,771,561 个格。"""

    def __init__(self, size: int = spec.LOCK_1331):
        self.size = size
        self.design = size * size
        self.cells: Dict[Tuple[int, int], float] = {}
        self.family_keys = spec.family_keys()
        self.protocol_keys = tuple(p[0] for p in spec.INNER_PROTOCOLS + spec.OUTER_PROTOCOLS)
        self.channel_keys = spec.SOVEREIGN_CHANNELS

    # 地址映射（确定性、纯算术，无随机）
    def addr(self, family: str, protocol: str, channel: str) -> Tuple[int, int]:
        fi = self.family_keys.index(family) if family in self.family_keys else 0
        ci = self.channel_keys.index(channel) if channel in self.channel_keys else 0
        pi = self.protocol_keys.index(protocol) if protocol in self.protocol_keys else 0
        row = (fi * spec.KALMAN_CHANNELS + ci) % self.size
        col = pi % self.size
        return (row, col)

    def activate(self, family: str, protocol: str, channel: str, weight: float = 1.0) -> Tuple[int, int]:
        r, c = self.addr(family, protocol, channel)
        self.cells[(r, c)] = round(self.cells.get((r, c), 0.0) + weight, 6)
        return (r, c)

    def sweep(self) -> int:
        """全族谱扫一遍：10 平台族 × 23 协议 × 17 通道。"""
        n = 0
        for fam in self.family_keys:
            for proto in self.protocol_keys:
                for ch in self.channel_keys:
                    self.activate(fam, proto, ch)
                    n += 1
        return n

    def occupied(self) -> int:
        return len(self.cells)

    def density(self) -> float:
        return self.occupied() / self.design

    def verify(self) -> dict:
        g = LogicGrid()
        combos = g.sweep()
        expect_combos = len(spec.PLATFORM_FAMILIES) * spec.PROTOCOL_TOTAL * spec.KALMAN_CHANNELS
        r1 = g.addr("short_stream", "HTTP", "query_forging")
        g2 = LogicGrid()
        r2 = g2.addr("short_stream", "HTTP", "query_forging")
        return {
            "size": g.size,
            "design": g.design,
            "combos": combos,
            "expected_combos": expect_combos,
            "occupied": g.occupied(),
            "density": round(g.density(), 6),
            "deterministic_addr": r1 == r2,
            "in_bounds": 0 <= r1[0] < g.size and 0 <= r1[1] < g.size,
            "sparse": g.occupied() < g.design,
            "ok": (
                g.design == 1771561
                and combos == expect_combos
                and r1 == r2
                and 0 <= r1[0] < 1331 and 0 <= r1[1] < 1331
                and g.occupied() <= combos
                and g.occupied() < g.design
            ),
        }


# ---------------------------------------------------------------- 卡尔曼 17 通道
class KalmanChannels:
    """17 通道一阶指数平滑（α=0.18），模拟"每通道一条卡尔曼口径"的观测更新。"""

    def __init__(self, alpha: float = spec.HEARTBEAT_ALPHA):
        self.alpha = alpha
        self.channels = list(spec.SOVEREIGN_CHANNELS)
        self.state: Dict[str, float] = {c: 0.5 for c in self.channels}
        self.updates = 0

    def update(self, channel: str, measurement: float) -> float:
        if channel not in self.state:
            raise KeyError(channel)
        old = self.state[channel]
        self.state[channel] = round((1 - self.alpha) * old + self.alpha * measurement, 6)
        self.updates += 1
        return self.state[channel]

    def sweep(self, measurement: float = 0.82) -> dict:
        for c in self.channels:
            self.update(c, measurement)
        return dict(self.state)

    def verify(self) -> dict:
        k = KalmanChannels()
        before = k.state["query_forging"]
        k.update("query_forging", 1.0)
        after = k.state["query_forging"]
        expect = round((1 - 0.18) * before + 0.18 * 1.0, 6)
        return {
            "channels": len(k.channels),
            "alpha": k.alpha,
            "before": before,
            "after": after,
            "formula_ok": abs(after - expect) < 1e-9,
            "lock_22627": spec.LOCK_1331 * len(k.channels),
            "ok": (
                len(k.channels) == 17
                and abs(k.alpha - 0.18) < 1e-9
                and after > before
                and abs(after - expect) < 1e-9
                and spec.LOCK_1331 * len(k.channels) == 22627
            ),
        }


# ---------------------------------------------------------------- 希尔伯特 6 层
class HilbertLayers:
    """6 层 × 108,641 节点 = 651,846；稀疏占用，不预分配。"""

    def __init__(self, layers: int = spec.HILBERT_LAYERS, per_layer: int = spec.LOCK_MANDALA):
        self.layers = layers
        self.per_layer = per_layer
        self.nodes: Dict[Tuple[int, int], float] = {}

    def put(self, layer: int, index: int, value: float = 1.0) -> None:
        if not 0 <= layer < self.layers:
            raise ValueError("层越界")
        if not 0 <= index < self.per_layer:
            raise ValueError("节点越界")
        self.nodes[(layer, index)] = round(value, 6)

    def sweep(self, stride: int = 1024) -> int:
        n = 0
        for layer in range(self.layers):
            for idx in range(0, self.per_layer, stride):
                self.put(layer, idx, 1.0)
                n += 1
        return n

    def verify(self) -> dict:
        h = HilbertLayers()
        n = h.sweep()
        return {
            "layers": h.layers,
            "per_layer": h.per_layer,
            "capacity": h.layers * h.per_layer,
            "placed": n,
            "lock_651846": spec.LOCK_MANDALA * spec.HILBERT_LAYERS,
            "ok": (
                h.layers == 6
                and h.layers * h.per_layer == 651846
                and h.layers * h.per_layer == 651846
                and n == 6 * (108641 // 1024 + 1)
            ),
        }


# ---------------------------------------------------------------- 曼陀罗 108641
class MandalaSpace:
    """9 域 + 合计 = 10 行的曼陀罗仿真空间（行数口径见 data/mandala_108641_allocation.csv）。"""

    def __init__(self, allocations: Dict[str, int] | None = None):
        self.allocations = dict(allocations) if allocations else dict(self.default_allocations())

    @staticmethod
    def default_allocations() -> Dict[str, int]:
        fam = spec.family_names()
        counts = (27185, 18007, 14593, 12011, 10139, 8647, 7211, 5971, 4877)
        keys = spec.family_keys()[:9]
        out = {fam[k]: c for k, c in zip(keys, counts)}
        return out

    def total(self) -> int:
        return sum(self.allocations.values())

    def verify(self) -> dict:
        m = MandalaSpace(MandalaSpace.default_allocations())
        return {
            "domains": len(m.allocations),
            "total": m.total(),
            "rows_with_total": len(m.allocations) + 1,
            "lock_108641": m.total() == 108641,
            "ok": len(m.allocations) == 9 and m.total() == 108641,
        }


def encode_all() -> dict:
    """一次性跑穿四层空间，返回可读快照（供 host/demo 使用）。"""
    hs = HyperSpace()
    lg = LogicGrid()
    lg.sweep()
    kc = KalmanChannels()
    kc.sweep()
    hl = HilbertLayers()
    hl.sweep()
    md = MandalaSpace(MandalaSpace.default_allocations())
    return {
        "hyper": hs.verify(),
        "grid": lg.verify(),
        "kalman": kc.verify(),
        "hilbert": hl.verify(),
        "mandala": md.verify(),
        "simulated": True,
    }
