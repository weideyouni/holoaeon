# 认知主权 Cognitive Sovereignty · 1331×1331 多智能体矩阵 V3.1

> 唯一 ID：`SG-MASTER-COGNITIVE-SOVEREIGNTY-1331x1331-SUPER-MAS-V3.1`
> 运行时：`SG-MASTER-COGNITIVE-SOVEREIGNTY-RUNTIME-HOLOGRAPHIC-V3.1`
> 协议：`SO-DATAPROTO v3.1` / `SO-BUS-V1.0` / `SO-THREADBUS-V1.0`（域 `sovereign`）
> 版本 `V3.1.0` · 日期 `2026-10-30` · 密令 **潮起开门，潮落闭嘴**

---

## 0. 一句话

把原设计里"6 个流媒体适配器 + 7 条提示词"的纸质方案，做成一套**可跑、可复现、可审计**的本地引擎：**张量向量化三层**表征 → **平台全域 10 族 130 入口**覆盖 → **内 12 × 外 11 = 132 协议映射**融通 → **R0-R4 五阶闭环** + **五机制** + **14 组自检**，且**维度口径与母体 V3 一个不改**。

V3.1 在这一层上**只加寻址深度、不动维度**：新增 `SD-Distill` 亚学科辅助蒸馏插件（16 域 → 127 亚学科），
以冷热插拔宿主 `so1331_runtime/plugins.py` 装载，`127 × 10 + 61 = 1331` 行、`127 × 855 + 56 = 108641` 节点，
两条等式写进 `spec.lock_verify()` 与 `selftest` G2/G14 双重断言。

**它不是**"绕过平台算法的工具"。它只做三件事：把认知身份编码成可计算的向量；把跨域查询锻造成可复现的文本清单；把"该由人做的事"写成清单交给本人手动执行。

---

## 1. 维度口径（与母体 V3 完全一致，一个不许动）

| 锁 | 值 | 含义 |
|---|---|---|
| 矩阵边长 | `1331` | 逻辑网格边长 |
| 设计格 | `1,771,561` | `1331²`（**稀疏字典，不预分配**） |
| 曼陀罗仿真节点 | `108,641` | 10 行分配合计 |
| 希尔伯特节点 | `651,846` | `108,641 × 6` |
| 卡尔曼节点 | `22,627` | `1331 × 17` |
| 心跳 | `70` 体 / `9700-9769` / `768` 维 / `α 0.18` | 全息心跳 |
| 细胞骨架 | `3` 层 × `4` 链（采/洗/检/注），跨链 `12` | 支撑层 |
| 皮肤 | `SG-SKIN-V6.0` 八层 | 边界闸门 |
| 语义 | `10` 模块 | 语义总线 |
| 赫布 | `lr 0.12 / decay 0.99 / clip 1.0`，`19` 圆（`42` 几何边）/ `17` 节点（`36` 节点边）/ `28` 流边 | 协作场 |
| 结构资产 | 分身 `168`、科目 `40`、协议 `23`、案例 `20`、执行体 `70`、维度 `147` | 台账 |

曼陀罗 10 行分配：`27185 / 18007 / 14593 / 12011 / 10139 / 8647 / 7211 / 5971 / 4877 / 合计 108641`。

> 说明：`42` 是**19 圆几何拓扑**的总邻接边数；17 个能力节点之间实际为 **36** 条节点边——两个数在 `hebbian_field.verify()` 里分别输出（`fol_edges_19` / `node_edges_17`），不做四舍五入式"对齐"。

---

## 2. 三层张量向量化（本包新增第一件事）

| 层 | 实现 | 关键性质 |
|---|---|---|
| ① 超向量 HRR | `tensor.HyperSpace`：768 维**双极 ±1**，`bind` 逐元素乘、`bundle` 多数表决（平票取 +1）、`permute` 循环移位、`cosine` | 种子 → `sha256` 派生，**同种子逐位一致**；`self_cosine = 1.0`；`cross_cosine ≈ -0.008`（近正交）；`recover_cosine ≈ 0.53`（bind 自逆可解绑） |
| ② 逻辑网格 1331×1331 | `tensor.LogicGrid`：地址 = `(族序×17 + 通道序) mod 1331` 行 × `(协议序) mod 1331` 列 | **稀疏字典**，只存被激活的格子；`combos = 10×23×17 = 3910`；`density ≈ 0.002207`；**绝不再申请 1,771,561 个对象** |
| ③ 三处空间 | `KalmanChannels`（17 通道 α 平滑）、`HilbertLayers`（6 层 × 108641 稀疏落点）、`MandalaSpace`（10 行分配） | 全部确定性 `sweep`，落点数与锁数一致（卡尔曼 `22627`、希尔伯特设计容量 `651846`、曼陀罗 `108641`） |

超向量之外还给了**带槽位**版本：`encode_ordered / recover_ordered`（`permute` 标注顺序，解绑用同一 shift 反置换），实测 `ordered_recover_cosine ≈ 0.49`。

---

## 3. 平台全域：10 族 × 13 职责 = 130 入口

| 族 | 名称 | 13 个入口（示例全列见 `--interop`） |
|---|---|---|
| `short_stream` | 短视频与直播 | 抖音 / 快手 / 视频号 / 小红书视频 / YouTube Shorts / TikTok / Reels / Bilibili 竖屏 / 微博视频 / 淘宝直播 / 斗鱼 / 虎牙 / Twitch |
| `long_video` | 长视频与影视 | YouTube / Bilibili / 腾讯视频 / 爱奇艺 / 优酷 / 芒果TV / Netflix / Prime Video / Disney+ / HBO Max / AcFun / 西瓜视频 / Vimeo |
| `feed_community` | 图文与社区 | 知乎 / 小红书 / 微博 / 豆瓣 / 贴吧 / 即刻 / Reddit / Medium / Substack / Quora / Mastodon / Threads / 少数派 |
| `search_qa` | 搜索与问答 | 百度 / Google / Bing / 必应学术 / 搜狗 / DuckDuckGo / Brave Search / Perplexity / 夸克 / 秘塔搜索 / You.com / Phind / Ecosia |
| `social_im` | 社交与即时通讯 | 微信 / 企业微信 / QQ / 飞书 / 钉钉 / Telegram / WhatsApp / Signal / Discord / Slack / Line / KakaoTalk / iMessage |
| `commerce_local` | 电商与本地生活 | 淘宝 / 天猫 / 京东 / 拼多多 / Amazon / Shopify / 美团 / 饿了么 / 大众点评 / 抖音商城 / eBay / Etsy / Booking |
| `knowledge_pro` | 知识与专业平台 | 知网 / 万方 / PubMed / arXiv / Semantic Scholar / Google Scholar / GitHub Docs / MDN / Notion / Obsidian 图谱 / Coursera / edX / 得到 |
| `llm_cn` | 大模型平台·国内 | 豆包 / Kimi / 通义千问 / 文心一言 / 智谱清言 / DeepSeek / 腾讯元宝 / 讯飞星火 / MiniMax 海螺 / 阶跃跃问 / 商汤日日新 / 百川 / Qwen Chat |
| `llm_intl` | 大模型平台·海外 | ChatGPT / Claude / Gemini / Copilot / Perplexity AI / Grok / Mistral Le Chat / Llama Chat / Poe / HuggingChat / PPLX Labs / YouChat / Together Chat |
| `dev_open` | 开源与开发者生态 | GitHub / GitLab / Hugging Face / PyPI / npm / Docker Hub / Stack Overflow / Hacker News / Gitee / Modelscope / Kaggle / Papers with Code / Product Hunt |

13 个**职责码**（每个入口一格）：搜索锻造 / 深链浏览 / 长文阅读 / 跨域跳转 / 身份声明 / 反标签复盘 / 协议取证 / 密度评估 / 兴趣拓扑重排 / 冷启动破圈 / 长尾覆盖 / 多端一致性 / 审计留痕。

**分身账**：`10 族 × 13 = 130` 组分身 + `26` 专项 + `12` 桥接 = **168**。
**执行体账**：`70` 个（`EX-9700…EX-9769`，与心跳号段一一对应）。

---

## 4. 协议融通：内 12 × 外 11 = 132 单元

**内部 12**：`Envelope 统一信封` / `Bus 消息总线` / `Skill 技能注册表` / `Memory 三层记忆` / `Scheduler 全息心跳` / `Guard·Skin 皮肤闸门` / `AdaptiveGraph 协作图` / `Cluster 并行 Actor` / `Hypervector 超向量` / `ModelAdapter 模型适配` / `ThreadBus 线程域锁` / `SO-DATAPROTO 数据协议`。

**外部 11 族**：`HTTP/REST` / `OpenAPI·Schema` / `GraphQL` / `gRPC·HTTP2` / `实时推送（WebSocket·SSE）` / `MCP 工具协议` / `Agent 互操作（A2A）` / `大模型 API（OpenAI·Anthropic·Gemini·国产兼容端点）` / `订阅分发（RSS·Atom·JSON Feed·WebSub）` / `身份授权（OAuth2·OIDC·SAML·DID·VC）` / `开放社交（ActivityPub·AT Protocol·Matrix·Nostr）`。

每个外部族都附**字段口径 + 有损点**声明；统一信封固定 7 字段；`ProtocolFusion.map_outer()` 对未知族直接 `KeyError`（用 `unknown_rejected` 断言守住）。**全部 `network=False`——只做映射表，不发一个包。**

---

## 5. 40 科 = 29 本源 + 11 融合

- **本源 29**：16 认知学科（数学 / 物理 / 逻辑 / 计算机 / AI / 生物 / 医学 / 中医 / 哲学 / 历史考古 / 文学 / 美学 / 符号学 / 社会学 / 未来科技 / 科幻）+ 13 条算法与平台机制学科（推荐系统 / 协同过滤 / 排序学习 / 用户画像建模 / 隐私计算 / 交互设计 / 内容审核 / 网络协议工程 / 语义网与知识图谱 / 计算传播学 / 平台经济学 / 算法透明度与合规 / 计量学习科学）。
- **融合 11**：认知工程×推荐对抗、符号学×注意力机制、本体论×知识图谱、张量代数×语义表征、协议工程×平台互操作、合规治理×算法透明、人机交互×自我呈现、传播学×算法策展、学习科学×跨域迁移、中医整体观×系统论（**隐喻**）、伦理学×认知自由。

---

## 6. 17 通道（`SO-01…SO-17`，五组 4-4-4-3-2）

信号组：张量向量化编码 / 跨域绑定与叠加 / 身份指纹与自述 / 本体图谱寻址
锻造组：查询锻造 / 模板引擎 / 语义密度评分 / 不可预测性调度
策略组：标签画像反推 / 反刻板策略 / 反馈闭环校准
协议组：内部协议融通 / 外部协议融通 / 平台适配注册
治理组：合规边界闸门 / 审计与可复现 / 人类终裁回执

---

## 7. R0-R4 五阶闭环 + 六大实战域

| 阶 | 名称 | 做什么 | 产物 |
|---|---|---|---|
| R0 | 编码 | 平台×协议×通道 → 网格地址 + 768 维超向量 | 占用格数、密度、超向量解绑余弦 |
| R1 | 锻造 | 跨域组合 → 高维查询文本 | 3 条查询 + 身份自述 + 21 条/3 天计划（时刻唯一） |
| R2 | 策略 | 反标签自测清单 + 五模式清单 | 7 条策略（全 `human_manual`）、`auto=False` |
| R3 | 互操作 | 23 协议族 → 信封映射 | `132` 单元、`network=False` |
| R4 | 合规 | 八层闸门 + 审计 + 占位 | 审计指纹 16 位、`pending_human_measure` |

六大实战域：`encoding / forge / strategy / interop / compliance / governance`。

---

## 8. 快速开始（纯标准库，Python 3.10+）

```powershell
cd runtime_v3
python selftest.py            # 14 组自检 → 期望 14/14 PASS
python main.py --version      # 身份 / 锁数 / 密令
python main.py --forge        # 今日跨域查询 + 身份自述 + 计划表
python main.py --anti         # 反标签计划（全 human_manual）
python main.py --interop      # 10 族 130 入口 + 23 协议 132 单元
python main.py --run          # R0-R4 五阶闭环
python main.py --plugs        # 插件冷装清单（SD-Distill）
python main.py --plug-hot subdistill   # 运行期热装（不重启）
python main.py --plug-off subdistill   # 卸载回滚
python main.py --subdistill   # S1-S7 蒸馏全流程 + SKC + 七项损失 + 四段课程
python cs_demo.py             # 端到端演练
python tools\redline_scan.py  # 红线扫描 → 期望 0 命中
python tools\score_runtime.py # 六维自评 → tools\round_scores.json
python tools\package.py       # SHA256SUMS.txt + 版本化发行 zip
python tools\harvest_pipeline.py  # 11 步收割 + 三重持久化
```

**无第三方依赖**：只用 `hashlib / json / csv / os / sys / ast / zipfile / shutil / itertools`。

---

## 9. 项目结构

```
runtime_v3/
├── README.md                     # 本文件
├── SKILL.md                      # 可入库技能条（frontmatter + 触发词 + 红线 + 科学边界）
├── MAPPING.md                    # 23 协议 / 10 族 / 17 通道 / 11 维收割 逐条视图
├── 导学使用手册.md                # 30 分钟上手 + 每周节奏
├── 交付报告.md                    # 交付清单 + 验证记录 + 缺口
├── 三轮工程自评报告.md
├── 技能入库入口.md
├── SHA256SUMS.txt
├── main.py                       # CLI（16 个入口）
├── cs_demo.py                    # 端到端演练
├── selftest.py                   # G1-G14
├── so1331_runtime/               # 14 个模块
│   ├── spec.py                   # ID / 锁数 / 五机制 / SD-Distill 锁数 / 刚性断言
│   ├── tensor.py                 # 三层张量向量化
│   ├── heartbeat_engine.py       # 全息心跳 70 体
│   ├── threadbus.py              # 线程域锁 sovereign
│   ├── skin.py                   # 皮肤八层 + E13/E14 闸门 + 细胞骨架
│   ├── semantic_bus.py           # 语义十模块
│   ├── hebbian_field.py          # 赫布协作场（生命之花）
│   ├── forge.py                  # 本体 + 查询锻造 + 7 条核心提示词
│   ├── strategy.py               # 反标签 + 离线注入器
│   ├── interop.py                # 132 协议映射 + 168 分身 / 70 执行体
│   ├── knowledge.py              # 四表读取与校验
│   ├── plugins.py                # 冷热插拔宿主（manifest 校验 / 能力供给 / 审计指纹）
│   ├── host.py                   # R0-R4 宿主
│   └── __init__.py
├── plugs/
│   └── subdistill_v3_1/           # SD-Distill 插件（manifest + plugin + payload）
│       ├── manifest.json         # id/version/entry/cells/policy/gated_domains
│       ├── plugin.py             # 127 亚学科 / 七阶段 / 七损失 / 四段课程 / 12 能力
│       └── payload/
│           ├── taxonomy_127.json     # 127 项亚学科编码 + 术语种子
│           └── resonance_seed_50.json # 50 组跨域共振种子（各带反例）
├── data/
│   ├── executor_1331_registry.csv        # 71 行（70 执行体）
│   ├── knowledge_dimensions_1331.csv     # 148 行（147 维度 = 130 + 17）
│   ├── mandala_108641_allocation.csv     # 11 行（9 域 + 合计 108641）
│   └── cases_20.csv                      # 21 行（10 + 4 + 6）
└── tools/
    ├── gen_data.py / package.py / redline_scan.py
    ├── score_runtime.py / harvest_pipeline.py
    └── round_scores.json / skill_registry.json / harvest_receipt.json
```

代码规模：**23 个 py 文件 / 4005 行**（`so1331_runtime` 14 个 / 2373 行；`tools` 5 个 / 583 行；入口 3 个 + 插件 1 个 / 1049 行；`gen_data` 幂等，可重复生成四表）。

---

## 10. 与 HoloAeon / 类生命经络的关系

```
HoloAeon 通用多智能体认知框架（Apache-2.0, v0.4.0）
├── holoaeon-core                # 内核 / 调度 / 技能注册
├── holoaeon/packs/gaoyi_pack.py       # 「高译」第九包
├── holoaeon/packs/sovereignty_pack.py # 第十包：本包 17 通道桥接（只注册不建 agent）
└── holoaeon/packs/subdistill_pack.py  # ◀ 第十一包：SD-Distill 亚学科蒸馏（15 技能 / 0 agent / S1-S7）
类生命经络 1331×1331 多智能体矩阵 V3（2026-10-24）
└── 提供：ID 命名法 / 锁数四件 / 五机制参数 / 六实战域 / 四表口径 / SKILL.md 写法
```

**桥接方式**：`sovereignty_pack` 把本包 17 通道注册成 17 技能、R0-R4 注册成 5 条工作流；
`subdistill_pack` 把 SD-Distill 的分类/教师/七阶段/七损失/课程/反标签/SKC 校验注册成 15 技能、
S1-S7 注册成 7 条工作流。两者**均不新增 agent**（HoloAeon 侧 `g15_packs` 对 `n_agents == 25`
是硬断言，新增 agent 会破坏它——所以只注册技能与工作流，由 `EXTRA_PACK_REGISTRY` 承载，
G18 / G19 单独验证）。

---

## 11. 合规边界（写进代码，不是口号）

- 不联网、不开端口、不认证、不常驻、无 cron
- 不读写任何平台账号；不调外部大模型；不配 Key；不读 `.env`
- 不自动登录 / 不自动搜索 / 不抓取 / 不批量发帖 / 不刷量养号 / 不规避风控 / 不伪造身份
- 五模式只产出**计划表**，执行列恒为 `human_manual`
- 平台指标 `pending_human_measure`（零伪造）
- 不冒充平台官方；平台规则以各平台用户协议为准，本包不做合规背书

## 12. 科学边界

`HyperSpace` 的 `recover_cosine ≈ 0.53` 只说明 **HRR 解绑在 768 维、两元素 bundle 的受控条件下有效**，不说明任何平台会被改变；标签推断是基于用户自填观测的**启发式**，不是平台真实标签体系；全息/经络/曼陀罗是**结构隐喻**与工程分区，不作科学结论。**仿真 ≠ 证明，碳基终裁。**

## 13. License

MIT（与母体 V3 口径一致）。HoloAeon 桥接层沿用上游 Apache-2.0。

---

潮起开门，潮落闭嘴。
