# MAPPING · 认知主权 1331×1331 矩阵 V3.0 逐条映射视图

> 本文件是"账本"：每一条锁数、每一个协议、每一个平台入口、每一维收割，都写明**它在代码里的位置**与**怎么验**。
> 校验入口：`python main.py --interop` / `--knowledge` / `--tensor`；自检：`python selftest.py`。

---

## A. 锁数核对表（12 项，`spec.lock_check()` / `lock_verify()`）

| # | 锁 | 值 | 代码位置 | 验证方式 |
|---|---|---|---|---|
| 1 | 矩阵边长 | 1331 | `spec.MATRIX_SIDE` | G2 |
| 2 | 设计格 | 1,771,561 | `spec.LOCK_DESIGN` | G2、G12（`LogicGrid.design`） |
| 3 | 曼陀罗节点 | 108,641 | `spec.LOCK_MANDALA` | G2、G10（CSV 合计行） |
| 4 | 希尔伯特节点 | 651,846 | `spec.LOCK_HILBERT` | G2、G12（`layers×per_layer`） |
| 5 | 卡尔曼节点 | 22,627 | `spec.LOCK_KALMAN` | G2、G12 |
| 6 | 心跳体数/号段 | 70 / 9700-9769 | `spec.HEARTBEAT_COUNT/BASE` | G3、G5 |
| 7 | 心跳维度/α | 768 / 0.18 | `spec.HEARTBEAT_DIM/ALPHA` | G3、G5 |
| 8 | 细胞骨架 | 3 层 × 4 链，跨 12 | `spec.CYTOSKELETON_*` | G6 |
| 9 | 皮肤 | SG-SKIN-V6.0 / 8 层 | `spec.SKIN_VERSION/LAYERS` | G7、G8 |
| 10 | 语义模块 | 10 | `spec.SEMANTIC_MODULES` | G9 |
| 11 | 赫布 | lr0.12 / decay0.99 / clip1.0 / 19 圆 / 17 节点 / 42 几何 / 36 节点边 / 28 流边 | `spec.HEBBIAN_*` + `hebbian_field.py` | G13 |
| 12 | 结构资产 | 168 / 40 / 23 / 20 / 70 / 147 | `spec.AVATAR_TOTAL…DIMENSION_TOTAL` | G10、G11 |

`lock_verify()` 里是**30+ 条与运算**，任一条不成立即 `False`；`selftest` G2 直接断言它。

---

## B. 23 协议逐条（内 12 + 外 11 = 132 映射单元）

### B1. 内部 12（每条 ≥3 个操作成员，`ProtocolFusion.verify()` 断言 `members_inner == 44`）

| 键 | 名称 | 操作成员 | 在包内的落点 |
|---|---|---|---|
| `ENV` | Envelope 统一信封 | create / broadcast / reply / forward / trace | `interop.make_envelope`（7 字段） |
| `BUS` | Bus 消息总线 | publish/subscribe / direct-address / route | `semantic_bus.route` |
| `SKL` | Skill 技能注册表 | register / match / manifest | `so1331_runtime/__init__.py` 统一出口 |
| `MEM` | Memory 三层记忆 | working / longterm / archive / consolidate | 本地 JSON / CSV 台账（无外部存储） |
| `HBT` | Scheduler 全息心跳 | tick / snapshot / health / reelect | `heartbeat_engine` |
| `SKN` | Guard·Skin 皮肤闸门 | L1-L8 / verdict / audit-log | `skin.SkinGate` |
| `GRP` | AdaptiveGraph 协作图 | dijkstra / bottleneck / cycle / root-cause | `hebbian_field` 权重图 |
| `CLS` | Cluster 并行 Actor | barrier / mailbox / forward | `host` 五阶串行 + 执行体台账 |
| `HVEC` | Hypervector 超向量 | make / bind / unbind / bundle / cosine | `tensor` |
| `MADP` | ModelAdapter 模型适配 | route-policy / format-mask / usage-metrics | 仅声明，不接任何模型 |
| `TBUS` | ThreadBus 线程域锁 | domain-lock / heartbeat-handshake / seal | `threadbus`（越域 `ValueError`） |
| `SODP` | SO-DATAPROTO 数据协议 | lock / csv / sha256 / simulated-flag | `spec` + `knowledge` + `tools/package.py` |

### B2. 外部 11 族（成员 + 有损点声明）

| 键 | 族 | 成员 | 映射时**必然损失**的东西 |
|---|---|---|---|
| `HTTP` | HTTP/REST | HTTP/1.1·HTTP/2·HTTP/3·REST·JSON | 头部/状态码语义 → 只留 7 字段信封；`simulated` 无对应字段 |
| `OPENAPI` | OpenAPI/Schema | OpenAPI 3.x / JSON Schema / Swagger 2.0 | 类型系统可映射，但"必填/枚举约束"无对应槽位 |
| `GRAPHQL` | GraphQL | query / mutation / subscription / introspection | `mutation` 在离线语义下退化为"计划动作"，不执行 |
| `GRPC` | gRPC/HTTP2 | gRPC / protobuf / streaming | streaming 的分片顺序不可表达；只留端点+载荷摘要 |
| `REALTIME` | 实时推送 | WebSocket / SSE / MQTT / WebRTC-signaling | 时序与背压全部丢失，只留"事件名+快照" |
| `MCP` | MCP 工具协议 | tools/list / tools/call / resources / prompts | tool 的副作用无法在信封里表达，一律 `human_manual` |
| `A2A` | Agent 互操作 | A2A / ACP / agent-card / task-handoff | 任务所有权与回执链只能压成 `origin/route` 两字段 |
| `LLMAPI` | 大模型 API | OpenAI-compatible `/v1/chat` / Anthropic Messages / Gemini generateContent / 国产兼容端点 | `temperature/top_p` 等采样参数无槽位；**本包不调用任何模型** |
| `FEED` | 订阅分发 | RSS 2.0 / Atom / JSON Feed / WebSub | pubDate/GUID 只能留"时间戳+指纹" |
| `IDENTITY` | 身份授权 | OAuth 2.0 / OIDC / SAML / DID / W3C VC | 凭证与 scope 一律不落地（红线：不读凭证） |
| `FEDIVERSE` | 开放社交 | ActivityPub / AT Protocol / Matrix / Nostr | actor 图与签名/联邦投递链不可表达 |

**互映射矩阵**：`12 × 11 = 132` 个单元，每单元 = 1 条内部协议 × 1 个外部族；`matrix()` 返回 `cells=132`，并强制 `network=False`。
未知外部族：`map_outer("SOAP", env)` → `KeyError`（`verify()["unknown_rejected"]` 断言）。

---

## C. 平台族 × 职责矩阵（10 × 13 = 130）

每族 13 个入口，**每个入口**挂 13 个职责码中的一个（`spec.AVATAR_DUTIES`）：
搜索锻造 → 深链浏览 → 长文阅读 → 跨域跳转 → 身份声明 → 反标签复盘 → 协议取证 → 密度评估 → 兴趣拓扑重排 → 冷启动破圈 → 长尾覆盖 → 多端一致性 → 审计留痕。

| 族 | 入口数 | 主要职责落点（哪几格最有用） |
|---|---|---|
| `short_stream` 短视频与直播 | 13 | 搜索锻造 / 冷启动破圈 / 长尾覆盖（长视频入口反而更适合深链浏览） |
| `long_video` 长视频与影视 | 13 | 长文阅读（长片说明与字幕）/ 跨域跳转 / 密度评估 |
| `feed_community` 图文与社区 | 13 | 长文阅读 / 身份声明 / 反标签复盘 |
| `search_qa` 搜索与问答 | 13 | 搜索锻造 / 协议取证 / 密度评估 |
| `social_im` 社交与即时通讯 | 13 | 多端一致性 / 身份声明（**只在可发布文本处**，不自称官方） |
| `commerce_local` 电商与本地生活 | 13 | 兴趣拓扑重排 / 反标签复盘（避免"消费=人格"式画像） |
| `knowledge_pro` 知识与专业平台 | 13 | 长文阅读 / 跨域跳转 / 审计留痕 |
| `llm_cn` 大模型平台·国内 | 13 | 搜索锻造 / 身份声明 / 反标签复盘（提示词直接表达学习结构） |
| `llm_intl` 大模型平台·海外 | 13 | 同上，另加跨域跳转（用英文交叉查询） |
| `dev_open` 开源与开发者生态 | 13 | 协议取证 / 审计留痕 / 长尾覆盖 |

**分身账**：`130`（组）+ `26`（专项：反标签/语义密度/不可预测调度/…/人类终裁）+ `12`（桥接：短视频↔长视频、国内↔海外、协议↔平台…）= **168**。
**执行体账**：`70`（`EX-9700…EX-9769`，心跳号段对齐；`permission` 恒为 `human_manual_only`）。

---

## D. 17 通道 → 1331 寻址

```
行 = (family_index × 17 + channel_index) mod 1331     # family_index 0..9, channel_index 0..16
列 = protocol_index mod 1331                          # 23 个内部/外部协议序
```

- 组合总数：`10 × 17 × 23 = 3910`（同一通道与协议多入口时仍只记一格）
- 实测占用：`3910` 格，密度 `0.002207`（`3910 / 1771561`）
- **稀疏性**：`LogicGrid` 只维护 `{(row, col): 激活计数}`，`occupied()` 返回 `3910`；**从不实例化 1,771,561 个对象**（G12 的 `sparse` 断言守这一条）

| 组 | 通道（`SO-01…SO-17`） |
|---|---|
| signal 4 | 张量向量化编码 / 跨域绑定与叠加 / 身份指纹与自述 / 本体图谱寻址 |
| forge 4 | 查询锻造 / 模板引擎 / 语义密度评分 / 不可预测性调度 |
| anti 3 | 标签画像反推 / 反刻板策略 / 反馈闭环校准 |
| protocol 3 | 内部协议融通 / 外部协议融通 / 平台适配注册 |
| governance 3 | 合规边界闸门 / 审计与可复现 / 人类终裁回执 |

---

## E. 四表台账（`knowledge.verify()`）

| 表 | 行数（含表头） | 主键 | 断言 |
|---|---|---|---|
| `executor_1331_registry.csv` | 71 | `executor_id` | 70 执行体；心跳号 `HB-9700…HB-9769` 全覆盖 |
| `knowledge_dimensions_1331.csv` | 148 | `dim_code` | 147 维；`AV-001…AV-130` + `SO-01…SO-17`；**权重和 = 1.0（±0.001）** |
| `mandala_108641_allocation.csv` | 11 | `row_no` | 9 域行 + 合计行 = 108641 |
| `cases_20.csv` | 21 | `case_id` | 10 正常 + 4 反标签 + 6 协议/平台 |

权重口径：`AV` 130 × `0.715/130 = 0.0055`；`SO` 17 × `0.285/17 ≈ 0.0168`；合计 `0.715 + 0.285 = 1.0`。

---

## F. 11 维收割视图（`tools/harvest_pipeline.py`）

| 维 | 收割对象 | 落点 | 校验 |
|---|---|---|---|
| 1 身份 | 矩阵ID / 运行时ID / 协议 / 域 / 双密令 | `spec.py` → `SKILL.md` 头部 | G1 |
| 2 锁数 | 12 项锁 | `spec.lock_check()` | G2 |
| 3 机制 | 心跳 / 骨架 / 皮肤 / 语义 / 赫布 | `S1 盘点` 输出 5 组 | G3-G9、G13 |
| 4 张量 | 超向量 / 网格 / 卡尔曼 / 希尔伯特 / 曼陀罗 | `tensor.py` | G12 |
| 5 锻造 | 16 学科 / 7 提示词 / 21 条计划 | `forge.py` | G12 |
| 6 策略 | 7 策略 / 5 模式 / 13 拒绝词 | `strategy.py` | G12 |
| 7 协议 | 内 12 / 外 11 / 132 单元 | `interop.py` + 本文件 B 节 | G11、G12 |
| 8 平台 | 10 族 / 130 入口 / 168 分身 / 70 执行体 | `interop.py` + 本文件 C 节 | G11 |
| 9 合规 | 八层闸门 / E13 10 词 / E14 20 词 / 审计指纹 | `skin.py`、`host.stage_r4` | G7、G8、G13 |
| 10 案例 | 20 案例（10+4+6） | `data/cases_20.csv` | G10 |
| 11 持久化 | 本地工程 / 发行包 / 技能旁挂 / 注册表 / 回执 | `tools/` 三个 json + `.user_skills` | `harvest_receipt.json` |

---

## G. 一句话对照（原始设计 → 本包）

| 原设计 | 本包 |
|---|---|
| 6 个流媒体适配器 | **10 族 130 入口**（含国内外大模型平台） |
| 7 条提示词（散在 README） | `CORE_PROMPTS` 7 条**原文** + 可复现锻造器（同种子逐字一致） |
| 16 学科本体 | **40 科**（29 本源 + 11 融合），`OntologyGraph` 断言 `16 认知学科 / 29 节点 / 16 边` |
| 5 种注入模式 | 5 模式**只出清单**，`auto=False`、`execution=human_manual` |
| 反标签"伪代码" | `AntiLabelEngine`：3 标签推断 / 7 策略 / 升-维持-拒绝三类校准 / 空观测 `pending` |
| 理念层"训练数据提供者" | **张量层落地**：768 维超向量 + 1331 网格寻址 + 五阶闭环可审计 |
| 未提协议 | **23 协议**（内 12 外 11）+ 132 映射 + 逐族有损点 |
| 未提合规 | 八层闸门 + E13/E14 词表 + 零伪造平台数据 + 碳基终裁 |

---

潮起开门，潮落闭嘴。
