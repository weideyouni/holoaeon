# -*- coding: utf-8 -*-
"""
技能收割流水线（11 步 + 三重持久化）
==============================================================
S1 盘点 → S2 抽取 → S3 去重 → S4 分类 → S5 生成校验 → S6 校验（自检/红线/哈希）
S7 持久化①本地工程 → S8 持久化②发行包(zip+SHA256SUMS) → S9 持久化③技能旁挂(.user_skills)
S10 注册表 skill_registry.json → S11 回执 harvest_receipt.json
用法：python tools\\harvest_pipeline.py [--target <skills_root>]
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PROJ = os.path.dirname(ROOT)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)

from so1331_runtime import spec, Knowledge  # noqa: E402
import selftest as st  # noqa: E402
import redline_scan as rl  # noqa: E402

SKILL_NAME = "cognitive-sovereignty-1331"
DEFAULT_TARGET = (r"C:\Users\Administrator\AppData\Local\DoubaoWork\User Data\Default"
                  r"\.doubaowork\agent_mode\workspace\.user_skills")
ZIP_NAME = f"cs1331_cognitive_sovereignty_matrix_{spec.VERSION}_{spec.DATE.replace('-', '')}.zip"

STEPS = [
    "S1 盘点工程文件", "S2 抽取标识与锁数", "S3 去重（模块清单唯一化）",
    "S4 分类（五机制/张量/互操作/平台）", "S5 生成并校验 SKILL.md 段落",
    "S6 校验（14 组自检+红线+哈希）", "S7 持久化①本地工程",
    "S8 持久化②发行包", "S9 持久化③技能旁挂", "S10 注册表", "S11 回执",
]


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def iter_files(base: str):
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [d for d in dirnames if d != "__pycache__"]
        for fn in sorted(filenames):
            if fn.endswith(".pyc"):
                continue
            yield os.path.join(dirpath, fn)


def s1_inventory() -> dict:
    files = list(iter_files(ROOT))
    py = [f for f in files if f.endswith(".py")]
    lines = sum(sum(1 for _ in open(f, encoding="utf-8")) for f in py)
    return {"files": len(files), "py": len(py), "py_lines": lines}


def s2_extract() -> dict:
    kv = Knowledge().verify()
    return {"matrix_id": spec.MATRIX_ID, "runtime_id": spec.RUNTIME_ID,
            "locks": spec.lock_check(), "executors": kv["executors"],
            "dimensions": kv["dimensions"], "cases": kv["cases"]}


def s3_dedup() -> dict:
    mods = sorted(m for m in os.listdir(os.path.join(ROOT, "so1331_runtime"))
                  if m.endswith(".py"))
    dup = len(mods) - len(set(mods))
    return {"modules": mods, "duplicates": dup}


def s4_classify() -> dict:
    buckets = {"机制": ["heartbeat_engine.py", "skin.py", "semantic_bus.py",
                       "hebbian_field.py", "threadbus.py"],
               "张量": ["tensor.py"],
               "互操作": ["interop.py"],
               "盘点": ["knowledge.py"],
               "编排": ["host.py", "forge.py", "strategy.py", "spec.py"]}
    exist = os.listdir(os.path.join(ROOT, "so1331_runtime"))
    return {k: [f for f in v if f in exist] for k, v in buckets.items()}


def s5_skilldoc() -> dict:
    p = os.path.join(ROOT, "SKILL.md")
    if not os.path.exists(p):
        return {"ok": False, "reason": "SKILL.md 缺失"}
    src = open(p, encoding="utf-8").read()
    need = ["name:", "description:", "何时使用", "核心锁数", "红线", "科学边界",
            spec.SECRET_OPEN, spec.SECRET_CLOSE]
    return {"ok": all(n in src for n in need),
            "bytes": len(src.encode("utf-8")), "missing": [n for n in need if n not in src]}


def s6_verify() -> dict:
    groups = st.run()
    files = rl.target_files()
    hits = sum(len(rl.scan_file(f)["hits"]) for f in files)
    return {"selftest_pass": sum(1 for v in groups.values() if v),
            "selftest_total": len(groups), "redline_hits": hits,
            "redline_files": len(files),
            "ok": sum(1 for v in groups.values() if v) == len(groups) and hits == 0}


def s8_package() -> dict:
    import package
    package.main()
    zp = os.path.join(PROJ, ZIP_NAME)
    return {"zip": zp, "size": os.path.getsize(zp) if os.path.exists(zp) else 0,
            "sha256": sha256(zp) if os.path.exists(zp) else ""}


def s9_attach(target_root: str) -> dict:
    """镜像到技能根。用"覆盖合并 + 清理多余"而不是整目录删除：
    Windows 下技能目录可能被应用/编辑器占用（WinError 32），删不掉但可以写入。"""
    dst = os.path.join(target_root, SKILL_NAME)
    os.makedirs(dst, exist_ok=True)
    shutil.copytree(ROOT, dst, dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    src_rel = {os.path.relpath(p, ROOT).replace("\\", "/") for p in iter_files(ROOT)}
    pruned, skipped = 0, 0
    for p in list(iter_files(dst)):
        rel = os.path.relpath(p, dst).replace("\\", "/")
        if rel not in src_rel:
            try:
                os.remove(p)
                pruned += 1
            except OSError:
                skipped += 1
    files = list(iter_files(dst))
    return {"skill_dir": dst, "files": len(files),
            "bytes": sum(os.path.getsize(f) for f in files),
            "mode": "merge+prune", "pruned": pruned, "skipped_locked": skipped,
            "skill_md_sha256": sha256(os.path.join(dst, "SKILL.md"))}


def main(argv) -> int:
    target = DEFAULT_TARGET
    if "--target" in argv:
        target = argv[argv.index("--target") + 1]
    print("=" * 72)
    print(f"技能收割流水线 · {SKILL_NAME} · {spec.VERSION}")
    print("=" * 72)
    rec = {}
    rec["S1"] = s1_inventory()
    print(f"[S1] 文件 {rec['S1']['files']} / py {rec['S1']['py']} / 行 {rec['S1']['py_lines']}")
    rec["S2"] = s2_extract()
    print(f"[S2] 锁数 {json.dumps(rec['S2']['locks'], ensure_ascii=False)}")
    rec["S3"] = s3_dedup()
    print(f"[S3] 模块 {len(rec['S3']['modules'])} 个，重复 {rec['S3']['duplicates']}")
    rec["S4"] = s4_classify()
    print(f"[S4] 分类 " + ", ".join(f"{k}:{len(v)}" for k, v in rec["S4"].items()))
    rec["S5"] = s5_skilldoc()
    print(f"[S5] SKILL.md 段落齐备={rec['S5']['ok']} bytes={rec['S5'].get('bytes')} "
          f"{rec['S5'].get('missing', '')}")
    rec["S6"] = s6_verify()
    print(f"[S6] 自检 {rec['S6']['selftest_pass']}/{rec['S6']['selftest_total']} | "
          f"红线命中 {rec['S6']['redline_hits']} | ok={rec['S6']['ok']}")
    if not rec["S6"]["ok"] or not rec["S5"].get("ok"):
        print("！校验未通过，停止持久化。")
        return 1
    rec["S7"] = {"root": ROOT, "ok": os.path.isdir(ROOT)}
    print(f"[S7] 持久化① 本地工程 {ROOT}")
    rec["S8"] = s8_package()
    print(f"[S8] 持久化② 发行包 {rec['S8']['size']} B sha256={rec['S8']['sha256'][:16]}…")
    rec["S9"] = s9_attach(target)
    print(f"[S9] 持久化③ 技能旁挂 {rec['S9']['skill_dir']}（{rec['S9']['files']} 文件，"
          f"{rec['S9']['bytes']} B，模式 {rec['S9']['mode']}，清理 {rec['S9']['pruned']}，"
          f"占用跳过 {rec['S9']['skipped_locked']}）")
    registry = {
        "skill_name": SKILL_NAME,
        "matrix_id": spec.MATRIX_ID,
        "version": spec.VERSION,
        "date": spec.DATE,
        "domain": spec.DOMAIN,
        "locks": spec.lock_check(),
        "entry": "so1331_runtime",
        "selftest": f"{rec['S6']['selftest_pass']}/{rec['S6']['selftest_total']}",
        "redline_hits": rec["S6"]["redline_hits"],
        "skill_dir": rec["S9"]["skill_dir"].replace("\\", "/"),
        "skill_md_sha256": rec["S9"]["skill_md_sha256"],
        "zip": rec["S8"]["zip"].replace("\\", "/"),
        "zip_sha256": rec["S8"]["sha256"],
        "zip_size": rec["S8"]["size"],
    }
    reg_path = os.path.join(HERE, "skill_registry.json")
    with open(reg_path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(registry, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(f"[S10] 注册表 {reg_path}")
    rec["receipt"] = registry
    rec_path = os.path.join(HERE, "harvest_receipt.json")
    with open(rec_path, "w", encoding="utf-8", newline="\n") as f:
        json.dump({"steps": STEPS, "detail": rec, "receipt": registry}, f,
                  ensure_ascii=False, indent=2)
        f.write("\n")
    print(f"[S11] 回执 {rec_path}")
    print("-" * 72)
    print("三重持久化完成：本地工程 / 发行包 / 技能旁挂；注册表与回执已落盘。")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
