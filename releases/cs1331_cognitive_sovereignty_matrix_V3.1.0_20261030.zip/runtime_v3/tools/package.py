# -*- coding: utf-8 -*-
"""
打包：SHA256SUMS + zip（纯标准库）
==============================================================
1) 对 runtime_v3 下全部文件（跳过 __pycache__）计算 sha256，写 SHA256SUMS.txt
2) 打 zip 到工程根目录：cs1331_cognitive_sovereignty_matrix_<版本>_<日期>.zip
3) 打印 zip 大小与哈希（可用于回读校验）

版本化原则：zip 名随 spec.VERSION 变化，旧版本 zip 只增不覆盖。
"""
from __future__ import annotations

import hashlib
import os
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                    # runtime_v3
PROJ = os.path.dirname(ROOT)                    # 工程目录
sys.path.insert(0, ROOT)

from so1331_runtime import spec  # noqa: E402

ZIP_NAME = (f"cs1331_cognitive_sovereignty_matrix_"
            f"{spec.VERSION}_{spec.DATE.replace('-', '')}.zip")

# 自引用排除：这两个文件记录"本 zip 的大小与哈希"，必须在打包之后写。
# 若把它们打进去，包的哈希会永远落后一代，回读校验必然对不上。
EXCLUDE_REL = {"SHA256SUMS.txt", "tools/skill_registry.json", "tools/harvest_receipt.json"}


def iter_files(base: str):
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [d for d in dirnames if d != "__pycache__"]
        for fn in sorted(filenames):
            if fn.endswith(".pyc"):
                continue
            yield os.path.join(dirpath, fn)


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def main() -> int:
    files = list(iter_files(ROOT))
    sums_path = os.path.join(ROOT, "SHA256SUMS.txt")
    lines = []
    for p in files:
        rel = os.path.relpath(p, ROOT).replace("\\", "/")
        if rel in EXCLUDE_REL:
            continue
        lines.append(f"{sha256(p)}  {rel}")
    with open(sums_path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    print(f"SHA256SUMS.txt 已写入：{len(lines)} 个文件")

    zip_path = os.path.join(PROJ, ZIP_NAME)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in files:
            rel = os.path.relpath(p, ROOT).replace("\\", "/")
            if rel in EXCLUDE_REL:
                continue
            z.write(p, arcname=f"runtime_v3/{rel}")
        z.write(sums_path, arcname="runtime_v3/SHA256SUMS.txt")
    size = os.path.getsize(zip_path)
    print(f"zip：{zip_path}")
    print(f"大小：{size} B")
    print(f"SHA256：{sha256(zip_path)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
