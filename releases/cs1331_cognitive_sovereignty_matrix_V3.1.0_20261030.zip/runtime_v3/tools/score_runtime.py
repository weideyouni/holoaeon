# -*- coding: utf-8 -*-
"""
工程自评（本地可复算，不是外部评审）
==============================================================
六个维度全部由实测指标推导，不写死分数：
  D1 锁数保真   : spec.lock_verify() + 四个锁数逐项核对
  D2 自检强度   : selftest 13 组通过数 / 13
  D3 红线合规   : redline_scan 命中数（0 才满分）
  D4 文档完备   : 约定文档清单存在率
  D5 可复现     : 同种子两次跑 audit 与查询文本逐字一致
  D6 覆盖度     : 20 案例 / ≥13 模块 / 四表行数
三个层次分（结构/语义/合规）各按本层维度加权平均，**不做逐轮加码的伪造曲线**；
平台侧"实测效果"单独列为未验证项（本包红线禁止联网，故不评、不给分）。
"""
from __future__ import annotations

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)

from so1331_runtime import spec, Knowledge, SovereignHost, QueryForge  # noqa: E402
import selftest as st  # noqa: E402
import redline_scan as rl  # noqa: E402

DOCS = ["README.md", "SKILL.md", "MAPPING.md", "导学使用手册.md", "交付报告.md",
        "三轮工程自评报告.md", "技能入库入口.md"]


def dim_lock() -> dict:
    lc = spec.lock_check()
    want = {"1331": 1331, "design_1331x1331": 1771561, "mandala": 108641,
            "hilbert": 651846, "kalman": 22627}
    ok = spec.lock_verify() and all(lc.get(k) == v for k, v in want.items())
    return {"score": 100.0 if ok else 0.0, "detail": lc, "ok": bool(ok)}


def dim_selftest() -> dict:
    groups = st.run()
    n = sum(1 for v in groups.values() if v)
    return {"score": round(100.0 * n / len(groups), 2), "detail": {"pass": n, "total": len(groups)},
            "ok": n == len(groups)}


def dim_redline() -> dict:
    files = rl.target_files()
    hits = sum(len(rl.scan_file(f)["hits"]) for f in files)
    return {"score": 100.0 if hits == 0 else max(0.0, 100.0 - hits * 20),
            "detail": {"files": len(files), "hits": hits}, "ok": hits == 0}


def dim_docs() -> dict:
    have = [d for d in DOCS if os.path.exists(os.path.join(ROOT, d))]
    miss = [d for d in DOCS if d not in have]
    return {"score": round(100.0 * len(have) / len(DOCS), 2),
            "detail": {"present": have, "missing": miss}, "ok": not miss}


def dim_repro() -> dict:
    a = SovereignHost("0").run_round()
    b = SovereignHost("0").run_round()
    q1 = QueryForge().generate("repro-0")
    q2 = QueryForge().generate("repro-0")
    ok = (a["stages"]["R4"]["audit"] == b["stages"]["R4"]["audit"]
          and q1["text"] == q2["text"] and a["round_ok"] and b["round_ok"])
    return {"score": 100.0 if ok else 0.0,
            "detail": {"audit_same": a["stages"]["R4"]["audit"] == b["stages"]["R4"]["audit"],
                       "query_same": q1["text"] == q2["text"]}, "ok": ok}


def dim_coverage() -> dict:
    kv = Knowledge().verify()
    modules = len([m for m in os.listdir(os.path.join(ROOT, "so1331_runtime"))
                   if m.endswith(".py")])
    ok = (kv["cases"] == 20 and modules >= 13 and kv["executors"] == 70
          and kv["dimensions"] == 147)
    score = 100.0
    if not ok:
        score -= 20
    return {"score": score, "detail": {"cases": kv["cases"], "modules": modules,
                                       "executors": kv["executors"],
                                       "dimensions": kv["dimensions"]}, "ok": ok}


WEIGHTS = {"D1": 0.20, "D2": 0.20, "D3": 0.20, "D4": 0.15, "D5": 0.10, "D6": 0.15}


def grade(total: float) -> str:
    for th, g in ((88, "A+"), (84, "A"), (80, "A-"), (76, "B+"), (70, "B")):
        if total >= th:
            return g
    return "C"


def main() -> int:
    dims = {"D1": dim_lock(), "D2": dim_selftest(), "D3": dim_redline(),
            "D4": dim_docs(), "D5": dim_repro(), "D6": dim_coverage()}
    d = {k: v["score"] for k, v in dims.items()}
    total = sum(d[k] * WEIGHTS[k] for k in WEIGHTS)
    # 三个层次分（各层次内部加权平均，不做"逐轮加码"的伪造曲线）
    structure = (d["D1"] * WEIGHTS["D1"] + d["D4"] * WEIGHTS["D4"] + d["D6"] * WEIGHTS["D6"]) \
        / (WEIGHTS["D1"] + WEIGHTS["D4"] + WEIGHTS["D6"])
    semantic = (d["D2"] * WEIGHTS["D2"] + d["D5"] * WEIGHTS["D5"]) \
        / (WEIGHTS["D2"] + WEIGHTS["D5"])
    compliance = d["D3"]
    out = {
        "matrix_id": spec.MATRIX_ID,
        "weights": WEIGHTS,
        "dimensions": {k: {"score": round(v["score"], 2), "ok": v["ok"], "detail": v["detail"]}
                       for k, v in dims.items()},
        "layers": {"结构层(锁数/文档/覆盖)": round(structure, 2),
                   "语义层(自检/可复现)": round(semantic, 2),
                   "合规层(红线)": round(compliance, 2)},
        "total": round(total, 2),
        "grade": grade(total),
        "unverified_external": {
            "平台实测效果": "0/100（未做，且本包不承诺做）",
            "原因": "红线禁止联网/登录/抓取；平台侧指标一律 pending_human_measure",
        },
        "note": "本分数只评'工程完备度'（可复算），不评平台效果，也不是第三方评审",
    }
    path = os.path.join(HERE, "round_scores.json")
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print("=" * 72)
    print("工程完备度自评（六维实测，非第三方评审）")
    print("=" * 72)
    for k in ("D1", "D2", "D3", "D4", "D5", "D6"):
        print(f"{k} score={dims[k]['score']:>6.2f}  ok={dims[k]['ok']}")
    print("-" * 72)
    for k, v in out["layers"].items():
        print(f"{k} = {v:.2f}")
    print(f"完备度总分 {out['total']:.2f}  评级 {out['grade']}")
    print("外部实测：0/100（未做；平台侧全部 pending_human_measure）")
    print(f"已写入 {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
