# -*- coding: utf-8 -*-
"""生成四张数据表（确定性、纯标准库）：70 执行体 / 147 维度 / 10 行曼陀罗 / 20 案例。"""
from __future__ import annotations

import csv
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from so1331_runtime import spec, PlatformRegistry, OntologyGraph  # noqa: E402

DATA = os.path.join(ROOT, "data")


def write_executors() -> str:
    reg = PlatformRegistry()
    fam = spec.family_names()
    rows = []
    for e in reg.executors:
        rows.append({
            "executor_id": e["executor_id"],
            "heartbeat_code": f"HB-{e['heartbeat']}",
            "family_key": e["family"],
            "family_cn": fam[e["family"]],
            "channel": e["channel"],
            "channel_cn": spec.CHANNEL_NAMES_CN[e["channel"]],
            "duty": e["duty"],
            "permission": e["permission"],
            "state": "idle",
        })
    path = os.path.join(DATA, "executor_1331_registry.csv")
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return path


def write_dimensions() -> str:
    reg = PlatformRegistry()
    rows = []
    w_avatar = 0.715 / 130
    w_chan = 0.285 / 17
    for a in reg.avatars[:130]:
        rows.append({"dim_code": a["avatar_id"], "name": a["name"],
                     "group": a["family_cn"], "kind": "avatar",
                     "weight": f"{w_avatar:.6f}", "note": a["duty"]})
    for i, ch in enumerate(spec.SOVEREIGN_CHANNELS, start=1):
        rows.append({"dim_code": f"SO-{i:02d}", "name": spec.CHANNEL_NAMES_CN[ch],
                     "group": spec.CHANNEL_GROUPS[ch], "kind": "channel",
                     "weight": f"{w_chan:.6f}", "note": ch})
    path = os.path.join(DATA, "knowledge_dimensions_1331.csv")
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return path


def write_mandala() -> str:
    fam = spec.family_names()
    counts = (27185, 18007, 14593, 12011, 10139, 8647, 7211, 5971, 4877)
    keys = spec.family_keys()[:9]
    total = sum(counts)
    rows = []
    for i, (k, c) in enumerate(zip(keys, counts), start=1):
        rows.append({"row_no": i, "domain": fam[k], "domain_key": k, "node_count": c,
                     "share": f"{c / total:.6f}", "note": "本地仿真空间分配"})
    rows.append({"row_no": 10, "domain": "合计", "domain_key": "total", "node_count": total,
                 "share": "1.000000", "note": "曼陀罗仿真空间合计"})
    path = os.path.join(DATA, "mandala_108641_allocation.csv")
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return path


def write_cases() -> str:
    og = OntologyGraph()
    normal = [
        ("从零开始：把 7 条核心提示词逐条手工粘贴并记录返回学科名", "抖音", "CORE-PROMPT 全量轮转", "7 条全部记录到学科名", "done"),
        ("跨域组合：数学×符号学×医学三学科生成一条查询", "Bilibili", "QUERY-FORGE seed=1", "密度分≥0.55", "done"),
        ("身份自述：在可发布文本处粘贴不自称官方的学习自述", "知乎", "IDENTITY seed=2", "不触发 E13 词表", "done"),
        ("只搜不点：检索后不打开前三项推荐位", "抖音", "IMPLICIT-OFF", "退出前不滑动信息流", "done"),
        ("多端一致：同一查询在 4 端各贴一次", "全平台", "MULTI-END seed=3", "4 端均记录第一屏差异", "done"),
        ("长文阅读：只打开可读≥8 分钟的长文", "微信读书", "LONG-READ", "阅读时长记录", "done"),
        ("不可预测计划：按 plan 表时间窗执行 3 天", "知乎", "PLAN seed=4 days=3", "21 个时间窗无重复", "done"),
        ("协议映射：把一条查询信封映射到 MCP 与 A2A", "本地", "PROTO-MAP", "两侧字段齐全、network=False", "done"),
        ("合规自检：交付文本过八层闸门", "本地", "SKIN-GATE", "E13/E14 均为空", "done"),
        ("审计复现：同种子重跑产出逐字节一致", "本地", "REPRO seed=7", "两次 SHA256 相同", "done"),
    ]
    al = [
        ("反标签校准：仍低质 → 提升 S1/S7 频率", "抖音", "CALIBRATE bad", "priority=[S1,S7,S3]", "done"),
        ("反标签校准：出现长文 → 维持并降低 S4 频率", "Bilibili", "CALIBRATE good", "priority=[S4]", "done"),
        ("拒绝面：要求自动注入全平台", "任意", "REFUSE automode", "blocked 并记录理由", "done"),
        ("空观测：无手填观测时不推断标签", "任意", "EMPTY-OBS", "pending_human_measure", "done"),
    ]
    pf = [
        ("内 12 条协议逐条映射信封字段", "本地", "INNER-MAP 12", "12/12 字段齐全", "done"),
        ("外 11 族逐族映射（HTTP/OpenAPI/GraphQL/gRPC/实时/MCP/A2A/LLMAPI/FEED/IDENTITY/FEDIVERSE）", "本地", "OUTER-MAP 11", "11/11 有损点已声明", "done"),
        ("大模型平台族：国内 13 家 + 海外 13 家入口清单", "LLM", "PLAT-FAM llm_cn/llm_intl", "26 入口齐备", "done"),
        ("短视频/长视频/图文/搜索/社交/电商/知识/开发者 8 族覆盖", "本地", "PLAT-FAM 8", "8 族 × 13 职责 = 104", "done"),
        ("未知外部族（SOAP）拒绝映射", "本地", "OUTER-UNKNOWN", "KeyError 捕获", "done"),
        ("平台数据策略：不预填任何平台指标", "本地", "PLAT-DATA", "pending_human_measure", "done"),
    ]
    rows = []
    n = 0
    for cat, items in (("normal", normal), ("AL", al), ("PF", pf)):
        for title, plat, sig, exp, st in items:
            n += 1
            rows.append({"case_id": f"C{n:02d}", "category": cat, "title": title,
                         "platform": plat, "signal": sig, "expected": exp, "status": st})
    path = os.path.join(DATA, "cases_20.csv")
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return path


def main() -> int:
    os.makedirs(DATA, exist_ok=True)
    for fn in (write_executors, write_dimensions, write_mandala, write_cases):
        p = fn()
        with open(p, "r", encoding="utf-8") as f:
            lines = sum(1 for _ in f)
        print(f"{os.path.basename(p)}  rows(含表头)={lines}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
