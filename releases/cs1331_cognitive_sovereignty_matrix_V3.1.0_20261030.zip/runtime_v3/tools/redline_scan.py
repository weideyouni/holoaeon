# -*- coding: utf-8 -*-
"""
红线扫描（AST/文本，零执行）
==============================================================
扫描对象：so1331_runtime/*.py、main.py、selftest.py、cs_demo.py、tools/*.py（本文件自身除外）。
检测：
  A. 禁用模块导入：socket / ssl / urllib / http / requests / httpx / ftplib / smtplib /
     telnetlib / paramiko / subprocess / webbrowser / shutil(删除用途另查)
  B. 禁用调用：os.system / os.popen / eval / exec / __import__ / compile
  C. 危险字面量：http:// https:// api_key apikey .env token=
输出：命中清单 + 计数；有命中即 exit 1。
"""
from __future__ import annotations

import ast
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SELF = os.path.abspath(__file__)

FORBIDDEN_MODULES = {
    "socket", "ssl", "urllib", "urllib2", "http", "requests", "httpx", "ftplib",
    "smtplib", "telnetlib", "paramiko", "subprocess", "webbrowser", "asyncio",
}
FORBIDDEN_CALLS = {"system", "popen", "eval", "exec", "__import__", "compile", "spawn"}
DANGEROUS_LITERALS = ("http://", "https://", "api_key", "apikey", ".env", "token=")


def target_files() -> list:
    files = []
    pkg = os.path.join(ROOT, "so1331_runtime")
    for name in sorted(os.listdir(pkg)):
        if name.endswith(".py"):
            files.append(os.path.join(pkg, name))
    for name in ("main.py", "selftest.py", "cs_demo.py"):
        p = os.path.join(ROOT, name)
        if os.path.exists(p):
            files.append(p)
    for name in sorted(os.listdir(HERE)):
        if name.endswith(".py"):
            p = os.path.join(HERE, name)
            if os.path.abspath(p) != SELF:
                files.append(p)
    return files


def scan_file(path: str) -> dict:
    hits = []
    doc_nodes = set()
    src = open(path, "r", encoding="utf-8").read()
    try:
        tree = ast.parse(src)
    except SyntaxError as exc:
        return {"file": path, "hits": [f"SYNTAX: {exc}"], "ok": False}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                base = a.name.split(".")[0]
                if base in FORBIDDEN_MODULES:
                    hits.append(f"import {a.name} @L{node.lineno}")
        elif isinstance(node, ast.ImportFrom):
            base = (node.module or "").split(".")[0]
            if base in FORBIDDEN_MODULES:
                hits.append(f"from {node.module} import ... @L{node.lineno}")
        elif isinstance(node, ast.Call):
            fn = node.func
            if isinstance(fn, ast.Attribute) and fn.attr in FORBIDDEN_CALLS:
                hits.append(f"call .{fn.attr}() @L{node.lineno}")
            elif isinstance(fn, ast.Name) and fn.id in FORBIDDEN_CALLS:
                hits.append(f"call {fn.id}() @L{node.lineno}")
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            body = getattr(node, "body", [])
            if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) \
                    and isinstance(body[0].value.value, str):
                doc_nodes.add(id(body[0].value))
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            if id(node) in doc_nodes:
                continue                      # 文档字符串（红线声明本身）不计入
            for lit in DANGEROUS_LITERALS:
                if lit in node.value:
                    hits.append(f'literal "{lit}" @L{node.lineno}')
    return {"file": os.path.relpath(path, ROOT), "hits": hits, "ok": not hits}


def main() -> int:
    files = target_files()
    results = [scan_file(f) for f in files]
    total_hits = sum(len(r["hits"]) for r in results)
    print("=" * 72)
    print("红线扫描（AST + 字面量，零执行）")
    print("=" * 72)
    for r in results:
        print(f"[{'OK' if r['ok'] else 'HIT'}] {r['file']}")
        for h in r["hits"]:
            print(f"      - {h}")
    print("-" * 72)
    print(f"扫描文件 {len(files)} 个 | 命中 {total_hits} 处 | 违规文件 "
          f"{sum(1 for r in results if not r['ok'])} 个")
    print("结论：" + ("零违规（红线全部守住）" if total_hits == 0 else "存在违规，禁止发布"))
    return 0 if total_hits == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
